import { useEffect, useMemo, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Alert,
  AppBar,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Container,
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemText,
  MenuItem,
  Stack,
  TextField,
  Toolbar,
  Typography,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import DeleteSweepIcon from '@mui/icons-material/DeleteSweep';
import RefreshIcon from '@mui/icons-material/Refresh';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import RouteIcon from '@mui/icons-material/Route';
import { fetchInsights, kmFromMeters, kmhFromKnots } from '../services/tripInsightsService';
import smartAlertsService from '../services/smartAlertsService';
import storageService from '../services/storageService';

/**
 * TripSummaryPage — الملخص الذكي والتنبيهات.
 * التصميم يتبع ثيم التطبيق بالكامل (palette) فيتناسق تلقائيًا مع
 * الوضع الداكن/الفاتح وبقية صفحات My Tracker.
 */
const useStyles = makeStyles()((theme) => ({
  page: { paddingBottom: theme.spacing(10) },
  statCard: {
    flex: '1 1 40%',
    minWidth: 140,
    background:
      theme.palette.mode === 'dark'
        ? 'linear-gradient(145deg, rgba(33,150,243,0.12), rgba(33,150,243,0.03))'
        : theme.palette.background.paper,
  },
  statValue: {
    fontSize: '1.6rem',
    fontWeight: 800,
    color: theme.palette.primary.main,
  },
  sectionTitle: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(1),
    marginBottom: theme.spacing(1.5),
  },
  summaryCard: {
    borderInlineStart: `4px solid ${theme.palette.primary.main}`,
  },
  alertItem: {
    borderRadius: theme.shape.borderRadius,
    marginBottom: theme.spacing(1),
    background: theme.palette.background.paper,
  },
}));

const toInputDate = (d) => d.toISOString().slice(0, 10);

const KIND_META = {
  tow: { color: 'error', label: 'سحب محتمل' },
  overspeed: { color: 'warning', label: 'تجاوز سرعة' },
  reconnect: { color: 'info', label: 'عودة اتصال' },
};

const TripSummaryPage = () => {
  const { classes } = useStyles();
  const navigate = useNavigate();
  const devices = useSelector((state) => Object.values(state.devices.items));
  const [deviceId, setDeviceId] = useState('');
  const [date, setDate] = useState(toInputDate(new Date()));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [insights, setInsights] = useState(null);
  const [alerts, setAlerts] = useState(storageService.getState().smartAlerts?.log || []);

  useEffect(() => {
    if (!deviceId && devices.length) setDeviceId(String(devices[0].id));
  }, [devices, deviceId]);

  useEffect(
    () => storageService.subscribe((s) => setAlerts(s.smartAlerts?.log || [])),
    [],
  );

  const load = async () => {
    if (!deviceId) return;
    setLoading(true);
    setError(null);
    const from = new Date(`${date}T00:00:00`);
    const to = new Date(`${date}T23:59:59`);
    const result = await fetchInsights(Number(deviceId), from, to);
    setLoading(false);
    if (!result.ok) {
      setError(result.error);
      setInsights(null);
    } else {
      setInsights(result.insights);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deviceId, date]);

  const stats = useMemo(() => {
    if (!insights) return [];
    const t = insights.totals;
    return [
      { label: 'المسافة', value: `${Math.round(t.distanceKm * 10) / 10}`, unit: 'كم' },
      { label: 'عدد الرحلات', value: `${t.trips}`, unit: '' },
      { label: 'أعلى سرعة', value: `${Math.round(t.maxSpeedKmh)}`, unit: 'كم/س' },
      { label: 'متوسط السرعة', value: `${Math.round(t.avgSpeedKmh)}`, unit: 'كم/س' },
    ];
  }, [insights]);

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
      <AppBar position="sticky" color="default" elevation={1}>
        <Toolbar>
          <IconButton edge="start" onClick={() => navigate(-1)} aria-label="رجوع">
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h6" sx={{ ml: 1 }}>
            الملخص الذكي والتنبيهات
          </Typography>
        </Toolbar>
      </AppBar>

      <Container maxWidth="sm" className={classes.page} sx={{ py: 2 }}>
        {/* الفلاتر */}
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} mb={2} alignItems="center">
          <TextField
            select
            label="المركبة"
            value={deviceId}
            onChange={(e) => setDeviceId(e.target.value)}
            fullWidth
            size="small"
          >
            {devices.map((d) => (
              <MenuItem key={d.id} value={String(d.id)}>
                {d.name}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            type="date"
            label="اليوم"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            fullWidth
            size="small"
          />
          <IconButton onClick={load} disabled={loading} color="primary" aria-label="تحديث">
            <RefreshIcon />
          </IconButton>
        </Stack>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}
        {loading && (
          <Typography color="text.secondary" sx={{ mb: 2 }}>
            جارٍ تحليل الرحلات…
          </Typography>
        )}

        {insights && (
          <>
            {/* ملخص نصي */}
            <Card className={classes.summaryCard} sx={{ mb: 2 }}>
              <CardContent>
                <Box className={classes.sectionTitle}>
                  <RouteIcon color="primary" />
                  <Typography variant="h6">ملخص اليوم</Typography>
                </Box>
                {insights.lines.map((line) => (
                  <Typography key={line} sx={{ lineHeight: 2 }}>
                    {line}
                  </Typography>
                ))}
              </CardContent>
            </Card>

            {/* بطاقات إحصائية */}
            <Stack direction="row" flexWrap="wrap" gap={1.5} mb={3}>
              {stats.map((s) => (
                <Card key={s.label} className={classes.statCard}>
                  <CardContent sx={{ py: 1.5, '&:last-child': { pb: 1.5 } }}>
                    <Typography variant="body2" color="text.secondary">
                      {s.label}
                    </Typography>
                    <span className={classes.statValue}>{s.value}</span>{' '}
                    <Typography component="span" color="text.secondary">
                      {s.unit}
                    </Typography>
                  </CardContent>
                </Card>
              ))}
            </Stack>

            {/* تفاصيل الرحلات */}
            {insights.trips.length > 0 && (
              <>
                <Typography variant="subtitle1" fontWeight={700} gutterBottom>
                  تفاصيل الرحلات
                </Typography>
                {insights.trips.map((trip) => (
                  <Card key={`${trip.startTime}-${trip.endTime}`} sx={{ mb: 1 }}>
                    <CardContent sx={{ py: 1.5, '&:last-child': { pb: 1.5 } }}>
                      <Typography fontWeight={700}>
                        {new Date(trip.startTime).toLocaleTimeString('ar', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                        {' → '}
                        {new Date(trip.endTime).toLocaleTimeString('ar', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </Typography>
                      <Typography color="text.secondary" variant="body2">
                        {`${Math.round(kmFromMeters(trip.distance) * 10) / 10} كم · أقصى سرعة ${Math.round(kmhFromKnots(trip.maxSpeed))} كم/س`}
                      </Typography>
                      {(trip.startAddress || trip.endAddress) && (
                        <Typography variant="body2" color="text.secondary">
                          {`من: ${trip.startAddress || '—'} · إلى: ${trip.endAddress || '—'}`}
                        </Typography>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </>
            )}
          </>
        )}

        <Divider sx={{ my: 3 }} />

        {/* التنبيهات الذكية */}
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={1.5}>
          <Box className={classes.sectionTitle} sx={{ mb: 0 }}>
            <NotificationsActiveIcon color="primary" />
            <Typography variant="h6">التنبيهات الذكية</Typography>
          </Box>
          {alerts.length > 0 && (
            <Button
              size="small"
              startIcon={<DeleteSweepIcon />}
              onClick={() => smartAlertsService.clearLog()}
            >
              مسح الكل
            </Button>
          )}
        </Stack>
        {alerts.length === 0 ? (
          <Typography color="text.secondary">
            لا توجد تنبيهات — سننبهك عند حركة مشبوهة أو تجاوز سرعة أو انقطاع طويل.
          </Typography>
        ) : (
          <List disablePadding>
            {alerts.map((a) => {
              const meta = KIND_META[a.kind] || { color: 'default', label: a.kind };
              return (
                <ListItem key={a.id} className={classes.alertItem} disableGutters sx={{ px: 2 }}>
                  <ListItemText
                    primary={a.title}
                    secondary={`${a.body} — ${new Date(a.ts).toLocaleString('ar')}`}
                  />
                  <Chip size="small" color={meta.color} label={meta.label} />
                </ListItem>
              );
            })}
          </List>
        )}
      </Container>
    </Box>
  );
};

export default TripSummaryPage;
