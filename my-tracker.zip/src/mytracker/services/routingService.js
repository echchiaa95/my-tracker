/**
 * routingService — أقرب مسار من موقع الهاتف إلى السيارة + خطوات الملاحة.
 * يستخدم خادم OSRM العام (قيادة/مشي) مع خطوات منعطفات (steps) للملاحة
 * داخل التطبيق بلغة الواجهة الحالية؛ عند غياب الاتصال يرجع خطًا مستقيمًا.
 */

const OSRM_BASE = 'https://router.project-osrm.org/route/v1';

/** نصوص تعليمات الملاحة حسب لغة التطبيق (ar/fr/en). */
const NAV_I18N = {
  ar: {
    depart: 'ابدأ',
    arrive: 'وصلت إلى سيارتك',
    turnLeft: 'انعطف يسارًا',
    turnRight: 'انعطف يمينًا',
    slightLeft: 'مِل قليلًا لليسار',
    slightRight: 'مِل قليلًا لليمين',
    sharpLeft: 'انعطف بحدة لليسار',
    sharpRight: 'انعطف بحدة لليمين',
    uturn: 'استدر وعد للخلف',
    continue: 'تابع الطريق',
    merge: 'اندمج',
    fork: 'خذ التفرع',
    follow: 'تابع',
    streetIn: (s) => ` في ${s}`,
    roundabout: (exit) => `ادخل الدوار واخرج من المخرج ${exit}`.trim(),
  },
  fr: {
    depart: 'Démarrez',
    arrive: 'Vous êtes arrivé à votre voiture',
    turnLeft: 'Tournez à gauche',
    turnRight: 'Tournez à droite',
    slightLeft: 'Serrez légèrement à gauche',
    slightRight: 'Serrez légèrement à droite',
    sharpLeft: 'Tournez fortement à gauche',
    sharpRight: 'Tournez fortement à droite',
    uturn: 'Faites demi-tour',
    continue: 'Continuez tout droit',
    merge: 'Insérez-vous',
    fork: 'Prenez la bifurcation',
    follow: 'Suivez',
    streetIn: (s) => ` sur ${s}`,
    roundabout: (exit) => `Prenez le rond-point, sortie ${exit}`.trim(),
  },
  en: {
    depart: 'Start',
    arrive: 'You have arrived at your car',
    turnLeft: 'Turn left',
    turnRight: 'Turn right',
    slightLeft: 'Bear slightly left',
    slightRight: 'Bear slightly right',
    sharpLeft: 'Turn sharp left',
    sharpRight: 'Turn sharp right',
    uturn: 'Make a U-turn',
    continue: 'Continue straight',
    merge: 'Merge',
    fork: 'Take the fork',
    follow: 'Follow',
    streetIn: (s) => ` on ${s}`,
    roundabout: (exit) => `Enter the roundabout, exit ${exit}`.trim(),
  },
};

/**
 * @param {string} lang لغة التطبيق الحالية (ar/fr/en) لترجمة التعليمات.
 * @returns {Promise<{ ok, coords?: [lon,lat][], distanceKm?: number,
 *   durationMin?: number, steps?: Array, fallback?: boolean }>}
 * steps: [{ instruction, distanceM, location }]
 */
export async function findRoute(from, to, profile = 'driving', lang = 'ar') {
  try {
    const url =
      `${OSRM_BASE}/${profile}/${from.lon},${from.lat};${to.lon},${to.lat}` +
      '?overview=full&geometries=geojson&steps=true';
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const route = data?.routes?.[0];
    if (!route) throw new Error('no route');

    const steps = [];
    (route.legs || []).forEach((leg) => {
      (leg.steps || []).forEach((step) => {
        steps.push({
          instruction: translateManeuver(step.maneuver, step.name, lang),
          distanceM: step.distance,
          location: step.maneuver?.location, // [lon, lat]
        });
      });
    });

    return {
      ok: true,
      coords: route.geometry.coordinates,
      distanceKm: route.distance / 1000,
      durationMin: route.duration / 60,
      steps,
      fallback: false,
    };
  } catch {
    // بدون اتصال: خط مستقيم + مسافة هافرساين
    const R = 6371;
    const dLat = ((to.lat - from.lat) * Math.PI) / 180;
    const dLon = ((to.lon - from.lon) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos((from.lat * Math.PI) / 180) *
        Math.cos((to.lat * Math.PI) / 180) *
        Math.sin(dLon / 2) ** 2;
    const distanceKm = 2 * R * Math.asin(Math.sqrt(a));
    return {
      ok: true,
      coords: [
        [from.lon, from.lat],
        [to.lon, to.lat],
      ],
      distanceKm,
      durationMin: (distanceKm / 40) * 60,
      steps: [],
      fallback: true,
    };
  }
}

/** ترجمة منعطفات OSRM إلى لغة التطبيق. */
function translateManeuver(maneuver, streetName, lang = 'ar') {
  const S = NAV_I18N[lang] || NAV_I18N.ar;
  if (!maneuver) return S.continue;
  const street = streetName ? S.streetIn(streetName) : '';
  const modKey = {
    left: 'turnLeft',
    right: 'turnRight',
    'slight left': 'slightLeft',
    'slight right': 'slightRight',
    'sharp left': 'sharpLeft',
    'sharp right': 'sharpRight',
    uturn: 'uturn',
  }[maneuver.modifier];
  const modText = modKey ? S[modKey] : '';
  switch (maneuver.type) {
    case 'depart':
      return `${S.depart}${street}`;
    case 'arrive':
      return S.arrive;
    case 'turn':
    case 'end of road':
      return `${modText || S.continue}${street}`.trim();
    case 'continue':
      return `${S.continue}${street}`;
    case 'merge':
      return `${S.merge}${modText ? ` ${modText}` : ''}`.trim();
    case 'roundabout':
    case 'rotary':
      return S.roundabout(maneuver.exit || '');
    case 'fork':
      return `${S.fork}${modText ? ` ${modText}` : ''}`.trim();
    case 'new name':
      return `${S.follow}${street}`;
    default:
      return `${modText || S.follow}${street}`.trim();
  }
}

/** رابط ملاحة Google Maps خارجي (احتياطي). */
export const googleNavLink = (to, profile = 'driving') =>
  `https://www.google.com/maps/dir/?api=1&destination=${to.lat},${to.lon}&travelmode=${profile}`;
