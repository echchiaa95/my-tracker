/**
 * tripInsightsService — ملخص الرحلات الذكي.
 * يجمع بيانات /api/reports/trips و /api/reports/summary من Traccar ويحوّلها
 * إلى ملخص نصي وبطاقات إحصائية بلغة واجهة التطبيق الحالية (ar/fr/en).
 * لا يخزّن شيئًا — حساب فوري عند فتح الصفحة.
 */

import traccarService from './traccarService';

const METERS_PER_KM = 1000;
const KNOTS_TO_KMH = 1.852;

/** تحويل مسافة Traccar (متر) إلى كم مقروءة. */
export const kmFromMeters = (m) => (m || 0) / METERS_PER_KM;

/** سرعات Traccar تأتي بالعقدة (knots). */
export const kmhFromKnots = (kn) => (kn || 0) * KNOTS_TO_KMH;

/** نصوص الملخص الذكي حسب لغة التطبيق (ar/fr/en). */
const INSIGHT_I18N = {
  ar: {
    noTrips: 'لا توجد رحلات مسجلة في هذه الفترة.',
    tripOne: 'رحلة',
    tripMany: 'رحلات',
    main: (km, trips, word, dur) =>
      `قطعت ${km} كم في ${trips} ${word}${dur ? ` بزمن قيادة إجمالي ${dur}.` : '.'}`,
    longest: (km, from, to) => `أطول رحلة: ${km} كم (من ${from} إلى ${to}).`,
    speed: (max, avg) => `أعلى سرعة ${max} كم/س، ومتوسط السرعة ${avg} كم/س.`,
    fuel: (l) => `الوقود المستهلك: ${l} لتر.`,
    highSpeed: 'تنبيه: سُجّلت سرعة مرتفعة جدًا — قُد بحذر.',
    h: 'س',
    m: 'د',
  },
  fr: {
    noTrips: 'Aucun trajet enregistré sur cette période.',
    tripOne: 'trajet',
    tripMany: 'trajets',
    main: (km, trips, word, dur) =>
      `Vous avez parcouru ${km} km en ${trips} ${word}${dur ? `, avec un temps de conduite total de ${dur}.` : '.'}`,
    longest: (km, from, to) => `Trajet le plus long : ${km} km (de ${from} à ${to}).`,
    speed: (max, avg) => `Vitesse max ${max} km/h, vitesse moyenne ${avg} km/h.`,
    fuel: (l) => `Carburant consommé : ${l} L.`,
    highSpeed: 'Attention : vitesse très élevée enregistrée — conduisez prudemment.',
    h: 'h',
    m: 'min',
  },
  en: {
    noTrips: 'No trips recorded in this period.',
    tripOne: 'trip',
    tripMany: 'trips',
    main: (km, trips, word, dur) =>
      `You drove ${km} km in ${trips} ${word}${dur ? `, with a total driving time of ${dur}.` : '.'}`,
    longest: (km, from, to) => `Longest trip: ${km} km (from ${from} to ${to}).`,
    speed: (max, avg) => `Top speed ${max} km/h, average speed ${avg} km/h.`,
    fuel: (l) => `Fuel consumed: ${l} L.`,
    highSpeed: 'Warning: very high speed recorded — drive carefully.',
    h: 'h',
    m: 'min',
  },
};

function fmtKm(km) {
  if (km >= 100) return Math.round(km).toString();
  return (Math.round(km * 10) / 10).toString();
}

function fmtDuration(ms, S) {
  if (!ms || ms <= 0) return `0 ${S.m}`;
  const totalMin = Math.round(ms / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h && m) return `${h} ${S.h} ${m} ${S.m}`;
  if (h) return `${h} ${S.h}`;
  return `${m} ${S.m}`;
}

function fmtTime(iso, lang) {
  try {
    return new Date(iso).toLocaleTimeString(lang, { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

/**
 * يبني ملخصًا ذكيًا من رحلات يوم/فترة واحدة لجهاز واحد.
 * @param {string} lang لغة التطبيق الحالية.
 * @returns {{
 *   totals: { trips, distanceKm, driveMs, maxSpeedKmh, avgSpeedKmh, spentFuel },
 *   longest: object|null, fastest: object|null,
 *   lines: string[], trips: object[]
 * }}
 */
export function buildInsights(trips, summaryRow, lang = 'ar') {
  const S = INSIGHT_I18N[lang] || INSIGHT_I18N.ar;
  const list = Array.isArray(trips) ? trips : [];
  const totals = {
    trips: list.length,
    distanceKm: 0,
    driveMs: 0,
    maxSpeedKmh: 0,
    avgSpeedKmh: 0,
    spentFuel: summaryRow?.spentFuel || 0,
  };
  let longest = null;
  let fastest = null;
  let weightedSpeed = 0;

  list.forEach((trip) => {
    const dist = kmFromMeters(trip.distance);
    const dur = trip.duration || 0;
    totals.distanceKm += dist;
    totals.driveMs += dur;
    const maxKmh = kmhFromKnots(trip.maxSpeed);
    if (maxKmh > totals.maxSpeedKmh) totals.maxSpeedKmh = maxKmh;
    weightedSpeed += kmhFromKnots(trip.averageSpeed) * dist;
    if (!longest || dist > kmFromMeters(longest.distance)) longest = trip;
    if (!fastest || maxKmh > kmhFromKnots(fastest.maxSpeed)) fastest = trip;
  });

  if (totals.distanceKm > 0) {
    totals.avgSpeedKmh = weightedSpeed / totals.distanceKm;
  } else if (summaryRow) {
    // Traccar summary أدق أحيانًا (يشمل مسافات خارج الرحلات المكتشفة)
    totals.distanceKm = kmFromMeters(summaryRow.distance);
    totals.maxSpeedKmh = kmhFromKnots(summaryRow.maxSpeed);
    totals.avgSpeedKmh = kmhFromKnots(summaryRow.averageSpeed);
  }

  const lines = [];
  if (!list.length && !summaryRow) {
    lines.push(S.noTrips);
  } else {
    lines.push(
      S.main(
        fmtKm(totals.distanceKm),
        totals.trips,
        totals.trips === 1 ? S.tripOne : S.tripMany,
        totals.driveMs ? fmtDuration(totals.driveMs, S) : '',
      ),
    );
    if (longest) {
      lines.push(
        S.longest(
          fmtKm(kmFromMeters(longest.distance)),
          fmtTime(longest.startTime, lang),
          fmtTime(longest.endTime, lang),
        ),
      );
    }
    if (totals.maxSpeedKmh > 0) {
      lines.push(S.speed(Math.round(totals.maxSpeedKmh), Math.round(totals.avgSpeedKmh)));
    }
    if (totals.spentFuel > 0) {
      lines.push(S.fuel((Math.round(totals.spentFuel * 10) / 10).toString()));
    }
    // ملاحظة سياقية بسيطة
    if (totals.maxSpeedKmh >= 140) {
      lines.push(S.highSpeed);
    }
  }

  return { totals, longest, fastest, lines, trips: list };
}

/**
 * يجلب الرحلات والملخص لفترة زمنية ويبني الـInsights بلغة الواجهة.
 * @returns {Promise<{ ok, error?, insights? }>}
 */
export async function fetchInsights(deviceId, fromDate, toDate, lang = 'ar') {
  const fromIso = new Date(fromDate).toISOString();
  const toIso = new Date(toDate).toISOString();
  const [tripsRes, summaryRes] = await Promise.all([
    traccarService.getTrips(deviceId, fromIso, toIso),
    traccarService.getSummary(deviceId, fromIso, toIso),
  ]);
  if (!tripsRes.ok) return { ok: false, error: tripsRes.error };
  const summaryRow = summaryRes.ok && summaryRes.summary?.length ? summaryRes.summary[0] : null;
  return { ok: true, insights: buildInsights(tripsRes.trips, summaryRow, lang) };
}
