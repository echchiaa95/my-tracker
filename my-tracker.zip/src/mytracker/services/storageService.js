/**
 * StorageService — طبقة تخزين محلية (Local-First) لتطبيق My Tracker.
 * لا علاقة لها بـ Redux الأصلي لـ traccar-web. تُخزَّن البيانات في localStorage
 * تحت مفتاح واحد (STORAGE_KEY) لتفادي مشاكل التزامن بين عدة مفاتيح.
 */

const STORAGE_KEY = 'mytracker.state.v1';
const SCHEMA_VERSION = 1;

const defaultState = () => ({
  version: SCHEMA_VERSION,
  settings: {
    appName: 'My Tracker',
    theme: 'system', // 'dark' | 'light' | 'system'
    language: 'ar',
    mapType: 'standard',
  },
  vehicles: {}, // { [deviceId]: { customName, icon, color } }
  diagnostics: {
    // Vehicle Diagnostics V1: نتائج جلسات الفحص فقط (لا Live Data مستمرة)
    sessions: [],
  },
  traccar: {
    // لم يعد يُخزَّن رابط سيرفر — Traccar backend غير مرئي للمستخدم بالكامل،
    // المصدر الوحيد للرابط هو VITE_TRACCAR_URL (يُقرأ مباشرة في
    // MyTrackerRoot). هنا نحتفظ فقط ببريد المستخدم إن اختار "تذكرني".
    email: '',
    rememberSession: false,
  },
  pin: {
    hash: null, // hash بسيط، ليس تشفيرًا فعليًا (انظر pinService.js)
    createdAt: null,
  },
});

function readRaw() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function writeRaw(state) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  } catch {
    return false;
  }
}

function migrate(state) {
  if (!state || typeof state !== 'object') return defaultState();
  // دمج الأقسام الافتراضية يملأ الأقسام الجديدة (مثل diagnostics) للمستخدمين
  // الحاليين دون المساس ببياناتهم المخزنة.
  if (state.version === SCHEMA_VERSION) return { ...defaultState(), ...state };
  // مكان مستقبلي لهجرات المخطط عند تغيّر SCHEMA_VERSION
  return { ...defaultState(), ...state, version: SCHEMA_VERSION };
}

let cache = migrate(readRaw());
if (!readRaw()) writeRaw(cache);

const listeners = new Set();

function notify() {
  listeners.forEach((fn) => fn(cache));
}

const storageService = {
  /** الحصول على كامل الحالة الحالية (نسخة مباشرة، لا تُعدَّل يدويًا). */
  getState() {
    return cache;
  },

  /** الاشتراك في تغييرات الحالة. يُرجع دالة إلغاء الاشتراك. */
  subscribe(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },

  /** تحديث جزء من الحالة عبر دمج سطحي (shallow) لكل قسم. */
  update(section, patch) {
    cache = {
      ...cache,
      [section]: { ...cache[section], ...patch },
    };
    writeRaw(cache);
    notify();
    return cache;
  },

  /** تحديث كائن vehicles لجهاز واحد. */
  updateVehicle(deviceId, patch) {
    cache = {
      ...cache,
      vehicles: {
        ...cache.vehicles,
        [deviceId]: { ...cache.vehicles[deviceId], ...patch },
      },
    };
    writeRaw(cache);
    notify();
    return cache;
  },

  /** تصدير نسخة احتياطية بصيغة JSON قابلة للتنزيل. */
  exportBackup() {
    const { pin, ...safe } = cache; // لا نصدّر الـ PIN داخل النسخة الاحتياطية
    return {
      version: SCHEMA_VERSION,
      exportedAt: new Date().toISOString(),
      ...safe,
    };
  },

  /** استيراد نسخة احتياطية. يُرجع { ok, error }. */
  importBackup(json) {
    try {
      const data = typeof json === 'string' ? JSON.parse(json) : json;
      if (!data || typeof data !== 'object' || !('settings' in data) || !('vehicles' in data)) {
        return { ok: false, error: 'Invalid backup file' };
      }
      cache = migrate({
        ...defaultState(),
        ...data,
        pin: cache.pin, // نحافظ على PIN الحالي، لا نستورده من الملف
      });
      writeRaw(cache);
      notify();
      return { ok: true };
    } catch {
      return { ok: false, error: 'Invalid backup file' };
    }
  },

  /** حذف كل البيانات المحلية (يتطلب تأكيدًا من الواجهة قبل الاستدعاء). */
  clearAll() {
    cache = defaultState();
    writeRaw(cache);
    notify();
  },
};

export default storageService;
