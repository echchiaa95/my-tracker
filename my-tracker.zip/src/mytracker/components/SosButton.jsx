import { useState } from 'react';
import { useSelector } from 'react-redux';
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Fab,
  MenuItem,
  Snackbar,
  TextField,
  Typography,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import SosIcon from '@mui/icons-material/Sos';
import { buildShareMessage, shareText } from '../services/shareService';
import { useTranslation } from '../../common/components/LocalizationProvider';

const useStyles = makeStyles()((theme) => ({
  fab: {
    position: 'fixed',
    bottom: 'calc(72px + env(safe-area-inset-bottom))',
    insetInlineEnd: theme.spacing(2),
    zIndex: 1200,
  },
}));

/**
 * SosButton — زر طوارئ عائم: يشارك الموقع الحالي لأي مركبة فورًا
 * (Web Share / Capacitor / نسخ الرابط / واتساب) مع تأكيد قبل الإرسال
 * لمنع الضغط الخاطئ. كل النصوص مترجمة عبر l10n لتتبع لغة التطبيق.
 */
const SosButton = () => {
  const { classes } = useStyles();
  const t = useTranslation();
  const devices = useSelector((state) => Object.values(state.devices.items));
  const positions = useSelector((state) => state.session.positions);
  const [open, setOpen] = useState(false);
  const [deviceId, setDeviceId] = useState('');
  const [toast, setToast] = useState('');

  const handleSend = async () => {
    const id = Number(deviceId || devices[0]?.id);
    const device = devices.find((d) => d.id === id);
    const position = positions[id];
    if (!device || !position) {
      setToast(t('mytrackerSosNoPos'));
      setOpen(false);
      return;
    }
    const msg = buildShareMessage({ deviceName: device.name, position });
    try {
      const method = await shareText(msg);
      setToast(method === 'clipboard' ? t('mytrackerCopied') : t('mytrackerShared'));
    } catch {
      setToast(t('mytrackerShareCancelled'));
    }
    setOpen(false);
  };

  if (!devices.length) return null;

  return (
    <>
      <Fab
        color="error"
        className={classes.fab}
        onClick={() => {
          setDeviceId(String(devices[0]?.id || ''));
          setOpen(true);
        }}
        aria-label={t('mytrackerSosAria')}
      >
        <SosIcon />
      </Fab>

      <Dialog open={open} onClose={() => setOpen(false)} fullWidth maxWidth="xs">
        <DialogTitle>{t('mytrackerSosTitle')}</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" mb={2}>
            {t('mytrackerSosBody')}
          </Typography>
          <TextField
            select
            fullWidth
            label={t('mytrackerVehicle')}
            value={deviceId}
            onChange={(e) => setDeviceId(e.target.value)}
          >
            {devices.map((d) => (
              <MenuItem key={d.id} value={String(d.id)}>
                {d.name}
              </MenuItem>
            ))}
          </TextField>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>{t('mytrackerCancel')}</Button>
          <Button onClick={handleSend} variant="contained" color="error">
            {t('mytrackerShareLocation')}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={Boolean(toast)}
        autoHideDuration={3000}
        onClose={() => setToast('')}
        message={toast}
      />
      <Box />
    </>
  );
};

export default SosButton;
