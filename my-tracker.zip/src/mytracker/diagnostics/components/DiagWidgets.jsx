import { Box, Typography, Collapse } from '@mui/material';
import { useState } from 'react';
import { DIAG_COLORS, GlassCard, MutedText, StatusPill } from './diagUi';
import { STATUS_META, SEVERITY_META } from '../services/analysisEngine';
import { SYSTEM_LABELS } from '../services/dtcDatabase';
import { PRIMARY_PID_KEYS } from '../services/obdPids';
import { CheckIcon, WarningIcon, ChevronIcon } from './DiagIcons';

/** عداد النتيجة الصحية الدائري. */
export const HealthGauge = ({ score, status, size = 130, showLabel = true }) => {
  const meta = STATUS_META[status] || STATUS_META.insufficient;
  const pct = score != null ? score / 100 : 0;
  const R = size / 2 - 13;
  const C = 2 * Math.PI * R;
  const sw = Math.max(6, size * 0.08);
  return (
    <Box
      sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: showLabel ? 1 : 0 }}
    >
      <Box sx={{ position: 'relative', width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          <circle
            cx={size / 2}
            cy={size / 2}
            r={R}
            fill="none"
            stroke="rgba(120,160,255,.12)"
            strokeWidth={sw}
          />
          {score != null && (
            <circle
              cx={size / 2}
              cy={size / 2}
              r={R}
              fill="none"
              stroke={meta.color}
              strokeWidth={sw}
              strokeLinecap="round"
              strokeDasharray={C}
              strokeDashoffset={C * (1 - pct)}
              transform={`rotate(-90 ${size / 2} ${size / 2})`}
              style={{ transition: 'stroke-dashoffset .8s ease' }}
            />
          )}
        </svg>
        <Box
          sx={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Typography
            sx={{
              fontSize: size * 0.23,
              fontWeight: 800,
              lineHeight: 1,
              color: score != null ? meta.color : DIAG_COLORS.muted,
            }}
          >
            {score != null ? score : '؟'}
          </Typography>
          {score != null && size >= 100 && <MutedText sx={{ fontSize: 11 }}>/ 100</MutedText>}
        </Box>
      </Box>
      {showLabel && (
        <Box sx={{ mt: 1.2 }}>
          <StatusPill label={meta.ar} color={meta.color} />
        </Box>
      )}
    </Box>
  );
};

/** بطاقة رمز عطل واحد: الوصف + الشدة + النظام + الأسباب + الفحوصات. */
export const DtcCard = ({ dtc }) => {
  const [open, setOpen] = useState(false);
  const sev = SEVERITY_META[dtc.severity] || SEVERITY_META.warning;
  return (
    <GlassCard sx={{ mb: 1 }} onClick={() => setOpen((v) => !v)}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
        <Box sx={{ color: sev.color, display: 'flex' }}>
          <WarningIcon fontSize="small" />
        </Box>
        <Typography
          sx={{ fontWeight: 800, fontSize: 16, fontFamily: 'monospace', letterSpacing: 0.5 }}
        >
          {dtc.code}
        </Typography>
        <StatusPill label={sev.ar} color={sev.color} />
        <Box sx={{ flex: 1 }} />
        <ChevronIcon
          sx={{
            color: DIAG_COLORS.muted,
            transform: open ? 'rotate(90deg)' : 'none',
            transition: 'transform .2s',
          }}
        />
      </Box>
      <Typography sx={{ fontSize: 13.5, mt: 0.8, lineHeight: 1.7 }}>{dtc.desc}</Typography>
      <MutedText sx={{ fontSize: 12, mt: 0.3 }}>
        النظام: {SYSTEM_LABELS[dtc.system]?.ar || 'عام'} · الحالة:{' '}
        {dtc.status === 'cleared' ? 'تم المسح' : 'مخزّن'}
        {!dtc.documented && ' · يتطلب تشخيصًا إضافيًا'}
      </MutedText>
      <Collapse in={open}>
        <Box sx={{ mt: 1.5, borderTop: `1px solid ${DIAG_COLORS.cardBorder}`, pt: 1.5 }}>
          <Typography sx={{ fontSize: 13, fontWeight: 700, mb: 0.5 }}>الأسباب المحتملة</Typography>
          {(dtc.causes || []).map((c) => (
            <MutedText key={c} sx={{ display: 'flex', gap: 0.8, mb: 0.3 }}>
              <Box component="span" sx={{ color: DIAG_COLORS.amber }}>
                •
              </Box>
              {c}
            </MutedText>
          ))}
          <Typography sx={{ fontSize: 13, fontWeight: 700, mt: 1.2, mb: 0.5 }}>
            الفحوصات المقترحة
          </Typography>
          {(dtc.checks || []).map((c) => (
            <MutedText key={c} sx={{ display: 'flex', gap: 0.8, mb: 0.3 }}>
              <Box component="span" sx={{ color: DIAG_COLORS.cyan }}>
                •
              </Box>
              {c}
            </MutedText>
          ))}
          <MutedText sx={{ fontSize: 11.5, mt: 1, color: DIAG_COLORS.amber }}>
            هذه أسباب محتملة وليست تشخيصًا قطعيًا — قد يلزم فحص إضافي لتحديد السبب الجذري.
          </MutedText>
        </Box>
      </Collapse>
    </GlassCard>
  );
};

/** شبكة البيانات الحية: الأساسية أولًا + زر عرض المزيد. */
export const LiveDataGrid = ({ liveData }) => {
  const [more, setMore] = useState(false);
  if (!liveData || !Object.keys(liveData).length) {
    return <MutedText>لم تتوفر بيانات حية من هذه المركبة.</MutedText>;
  }
  const entries = Object.entries(liveData);
  const primary = entries.filter(([k]) => PRIMARY_PID_KEYS.includes(k));
  const rest = entries.filter(([k]) => !PRIMARY_PID_KEYS.includes(k));

  const renderItem = ([key, v]) => (
    <Box
      key={key}
      sx={{
        background: 'rgba(10,17,40,.55)',
        border: `1px solid ${DIAG_COLORS.cardBorder}`,
        borderRadius: 2.5,
        p: 1.3,
        minWidth: 0,
      }}
    >
      <MutedText
        sx={{
          fontSize: 11.5,
          mb: 0.3,
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
        }}
      >
        {v.name?.ar || key}
      </MutedText>
      <Typography sx={{ fontSize: 17, fontWeight: 800, fontFamily: 'monospace' }}>
        {v.value}
        <Box
          component="span"
          sx={{ fontSize: 11, fontWeight: 400, color: DIAG_COLORS.muted, mr: 0.5 }}
        >
          {' '}
          {v.unit?.ar || ''}
        </Box>
      </Typography>
    </Box>
  );

  return (
    <Box>
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 1 }}>
        {primary.map(renderItem)}
      </Box>
      {rest.length > 0 && (
        <>
          <Collapse in={more}>
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 1, mt: 1 }}>
              {rest.map(renderItem)}
            </Box>
          </Collapse>
          <Box
            className="dg-pressable"
            onClick={() => setMore((v) => !v)}
            sx={{
              mt: 1,
              py: 1,
              textAlign: 'center',
              borderRadius: 2.5,
              color: DIAG_COLORS.cyan,
              fontSize: 13,
              fontWeight: 700,
              border: `1px dashed ${DIAG_COLORS.cardBorder}`,
            }}
          >
            {more ? 'عرض أقل' : `عرض المزيد (${rest.length})`}
          </Box>
        </>
      )}
    </Box>
  );
};

/** خطوة واحدة في قائمة مراحل الفحص. */
export const ScanStepRow = ({ label, status }) => (
  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.3, py: 0.9 }}>
    <Box
      sx={{
        width: 24,
        height: 24,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {status === 'done' && <CheckIcon sx={{ color: DIAG_COLORS.green, fontSize: 20 }} />}
      {status === 'active' && <Box className="dg-spinner" />}
      {status === 'pending' && (
        <Box
          sx={{ width: 9, height: 9, borderRadius: '50%', background: 'rgba(138,148,166,.4)' }}
        />
      )}
      {status === 'skipped' && (
        <Box sx={{ width: 9, height: 9, borderRadius: '50%', background: DIAG_COLORS.amber }} />
      )}
      {status === 'error' && <WarningIcon sx={{ color: DIAG_COLORS.red, fontSize: 20 }} />}
    </Box>
    <Typography
      sx={{
        fontSize: 14,
        fontWeight: status === 'active' ? 700 : 500,
        color: status === 'pending' ? DIAG_COLORS.muted : DIAG_COLORS.text,
      }}
    >
      {label}
      {status === 'skipped' && (
        <MutedText component="span" sx={{ fontSize: 12 }}>
          {' '}
          — غير متاح
        </MutedText>
      )}
    </Typography>
  </Box>
);
