/**
 * AnalysisEngine — طبقة تحليل مستقلة: تدمج نتيجة الفحص (DTC + Live Data +
 * Freeze Frame) وتُنتج Health Score وحالة وملاحظات مفهومة.
 * الحساب مبني حصرًا على بيانات حقيقية حُصل عليها فعلًا؛ عند نقص البيانات
 * تكون الحالة 'insufficient' بدل اختراع نتيجة.
 */

import { lookupDtc, SEVERITY_ORDER } from './dtcDatabase';

/**
 * @param {object} input
 *   dtcs: string[] رموز الأعطال المقروءة
 *   liveData: { key: {value, unit, name} } | null
 *   freezeFrame: object | null
 * @returns {{
 *   score: number|null, status: 'healthy'|'warning'|'fault'|'insufficient',
 *   findings: Array<{type:'dtc'|'live', code?, severity, title, detail}>,
 *   dtcsDetailed: Array, summary: string
 * }}
 */
export function analyze({ dtcs = [], liveData = null, freezeFrame = null }) {
  const findings = [];
  const dtcsDetailed = dtcs.map((code) => {
    const info = lookupDtc(code);
    findings.push({
      type: 'dtc',
      code,
      severity: info.severity,
      title: code,
      detail: info.desc,
    });
    return { ...info, status: 'stored' };
  });

  // ملاحظات من Live Data — فقط للقيم المقروءة فعلًا
  if (liveData) {
    const coolant = liveData.coolantTemp?.value;
    if (typeof coolant === 'number') {
      if (coolant >= 110) {
        findings.push({
          type: 'live',
          severity: 'fault',
          title: 'حرارة مرتفعة جدًا',
          detail: `حرارة سائل التبريد ${coolant}°م — أوقف المركبة وافحص نظام التبريد`,
        });
      } else if (coolant >= 102) {
        findings.push({
          type: 'live',
          severity: 'warning',
          title: 'حرارة أعلى من المعتاد',
          detail: `حرارة سائل التبريد ${coolant}°م`,
        });
      }
    }
    const voltage = liveData.controlVoltage?.value;
    if (typeof voltage === 'number' && voltage > 0 && voltage < 12) {
      findings.push({
        type: 'live',
        severity: 'warning',
        title: 'جهد كهربائي منخفض',
        detail: `جهد وحدة التحكم ${voltage}V — افحص البطارية والشحن`,
      });
    }
    const misfireDistance = liveData.milDistance?.value;
    if (typeof misfireDistance === 'number' && misfireDistance > 0) {
      findings.push({
        type: 'live',
        severity: 'info',
        title: 'لمبة العطل مضاءة',
        detail: `المركبة قطعت ${misfireDistance} كم ولمبة العطل مضاءة`,
      });
    }
  }

  // هل توجد بيانات كافية للحكم؟
  const hasLive = liveData && Object.keys(liveData).length >= 2;
  const hasDtcScan = true; // قراءة DTC نجحت (وصلت هنا)
  if (!hasLive && !hasDtcScan) {
    return {
      score: null,
      status: 'insufficient',
      findings,
      dtcsDetailed,
      summary: 'بيانات غير كافية لحساب نتيجة صحية',
    };
  }

  // الحساب: 100 - خصومات حسب الشدة، بحد أدنى 5 عند وجود عطل جسيم
  let score = 100;
  for (const f of findings) {
    if (f.severity === 'fault') score -= 25;
    else if (f.severity === 'warning') score -= 10;
    else score -= 3;
  }
  const hasFault = findings.some((f) => f.severity === 'fault');
  score = Math.max(hasFault ? 5 : 40, Math.min(100, score));
  if (!hasLive && dtcs.length === 0) {
    // نجح الفحص لكن لا بيانات حية كافية ولا أعطال — نتيجة مبنية على DTC فقط
    return {
      score: 95,
      status: 'healthy',
      findings,
      dtcsDetailed,
      summary: 'لا توجد رموز أعطال مخزنة',
    };
  }

  let status = 'healthy';
  if (hasFault) status = 'fault';
  else if (findings.some((f) => SEVERITY_ORDER[f.severity] >= 2)) status = 'warning';

  const summary =
    status === 'healthy'
      ? 'لا توجد مؤشرات أعطال حالية'
      : status === 'warning'
        ? `توجد ${dtcs.length || ''} مؤشرات تستدعي المتابعة`
        : 'توجد أعطال تحتاج تدخلًا';

  return { score, status, findings, dtcsDetailed, summary, freezeFrame };
}

export const STATUS_META = {
  healthy: { ar: 'سليمة', en: 'Healthy', color: '#2ecc71' },
  warning: { ar: 'تنبيه', en: 'Warning', color: '#f5a623' },
  fault: { ar: 'عطل', en: 'Fault', color: '#ff5252' },
  insufficient: { ar: 'بيانات غير كافية', en: 'Insufficient Data', color: '#8a94a6' },
};

export const SEVERITY_META = {
  fault: { ar: 'عطل', en: 'Fault', color: '#ff5252' },
  warning: { ar: 'تحذير', en: 'Warning', color: '#f5a623' },
  info: { ar: 'معلومة', en: 'Info', color: '#4dd8e6' },
};
