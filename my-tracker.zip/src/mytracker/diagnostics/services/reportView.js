/**
 * ReportView — تقرير التشخيص عبر نافذة طباعة (window.print → Save as PDF)
 * بدون أي مكتبة PDF. يدعم RTL والعربية، ويشمل كل الأقسام المطلوبة.
 * المشاركة عبر Web Share API مع fallback (تنزيل HTML / نسخ نص).
 */

import { STATUS_META, SEVERITY_META } from './analysisEngine';
import { SYSTEM_LABELS } from './dtcDatabase';

const esc = (s) =>
  String(s ?? '—').replace(
    /[&<>"]/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c],
  );

function buildReportHtml(session) {
  const statusMeta = STATUS_META[session.health?.status] || STATUS_META.insufficient;
  const dateStr = new Date(session.timestamp).toLocaleString('ar');
  const info = session.vehicleInfo || {};

  const dtcRows =
    (session.dtcsDetailed || [])
      .map(
        (d) => `
    <div class="dtc">
      <div class="dtc-head"><b>${esc(d.code)}</b>
        <span class="pill" style="background:${SEVERITY_META[d.severity]?.color}22;color:${SEVERITY_META[d.severity]?.color}">${SEVERITY_META[d.severity]?.ar || ''}</span>
        <span class="muted">${esc(SYSTEM_LABELS[d.system]?.ar)}</span>
        <span class="muted">${d.status === 'cleared' ? 'تم المسح' : 'مخزّن'}</span>
      </div>
      <p>${esc(d.desc)}</p>
      <p class="muted">الأسباب المحتملة: ${esc((d.causes || []).join(' • '))}</p>
      <p class="muted">الفحوصات المقترحة: ${esc((d.checks || []).join(' • '))}</p>
    </div>`,
      )
      .join('') || '<p class="muted">لا توجد رموز أعطال.</p>';

  const liveRows = session.liveSnapshot
    ? Object.values(session.liveSnapshot)
        .map(
          (v) =>
            `<tr><td>${esc(v.name?.ar || v.name)}</td><td>${esc(v.value)} ${esc(v.unit?.ar || v.unit || '')}</td></tr>`,
        )
        .join('')
    : '';

  const ffRows = session.freezeFrame
    ? Object.values(session.freezeFrame)
        .map(
          (v) =>
            `<tr><td>${esc(v.name?.ar || v.name)}</td><td>${esc(v.value)} ${esc(v.unit?.ar || v.unit || '')}</td></tr>`,
        )
        .join('')
    : '';

  return `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<title>تقرير تشخيص — ${esc(session.vehicleName || '')}</title>
<style>
  body{font-family:'Segoe UI',Tahoma,Arial,sans-serif;color:#1a2233;max-width:760px;margin:0 auto;padding:32px 24px;line-height:1.7}
  h1{font-size:22px;margin:0 0 4px}
  h2{font-size:16px;margin:28px 0 8px;border-bottom:2px solid #2f6bff;padding-bottom:4px;color:#0a1128}
  .brand{color:#2f6bff}
  .muted{color:#68728a;font-size:13px}
  table{width:100%;border-collapse:collapse;font-size:14px}
  td,th{border:1px solid #dde3ee;padding:6px 10px;text-align:right}
  .health{display:inline-block;padding:8px 18px;border-radius:12px;background:${statusMeta.color}18;color:${statusMeta.color};font-weight:700;font-size:18px}
  .dtc{border:1px solid #e4e9f2;border-radius:10px;padding:10px 14px;margin:8px 0}
  .dtc-head{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
  .pill{padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600}
  .footer{margin-top:36px;font-size:12px;color:#98a1b3;border-top:1px solid #e4e9f2;padding-top:10px}
  @media print{body{padding:0}}
</style></head><body>
  <h1>تقرير تشخيص المركبة <span class="brand">— MY TRACKER</span></h1>
  <p class="muted">${esc(dateStr)} · وضع الفحص: ${session.mode === 'test' ? 'TEST MODE (بيانات اختبارية)' : 'مركبة حقيقية'} · الاتصال: ${esc(session.connection?.deviceName || '—')}</p>

  <h2>معلومات المركبة</h2>
  <table>
    <tr><td>المركبة</td><td>${esc(session.vehicleName)}</td></tr>
    <tr><td>الشركة / الموديل</td><td>${esc(info.make)} / ${esc(info.model)}</td></tr>
    <tr><td>السنة</td><td>${esc(info.year)}</td></tr>
    <tr><td>المحرك</td><td>${esc(info.engine)}</td></tr>
    <tr><td>نوع الوقود</td><td>${esc(info.fuelType)}</td></tr>
    <tr><td>VIN</td><td>${esc(session.vin || info.vin)}</td></tr>
  </table>

  <h2>الحالة الصحية</h2>
  <span class="health">${session.health?.score != null ? `<bdi dir="ltr">${session.health.score} / 100</bdi>` : 'بيانات غير كافية'} — ${statusMeta.ar}</span>

  <h2>رموز الأعطال (DTC)</h2>
  ${dtcRows}

  ${ffRows ? `<h2>Freeze Frame</h2><table>${ffRows}</table>` : ''}
  ${liveRows ? `<h2>لقطة البيانات الحية</h2><table>${liveRows}</table>` : ''}

  ${session.clearResult ? `<h2>نتيجة مسح الأعطال</h2><p>${esc(session.clearResult.summary)}</p>` : ''}
  ${session.rescanResult ? `<h2>نتيجة إعادة الفحص</h2><p>${esc(session.rescanResult.summary)}</p>` : ''}

  <div class="footer">مسح رمز العطل لا يعني إصلاح سبب المشكلة — يُنصح بمعالجة السبب الجذري. · أُنشئ بواسطة MY TRACKER — Vehicle Diagnostics V1</div>
</body></html>`;
}

/** فتح نافذة طباعة بالتقرير (Save as PDF من المتصفح). */
export function openPrintableReport(session) {
  const html = buildReportHtml(session);
  const win = window.open('', '_blank');
  if (!win) return { ok: false, error: 'POPUP_BLOCKED' };
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => {
    try {
      win.print();
    } catch {
      /* المستخدم يطبع يدويًا */
    }
  }, 400);
  return { ok: true };
}

/** مشاركة ملخص نصي عبر Web Share API، مع fallback بالنسخ للحافظة. */
export async function shareReport(session) {
  const statusMeta = STATUS_META[session.health?.status] || STATUS_META.insufficient;
  const text = [
    `تقرير تشخيص — ${session.vehicleName || 'مركبة'} (MY TRACKER)`,
    `التاريخ: ${new Date(session.timestamp).toLocaleString('ar')}`,
    `VIN: ${session.vin || '—'}`,
    `الحالة: ${session.health?.score != null ? `${session.health.score}/100` : '—'} (${statusMeta.ar})`,
    `الأعطال: ${session.dtcsDetailed?.length ? session.dtcsDetailed.map((d) => d.code).join(', ') : 'لا يوجد'}`,
    session.mode === 'test' ? '⚠️ TEST MODE — بيانات اختبارية' : '',
    'ملاحظة: مسح رمز العطل لا يعني إصلاح سبب المشكلة.',
  ]
    .filter(Boolean)
    .join('\n');

  if (navigator.share) {
    try {
      await navigator.share({ title: 'تقرير تشخيص المركبة', text });
      return { ok: true, method: 'share' };
    } catch (err) {
      if (err?.name === 'AbortError') return { ok: false, error: 'CANCELLED' };
    }
  }
  try {
    await navigator.clipboard.writeText(text);
    return { ok: true, method: 'clipboard' };
  } catch {
    return { ok: false, error: 'SHARE_FAILED' };
  }
}
