import { DIAG_ERRORS } from '../services/diagnosticService';

/**
 * خريطة أكواد الأخطاء إلى رسائل عربية مفهومة: المشكلة + ما يمكن فعله.
 * لا تُعرض رسائل تقنية خام للمستخدم أبدًا.
 */
const ERROR_MESSAGES = {
  [DIAG_ERRORS.BLE_UNSUPPORTED_BROWSER]: {
    title: 'Bluetooth غير مدعوم في هذا المتصفح',
    hint: 'استخدم Chrome على Android أو Chrome/Edge على الحاسوب. Safari على iPhone لا يدعم Web Bluetooth حاليًا.',
  },
  [DIAG_ERRORS.SERIAL_UNSUPPORTED_BROWSER]: {
    title: 'اتصال USB غير مدعوم في هذا المتصفح',
    hint: 'اتصال USB متاح فقط في Chrome/Edge على الحاسوب. جرّب Bluetooth على الهاتف بدلًا منه.',
  },
  [DIAG_ERRORS.WIFI_NOT_SUPPORTED]: {
    title: 'أجهزة OBD عبر Wi-Fi غير مدعومة في نسخة الويب',
    hint: 'متصفحات الويب لا تسمح باتصال TCP مباشر الذي تحتاجه أجهزة Wi-Fi OBD. استخدم محول BLE أو USB، أو تطبيقًا أصليًا.',
  },
  [DIAG_ERRORS.BLE_CANCELLED]: {
    title: 'لم يتم اختيار جهاز',
    hint: 'أعد المحاولة واختر محول OBD من القائمة. تأكد أن المحول مُشغَّل ومرئي.',
  },
  [DIAG_ERRORS.SERIAL_CANCELLED]: {
    title: 'لم يتم اختيار منفذ USB',
    hint: 'أعد المحاولة واختر منفذ المحول من القائمة.',
  },
  [DIAG_ERRORS.CONNECT_FAILED]: {
    title: 'فشل الاتصال بالمحول',
    hint: 'تأكد أن المحول موصول بمنفذ OBD-II وبطارية المركبة تعمل، ثم أعد المحاولة.',
  },
  [DIAG_ERRORS.UNSUPPORTED_DEVICE]: {
    title: 'جهاز غير متوافق',
    hint: 'تم الاتصال بالجهاز لكن لم يُعثر على قناة OBD صالحة فيه. تأكد أنه محول ELM327 متوافق مع BLE.',
  },
  [DIAG_ERRORS.UNABLE_TO_CONNECT]: {
    title: 'المحول لا يستطيع الوصول لوحدة ECU',
    hint: 'شغّل المحرك (أو ضع المفتاح في وضع ON)، وتأكد أن المركبة تدعم OBD-II، ثم أعد الفحص.',
  },
  [DIAG_ERRORS.NO_DATA]: {
    title: 'لا توجد استجابة من وحدة ECU',
    hint: 'المركبة قد لا تدعم OBD-II القياسي أو البروتوكول غير مدعوم. جرّب مع المحرك يعمل.',
  },
  [DIAG_ERRORS.TIMEOUT]: {
    title: 'انتهت مهلة الاتصال',
    hint: 'استجابة المحول بطيئة جدًا. قرّب الهاتف من المحول وتأكد من ثبات الاتصال، ثم أعد المحاولة.',
  },
  [DIAG_ERRORS.NOT_CONNECTED]: {
    title: 'المحول غير متصل',
    hint: 'انقطع الاتصال بمحول OBD. أعد الاتصال ثم تابع الفحص.',
  },
  [DIAG_ERRORS.DISCONNECTED]: {
    title: 'انقطع الاتصال',
    hint: 'فُقد الاتصال بالمحول أثناء العملية. أعد الاتصال وأعد الفحص.',
  },
};

export function describeError(code) {
  return (
    ERROR_MESSAGES[code] || {
      title: 'حدث خطأ غير متوقع',
      hint: 'أعد المحاولة. إذا استمرت المشكلة، افصل المحول ووصله من جديد.',
    }
  );
}
