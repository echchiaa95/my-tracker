import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Typography, Collapse } from '@mui/material';
import {
  DiagPage,
  GlassCard,
  MutedText,
  GhostButton,
  DiagHeader,
  EmptyState,
  StatusPill,
  injectDiagStyles,
  DIAG_COLORS,
} from '../components/diagUi';
import { BackIcon, TrashIcon, ReportIcon, ShareIcon, ChevronIcon } from '../components/DiagIcons';
import { HealthGauge, DtcCard, LiveDataGrid } from '../components/DiagWidgets';
import { STATUS_META } from '../services/analysisEngine';
import historyStore from '../services/historyStore';
import { openPrintableReport, shareReport } from '../services/reportView';

/** بطاقة جلسة فحص واحدة في السجل — تنفتح لعرض التفاصيل والتقرير. */
const SessionCard = ({ session, onDelete }) => {
  const [open, setOpen] = useState(false);
  const [notice, setNotice] = useState(null);
  const meta = STATUS_META[session.health?.status] || STATUS_META.insufficient;

  const handleShare = async (e) => {
    e.stopPropagation();
    const r = await shareReport(session);
    if (r.ok && r.method === 'clipboard') setNotice('تم نسخ الملخص');
  };

  return (
    <GlassCard onClick={() => setOpen((v) => !v)}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4 }}>
        <Box sx={{ width: 54, height: 54, flexShrink: 0 }}>
          <HealthGauge
            score={session.health?.score}
            status={session.health?.status}
            size={54}
            showLabel={false}
          />
        </Box>
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Typography sx={{ fontWeight: 700, fontSize: 14.5 }}>
            {session.vehicleName || 'مركبة'}
          </Typography>
          <MutedText sx={{ fontSize: 12 }}>
            {new Date(session.timestamp).toLocaleString('ar')}
          </MutedText>
          <Box sx={{ display: 'flex', gap: 0.8, mt: 0.5, flexWrap: 'wrap' }}>
            <StatusPill label={meta.ar} color={meta.color} />
            {session.mode === 'test' && <StatusPill label="TEST MODE" color={DIAG_COLORS.amber} />}
          </Box>
        </Box>
        <ChevronIcon
          sx={{
            color: DIAG_COLORS.muted,
            transform: open ? 'rotate(90deg)' : 'none',
            transition: 'transform .2s',
          }}
        />
      </Box>

      <Collapse in={open}>
        <Box
          sx={{ mt: 1.5, borderTop: `1px solid ${DIAG_COLORS.cardBorder}`, pt: 1.5 }}
          onClick={(e) => e.stopPropagation()}
        >
          <MutedText sx={{ fontSize: 12.5, mb: 1 }}>
            VIN: {session.vin || '—'} · الاتصال: {session.connection?.deviceName || '—'}
          </MutedText>

          {session.dtcsDetailed?.length > 0 && (
            <>
              <Typography sx={{ fontSize: 13, fontWeight: 700, mb: 0.8 }}>رموز الأعطال</Typography>
              {session.dtcsDetailed.map((d) => (
                <DtcCard key={d.code} dtc={d} />
              ))}
            </>
          )}

          {session.clearResult && (
            <MutedText sx={{ fontSize: 12.5, mt: 0.8 }}>
              مسح الأعطال: {session.clearResult.summary}
            </MutedText>
          )}
          {session.rescanResult && (
            <MutedText sx={{ fontSize: 12.5 }}>
              إعادة الفحص: {session.rescanResult.summary}
            </MutedText>
          )}

          {session.liveSnapshot && Object.keys(session.liveSnapshot).length > 0 && (
            <>
              <Typography sx={{ fontSize: 13, fontWeight: 700, my: 0.8 }}>
                لقطة البيانات الحية
              </Typography>
              <LiveDataGrid liveData={session.liveSnapshot} />
            </>
          )}

          {session.freezeFrame && (
            <>
              <Typography sx={{ fontSize: 13, fontWeight: 700, my: 0.8 }}>Freeze Frame</Typography>
              <LiveDataGrid liveData={session.freezeFrame} />
            </>
          )}

          <Box sx={{ display: 'flex', gap: 1, mt: 1.5 }}>
            <GhostButton startIcon={<ReportIcon />} onClick={() => openPrintableReport(session)}>
              PDF
            </GhostButton>
            <GhostButton startIcon={<ShareIcon />} onClick={handleShare}>
              مشاركة
            </GhostButton>
            <GhostButton danger startIcon={<TrashIcon />} onClick={() => onDelete(session.id)}>
              حذف
            </GhostButton>
          </Box>
          {notice && (
            <MutedText sx={{ textAlign: 'center', mt: 0.8, color: DIAG_COLORS.cyan }}>
              {notice}
            </MutedText>
          )}
        </Box>
      </Collapse>
    </GlassCard>
  );
};

/** DiagnosticHistoryPage — سجل جلسات التشخيص المحفوظة محليًا. */
const DiagnosticHistoryPage = () => {
  injectDiagStyles();
  const navigate = useNavigate();
  const [sessions, setSessions] = useState(historyStore.list());

  const handleDelete = (id) => {
    historyStore.remove(id);
    setSessions(historyStore.list());
  };

  return (
    <DiagPage>
      <DiagHeader
        title="سجل الفحوصات"
        subtitle={sessions.length ? `${sessions.length} فحص محفوظ` : undefined}
        onBack={() => navigate('/diagnostics')}
        backIcon={<BackIcon />}
      />
      {sessions.length === 0 ? (
        <EmptyState
          icon={<ReportIcon />}
          title="لا توجد فحوصات محفوظة"
          hint="نتائج الفحوصات التي تجريها ستظهر هنا"
        />
      ) : (
        sessions.map((s) => <SessionCard key={s.id} session={s} onDelete={handleDelete} />)
      )}
    </DiagPage>
  );
};

export default DiagnosticHistoryPage;
