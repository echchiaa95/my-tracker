import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Box, Typography } from '@mui/material';
import {
  DiagPage,
  GlassCard,
  SectionTitle,
  MutedText,
  PrimaryButton,
  StatusPill,
  TestModeBanner,
  DiagHeader,
  EmptyState,
  injectDiagStyles,
  DIAG_COLORS,
} from '../components/diagUi';
import {
  DiagPulseIcon,
  HistoryIcon,
  LinkIcon,
  ChevronIcon,
  BluetoothIcon,
  FlaskIcon,
} from '../components/DiagIcons';
import { HealthGauge } from '../components/DiagWidgets';
import diagnosticService from '../services/diagnosticService';
import historyStore from '../services/historyStore';

/**
 * Diagnostic Dashboard — نقطة دخول Vehicle Diagnostics V1:
 * فحص جديد / آخر نتيجة / السجل / حالة الاتصال. المعلومات المهمة ظاهرة فورًا.
 */
const DiagnosticsDashboard = () => {
  injectDiagStyles();
  const navigate = useNavigate();
  const [conn, setConn] = useState(() => diagnosticService.snapshot());
  // تُقرأ عند التركيب — الصفحة تُعاد تركيبها عند كل تنقّل إليها
  const sessions = historyStore.list();
  const devices = useSelector((state) => Object.values(state.devices.items));

  useEffect(() => diagnosticService.subscribe(setConn), []);

  const last = sessions[0] || null;
  const vehicleName = useMemo(() => {
    if (!last) return null;
    const d = devices.find((x) => x.id === last.vehicleId);
    return d?.name || last.vehicleName || 'مركبة';
  }, [last, devices]);

  return (
    <DiagPage>
      <DiagHeader title="تشخيص المركبة" subtitle="Vehicle Diagnostics" />

      {conn.mode === 'test' && conn.connected && <TestModeBanner />}

      {/* حالة الاتصال */}
      <GlassCard>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4 }}>
          <Box sx={{ color: conn.connected ? DIAG_COLORS.green : DIAG_COLORS.muted }}>
            <LinkIcon />
          </Box>
          <Box sx={{ flex: 1 }}>
            <Typography sx={{ fontWeight: 700, fontSize: 15 }}>
              {conn.connected ? 'محول OBD متصل' : 'لا يوجد اتصال بمحول OBD'}
            </Typography>
            <MutedText sx={{ fontSize: 12.5 }}>
              {conn.connected ? conn.deviceName : 'صل محول OBD-II بالمركبة ثم ابدأ فحصًا جديدًا'}
            </MutedText>
          </Box>
          <StatusPill
            label={conn.connected ? 'متصل' : 'غير متصل'}
            color={conn.connected ? DIAG_COLORS.green : DIAG_COLORS.muted}
          />
        </Box>
      </GlassCard>

      {/* فحص جديد */}
      <GlassCard sx={{ mt: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4, mb: 1.5 }}>
          <Box
            sx={{
              width: 46,
              height: 46,
              borderRadius: 3,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: 'linear-gradient(135deg, rgba(47,107,255,.25), rgba(77,216,230,.18))',
              color: DIAG_COLORS.cyan,
            }}
          >
            <DiagPulseIcon />
          </Box>
          <Box>
            <Typography sx={{ fontWeight: 800, fontSize: 16 }}>فحص جديد</Typography>
            <MutedText sx={{ fontSize: 12.5 }}>قراءة الأعطال والبيانات الحية عبر OBD-II</MutedText>
          </Box>
        </Box>
        <PrimaryButton onClick={() => navigate('/diagnostics/scan')} startIcon={<DiagPulseIcon />}>
          بدء فحص جديد
        </PrimaryButton>
      </GlassCard>

      {/* آخر نتيجة */}
      <SectionTitle>آخر نتيجة</SectionTitle>
      {last ? (
        <GlassCard onClick={() => navigate('/diagnostics/history')}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <HealthGauge score={last.health?.score} status={last.health?.status} />
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontWeight: 700, fontSize: 15 }}>{vehicleName}</Typography>
              <MutedText sx={{ fontSize: 12.5 }}>
                {new Date(last.timestamp).toLocaleString('ar')}
              </MutedText>
              <MutedText sx={{ fontSize: 12.5 }}>
                {last.dtcsDetailed?.length
                  ? `${last.dtcsDetailed.length} رمز عطل: ${last.dtcsDetailed.map((d) => d.code).join('، ')}`
                  : 'لا توجد أعطال مخزنة'}
              </MutedText>
              {last.mode === 'test' && (
                <Box sx={{ mt: 0.6 }}>
                  <StatusPill label="TEST MODE" color={DIAG_COLORS.amber} />
                </Box>
              )}
            </Box>
            <ChevronIcon sx={{ color: DIAG_COLORS.muted }} />
          </Box>
        </GlassCard>
      ) : (
        <EmptyState
          icon={<DiagPulseIcon />}
          title="لا توجد نتائج بعد"
          hint="ابدأ أول فحص لمركبتك وستظهر النتيجة هنا"
        />
      )}

      {/* السجل */}
      <SectionTitle>سجل الفحوصات</SectionTitle>
      <GlassCard onClick={() => navigate('/diagnostics/history')}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4 }}>
          <Box sx={{ color: DIAG_COLORS.blue }}>
            <HistoryIcon />
          </Box>
          <Box sx={{ flex: 1 }}>
            <Typography sx={{ fontWeight: 700, fontSize: 15 }}>
              {sessions.length ? `${sessions.length} فحص محفوظ` : 'السجل فارغ'}
            </Typography>
            <MutedText sx={{ fontSize: 12.5 }}>عرض النتائج السابقة وإنشاء التقارير</MutedText>
          </Box>
          <ChevronIcon sx={{ color: DIAG_COLORS.muted }} />
        </Box>
      </GlassCard>

      {/* معلومة التوافق */}
      <GlassCard sx={{ mt: 2.5, borderStyle: 'dashed' }}>
        <Box sx={{ display: 'flex', gap: 1.2, alignItems: 'flex-start' }}>
          <BluetoothIcon sx={{ color: DIAG_COLORS.muted, fontSize: 20, mt: 0.2 }} />
          <MutedText sx={{ fontSize: 12 }}>
            يعمل الفحص مع محولات ELM327 المتوافقة عبر Bluetooth (BLE) أو USB حسب دعم متصفحك. أجهزة
            Bluetooth الكلاسيكية وWi-Fi OBD غير مدعومة في نسخة الويب حاليًا. وضع{' '}
            <FlaskIcon sx={{ fontSize: 14, verticalAlign: '-2px' }} /> التجريبي متاح للتجربة بدون
            محول.
          </MutedText>
        </Box>
      </GlassCard>
    </DiagPage>
  );
};

export default DiagnosticsDashboard;
