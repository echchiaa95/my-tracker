import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Box, Typography, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import {
  DiagPage,
  GlassCard,
  SectionTitle,
  MutedText,
  PrimaryButton,
  GhostButton,
  TestModeBanner,
  DiagHeader,
  EmptyState,
  ErrorCard,
  injectDiagStyles,
  DIAG_COLORS,
} from '../components/diagUi';
import {
  DiagCarIcon,
  BluetoothIcon,
  UsbIcon,
  WifiOffIcon,
  FlaskIcon,
  BackIcon,
  ClearIcon,
  RescanIcon,
  ReportIcon,
  ShareIcon,
  CheckIcon,
} from '../components/DiagIcons';
import { HealthGauge, DtcCard, LiveDataGrid, ScanStepRow } from '../components/DiagWidgets';
import diagnosticService from '../services/diagnosticService';
import { analyze } from '../services/analysisEngine';
import historyStore from '../services/historyStore';
import { openPrintableReport, shareReport } from '../services/reportView';
import { describeError } from '../services/errorMessages';
import storageService from '../../services/storageService';

const SCAN_STEPS = [
  { key: 'init', label: 'تهيئة المحول والتحقق من وحدة ECU' },
  { key: 'vin', label: 'قراءة رقم الهيكل (VIN)' },
  { key: 'supported', label: 'اكتشاف القدرات المدعومة (PIDs)' },
  { key: 'dtc', label: 'فحص رموز الأعطال (DTC)' },
  { key: 'freeze', label: 'قراءة Freeze Frame' },
  { key: 'live', label: 'قراءة البيانات الحية' },
];

const initialSteps = () => Object.fromEntries(SCAN_STEPS.map((s) => [s.key, 'pending']));

/** معلومات المركبة من بيانات Traccar الموجودة — الحقول الناقصة تبقى '—'. */
function extractVehicleInfo(device) {
  const a = device?.attributes || {};
  return {
    make: a.make || '—',
    model: a.model || '—',
    year: a.year || '—',
    engine: a.engine || '—',
    fuelType: a.fuelType || a.fuel || '—',
    vin: a.vin || null,
  };
}

/**
 * DiagnosticScanPage — رحلة الفحص الكاملة:
 * Select Vehicle → Compatibility/Connect → Scan (بخطوات مرئية) → Result.
 */
const DiagnosticScanPage = () => {
  injectDiagStyles();
  const navigate = useNavigate();
  const devices = useSelector((state) => Object.values(state.devices.items));
  const customNames = storageService.getState().vehicles || {};

  const [phase, setPhase] = useState('select'); // select | connect | scanning | result
  const [vehicle, setVehicle] = useState(null);
  const [conn, setConn] = useState(() => diagnosticService.snapshot());
  const [steps, setSteps] = useState(initialSteps);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null); // { analysis, raw, sessionId }
  const [clearDialog, setClearDialog] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [clearOutcome, setClearOutcome] = useState(null); // {status, summary}
  const [notice, setNotice] = useState(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    const unsub = diagnosticService.subscribe((s) => {
      if (mountedRef.current) setConn(s);
    });
    return () => {
      mountedRef.current = false;
      unsub();
      diagnosticService.disconnect(); // مغادرة الصفحة = إنهاء جلسة OBD
    };
  }, []);

  const compat = useMemo(() => diagnosticService.checkCompatibility(), []);

  const vehicleDisplayName = (d) => customNames[d.id]?.customName || d.name;

  /* ---------- اختيار المركبة ---------- */
  const pickVehicle = (d) => {
    setVehicle(d);
    setError(null);
    setPhase('connect');
  };

  /* ---------- الاتصال ---------- */
  const connect = async (type) => {
    setError(null);
    const r = await diagnosticService.connect(type);
    if (!r.ok) {
      if (r.error === 'BLE_CANCELLED' || r.error === 'SERIAL_CANCELLED') return; // إلغاء المستخدم
      setError(r.error);
      return;
    }
    startScan();
  };

  /* ---------- الفحص ---------- */
  const startScan = async () => {
    setPhase('scanning');
    setSteps(initialSteps());
    setError(null);
    try {
      const raw = await diagnosticService.scan((key, status) => {
        if (mountedRef.current) setSteps((prev) => ({ ...prev, [key]: status }));
      });
      const analysis = analyze(raw);
      const info = extractVehicleInfo(vehicle);
      const session = historyStore.save({
        vehicleId: vehicle.id,
        vehicleName: vehicleDisplayName(vehicle),
        vehicleInfo: { ...info, vin: raw.vin || info.vin },
        mode: diagnosticService.mode,
        vin: raw.vin || info.vin || null,
        dtcsDetailed: analysis.dtcsDetailed,
        health: { score: analysis.score, status: analysis.status },
        liveSnapshot: raw.liveData,
        freezeFrame: raw.freezeFrame,
        connection: {
          type: diagnosticService.adapter?.type,
          deviceName: diagnosticService.deviceName,
        },
      });
      if (!mountedRef.current) return;
      setResult({ analysis, raw, sessionId: session.id });
      setPhase('result');
    } catch (err) {
      if (!mountedRef.current) return;
      setSteps((prev) => {
        const next = { ...prev };
        const active = Object.keys(next).find((k) => next[k] === 'active');
        if (active) next[active] = 'error';
        return next;
      });
      setError(err?.message || 'UNKNOWN');
    }
  };

  /* ---------- مسح الأعطال + إعادة فحص ومقارنة ---------- */
  const handleClear = async () => {
    setClearDialog(false);
    setClearing(true);
    setClearOutcome(null);
    const before = result.raw.dtcs;
    try {
      const cleared = await diagnosticService.clearDTC();
      if (!cleared) {
        setClearOutcome({
          status: 'failed',
          summary: 'رفضت وحدة ECU طلب المسح — العملية غير مدعومة أو تعذّرت',
        });
      } else {
        // إعادة فحص للمقارنة: هل عادت الرموز؟
        const after = await diagnosticService.readDTC();
        const returned = after.filter((c) => before.includes(c));
        const gone = before.filter((c) => !after.includes(c));
        if (after.length === 0) {
          setClearOutcome({
            status: 'cleared',
            summary: `تم مسح ${before.length} رمز بنجاح. تنبيه: مسح رمز العطل لا يعني إصلاح سبب المشكلة — قد يعود الرمز إذا استمر السبب.`,
          });
        } else if (returned.length) {
          setClearOutcome({
            status: 'returned',
            summary: `عادت ${returned.length} رموز بعد إعادة الفحص فورًا (${returned.join('، ')}) — السبب الجذري ما زال قائمًا ويحتاج إصلاحًا.`,
          });
        } else {
          setClearOutcome({
            status: 'cleared',
            summary: `تم مسح ${gone.length} رمز، وبقيت ${after.length} رموز جديدة/ثابتة (${after.join('، ')})`,
          });
        }
        // تحديث النتيجة المعروضة والجلسة المحفوظة
        const newAnalysis = analyze({
          dtcs: after,
          liveData: result.raw.liveData,
          freezeFrame: result.raw.freezeFrame,
        });
        setResult((prev) => ({
          ...prev,
          raw: { ...prev.raw, dtcs: after },
          analysis: newAnalysis,
        }));
        historyStore.update(result.sessionId, {
          dtcsDetailed: newAnalysis.dtcsDetailed,
          health: { score: newAnalysis.score, status: newAnalysis.status },
          clearResult: { status: 'cleared', summary: 'تم تنفيذ المسح' },
          rescanResult: {
            status: returned.length ? 'returned' : 'clean',
            summary: returned.length ? `عادت: ${returned.join('، ')}` : 'لا رموز بعد إعادة الفحص',
          },
        });
      }
    } catch (err) {
      setClearOutcome({ status: 'unsupported', summary: describeError(err?.message).title });
    } finally {
      setClearing(false);
    }
  };

  /* ---------- مشاركة / تقرير ---------- */
  const currentSession = () =>
    historyStore.getById(result.sessionId) || {
      ...result.raw,
      vehicleName: vehicleDisplayName(vehicle),
      timestamp: Date.now(),
      health: { score: result.analysis.score, status: result.analysis.status },
      dtcsDetailed: result.analysis.dtcsDetailed,
      vehicleInfo: extractVehicleInfo(vehicle),
      mode: diagnosticService.mode,
    };

  const handleShare = async () => {
    const r = await shareReport(currentSession());
    if (r.ok && r.method === 'clipboard')
      setNotice('تم نسخ ملخص التقرير — المشاركة المباشرة غير متاحة في هذا المتصفح');
    else if (!r.ok && r.error !== 'CANCELLED') setNotice('تعذّرت المشاركة');
  };

  const handleReport = () => {
    const r = openPrintableReport(currentSession());
    if (!r.ok) setNotice('المتصفح منع نافذة الطباعة — اسمح بالنوافذ المنبثقة ثم أعد المحاولة');
  };

  /* ================= العرض ================= */

  const renderSelect = () => (
    <>
      <SectionTitle>اختر المركبة</SectionTitle>
      {devices.length === 0 ? (
        <EmptyState
          icon={<DiagCarIcon />}
          title="لا توجد مركبات"
          hint="أضف مركبة من شاشة المركبات أولًا ثم عد هنا"
        />
      ) : (
        devices.map((d) => (
          <GlassCard key={d.id} onClick={() => pickVehicle(d)}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4 }}>
              <Box
                sx={{
                  width: 44,
                  height: 44,
                  borderRadius: 2.5,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  background: 'rgba(47,107,255,.16)',
                  color: DIAG_COLORS.cyan,
                  flexShrink: 0,
                }}
              >
                <DiagCarIcon />
              </Box>
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography sx={{ fontWeight: 700, fontSize: 15 }}>
                  {vehicleDisplayName(d)}
                </Typography>
                <MutedText sx={{ fontSize: 12 }}>
                  {[d.attributes?.make, d.attributes?.model, d.attributes?.year]
                    .filter(Boolean)
                    .join(' · ') || d.uniqueId}
                </MutedText>
              </Box>
            </Box>
          </GlassCard>
        ))
      )}
    </>
  );

  const renderConnect = () => {
    const info = extractVehicleInfo(vehicle);
    return (
      <>
        <GlassCard>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4 }}>
            <Box sx={{ color: DIAG_COLORS.cyan }}>
              <DiagCarIcon fontSize="large" />
            </Box>
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontWeight: 800, fontSize: 16 }}>
                {vehicleDisplayName(vehicle)}
              </Typography>
              <MutedText sx={{ fontSize: 12.5 }}>
                {`الشركة: ${info.make} · الموديل: ${info.model} · السنة: ${info.year}`}
              </MutedText>
              <MutedText sx={{ fontSize: 12.5 }}>
                {`المحرك: ${info.engine} · الوقود: ${info.fuelType}`}
              </MutedText>
              <MutedText sx={{ fontSize: 12.5 }}>
                {info.vin ? `VIN: ${info.vin}` : 'VIN: سيُقرأ تلقائيًا من المركبة إن أمكن'}
              </MutedText>
            </Box>
          </Box>
        </GlassCard>

        <SectionTitle>طريقة الاتصال بمحول OBD</SectionTitle>

        <GlassCard sx={{ mb: 1 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            <PrimaryButton
              startIcon={<BluetoothIcon />}
              disabled={!compat.ble}
              onClick={() => connect('ble')}
            >
              Bluetooth (BLE){!compat.ble ? ' — غير مدعوم هنا' : ''}
            </PrimaryButton>
            <GhostButton
              startIcon={<UsbIcon />}
              disabled={!compat.serial}
              onClick={() => connect('serial')}
            >
              USB (Serial){!compat.serial ? ' — الحاسوب فقط' : ''}
            </GhostButton>
            <GhostButton startIcon={<WifiOffIcon />} disabled>
              Wi-Fi OBD — غير متاح في نسخة الويب
            </GhostButton>
          </Box>
          {!compat.ble && !compat.serial && (
            <MutedText sx={{ mt: 1.2, fontSize: 12, color: DIAG_COLORS.amber }}>
              هذا المتصفح لا يدعم اتصال OBD المباشر (Web Bluetooth / Web Serial). استخدم Chrome على
              Android أو Chrome/Edge على الحاسوب — أو جرّب الوضع التجريبي أدناه.
            </MutedText>
          )}
          {conn.state === 'connecting' && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2, mt: 1.4 }}>
              <Box className="dg-spinner" />
              <MutedText>جاري الاتصال بالمحول… اختر الجهاز من نافذة المتصفح</MutedText>
            </Box>
          )}
        </GlassCard>

        {error && <ErrorCard title={describeError(error).title} hint={describeError(error).hint} />}

        <GlassCard sx={{ borderStyle: 'dashed', textAlign: 'center' }}>
          <MutedText sx={{ mb: 1 }}>بدون محول؟ جرّب التجربة الكاملة ببيانات اختبارية</MutedText>
          <GhostButton startIcon={<FlaskIcon />} onClick={() => connect('mock')}>
            وضع التجربة (TEST MODE)
          </GhostButton>
        </GlassCard>

        <GhostButton
          onClick={() => {
            setPhase('select');
            setError(null);
          }}
        >
          تغيير المركبة
        </GhostButton>
      </>
    );
  };

  const renderScanning = () => (
    <>
      <SectionTitle>{error ? 'توقف الفحص' : 'جاري الفحص…'}</SectionTitle>
      <GlassCard>
        {SCAN_STEPS.map((s) => (
          <ScanStepRow key={s.key} label={s.label} status={steps[s.key]} />
        ))}
      </GlassCard>
      {error && (
        <>
          <ErrorCard title={describeError(error).title} hint={describeError(error).hint} />
          <Box sx={{ mt: 1 }}>
            <PrimaryButton startIcon={<RescanIcon />} onClick={() => setPhase('connect')}>
              إعادة المحاولة
            </PrimaryButton>
          </Box>
        </>
      )}
    </>
  );

  const renderResult = () => {
    const { analysis, raw } = result;
    return (
      <>
        {/* النتيجة الصحية */}
        <GlassCard sx={{ textAlign: 'center' }}>
          <HealthGauge score={analysis.score} status={analysis.status} />
          <MutedText>{analysis.summary}</MutedText>
          {raw.vin && <MutedText sx={{ fontSize: 12, mt: 0.5 }}>VIN: {raw.vin}</MutedText>}
        </GlassCard>

        {/* نتيجة المسح/إعادة الفحص */}
        {clearOutcome && (
          <GlassCard
            sx={{
              borderColor:
                clearOutcome.status === 'cleared' ? 'rgba(46,204,113,.4)' : 'rgba(245,166,35,.4)',
            }}
          >
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
              <Box
                sx={{
                  color: clearOutcome.status === 'cleared' ? DIAG_COLORS.green : DIAG_COLORS.amber,
                  mt: 0.2,
                }}
              >
                {clearOutcome.status === 'cleared' ? (
                  <CheckIcon fontSize="small" />
                ) : (
                  <RescanIcon fontSize="small" />
                )}
              </Box>
              <MutedText sx={{ flex: 1 }}>{clearOutcome.summary}</MutedText>
            </Box>
          </GlassCard>
        )}

        {/* رموز الأعطال */}
        <SectionTitle>رموز الأعطال ({analysis.dtcsDetailed.length})</SectionTitle>
        {analysis.dtcsDetailed.length === 0 ? (
          <GlassCard>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
              <CheckIcon sx={{ color: DIAG_COLORS.green }} />
              <Typography sx={{ fontWeight: 700, fontSize: 14.5 }}>
                لا توجد رموز أعطال مخزنة
              </Typography>
            </Box>
          </GlassCard>
        ) : (
          <>
            {analysis.dtcsDetailed.map((d) => (
              <DtcCard key={d.code} dtc={d} />
            ))}
            <GhostButton
              danger
              startIcon={<ClearIcon />}
              disabled={clearing}
              onClick={() => setClearDialog(true)}
            >
              {clearing ? 'جاري المسح وإعادة الفحص…' : 'مسح رموز الأعطال'}
            </GhostButton>
            <MutedText sx={{ fontSize: 11.5, mt: 0.6, textAlign: 'center' }}>
              مسح رمز العطل لا يعني إصلاح سبب المشكلة
            </MutedText>
          </>
        )}

        {/* البيانات الحية */}
        <SectionTitle>البيانات الحية</SectionTitle>
        <GlassCard>
          <LiveDataGrid liveData={raw.liveData} />
        </GlassCard>

        {/* Freeze Frame */}
        {raw.freezeFrame && (
          <>
            <SectionTitle>Freeze Frame</SectionTitle>
            <GlassCard>
              <LiveDataGrid liveData={raw.freezeFrame} />
            </GlassCard>
          </>
        )}

        {/* الإجراءات */}
        <SectionTitle>التقرير</SectionTitle>
        <Box sx={{ display: 'flex', gap: 1, mb: 1 }}>
          <PrimaryButton startIcon={<ReportIcon />} onClick={handleReport}>
            تحميل PDF
          </PrimaryButton>
          <GhostButton startIcon={<ShareIcon />} onClick={handleShare}>
            مشاركة
          </GhostButton>
        </Box>
        {notice && (
          <MutedText sx={{ textAlign: 'center', color: DIAG_COLORS.cyan, mb: 1 }}>
            {notice}
          </MutedText>
        )}

        <GhostButton startIcon={<RescanIcon />} onClick={startScan} sx={{ mb: 1 }}>
          إعادة الفحص
        </GhostButton>
        <GhostButton onClick={() => navigate('/diagnostics')}>العودة للوحة التشخيص</GhostButton>

        {/* تأكيد المسح */}
        <Dialog
          open={clearDialog}
          onClose={() => setClearDialog(false)}
          PaperProps={{
            sx: { background: DIAG_COLORS.bg1, color: DIAG_COLORS.text, borderRadius: 3, mx: 2 },
          }}
        >
          <DialogTitle sx={{ fontWeight: 800, fontSize: 17 }}>تأكيد مسح رموز الأعطال</DialogTitle>
          <DialogContent>
            <MutedText>
              سيتم مسح {analysis.dtcsDetailed.length} رمز عطل من وحدة ECU ثم إعادة الفحص للمقارنة.
              <br />
              <br />
              تنبيه مهم: مسح رمز العطل لا يعني إصلاح سبب المشكلة — قد تعود الرموز إذا استمر العطل
              الفعلي.
            </MutedText>
          </DialogContent>
          <DialogActions sx={{ p: 2, gap: 1 }}>
            <GhostButton onClick={() => setClearDialog(false)}>إلغاء</GhostButton>
            <PrimaryButton color={DIAG_COLORS.red} onClick={handleClear}>
              تأكيد المسح
            </PrimaryButton>
          </DialogActions>
        </Dialog>
      </>
    );
  };

  const titles = {
    select: ['فحص جديد', 'اختر المركبة المراد فحصها'],
    connect: ['الاتصال', vehicle ? vehicleDisplayName(vehicle) : ''],
    scanning: ['الفحص', vehicle ? vehicleDisplayName(vehicle) : ''],
    result: ['نتيجة الفحص', vehicle ? vehicleDisplayName(vehicle) : ''],
  };

  return (
    <DiagPage>
      {conn.mode === 'test' && <TestModeBanner />}
      <DiagHeader
        title={titles[phase][0]}
        subtitle={titles[phase][1]}
        onBack={() => navigate('/diagnostics')}
        backIcon={<BackIcon />}
      />
      {phase === 'select' && renderSelect()}
      {phase === 'connect' && renderConnect()}
      {phase === 'scanning' && renderScanning()}
      {phase === 'result' && renderResult()}
    </DiagPage>
  );
};

export default DiagnosticScanPage;
