# نشر My Tracker من الهاتف عبر GitHub فقط (بدون رفع ملفات يدويًا)

## الخطوات

1. أنشئ Repository جديد فارغ على GitHub (يمكن Public أو Private — Pages تعمل مع كليهما إذا كان لديك خطة تدعم ذلك؛ Public أبسط).
2. من صفحة الريبو: **Add file → Upload files**، وارفع **my-tracker.zip فقط** (هذا الملف بالضبط، دون فك ضغطه).
3. Commit مباشرة على الفرع الرئيسي (main).
4. من **Settings → Pages → Build and deployment → Source**: اختر **GitHub Actions** (مرة واحدة فقط، لا يمكن أتمتة هذه الخطوة من ملف workflow لأسباب أمان GitHub نفسه).
5. اذهب إلى تبويب **Actions** — سيبدأ workflow باسم **"Deploy My Tracker (from zip) to GitHub Pages"** تلقائيًا. انتظر حتى تظهر علامة ✅ خضراء على كلا العمل (build ثم deploy).
6. رابط تطبيقك سيظهر في نفس صفحة الـrun تحت خطوة deploy، أو من Settings → Pages مباشرة. الشكل المتوقع:
   `https://<username>.github.io/<repo-name>/`

## عند أي تعديل لاحق

كرّر فقط: ارفع ملف `my-tracker.zip` جديدًا (نفس الاسم) → Commit → الـworkflow يعيد البناء والنشر تلقائيًا من جديد. لا حاجة لأي خطوة يدوية أخرى بعد الإعداد الأول في الخطوة 4.

## ماذا يفعل الـworkflow تلقائيًا

- يفكّ ضغط `my-tracker.zip` (يتعامل تلقائيًا سواء كان المشروع داخل مجلد `my-tracker/` أو على الجذر مباشرة).
- `npm ci` ثم `npm run build`.
- يحسب مسار `base` الصحيح تلقائيًا حسب اسم الريبو (`/repo-name/`)، أو `/` إذا كان اسم الريبو بصيغة `username.github.io`.
- يضيف `.nojekyll` و`404.html` (ضروريان لعمل الروابط الداخلية على GitHub Pages بشكل صحيح).
- ينشر مجلد `build/` الناتج على GitHub Pages.

## إذا فشل الـworkflow

افتح الـrun الأحمر ❌ في تبويب Actions، وابحث عن أول رسالة `::error::` — الرسائل مكتوبة لتوضّح السبب مباشرة (مثال: لم يُعثر على `my-tracker.zip`، أو فشل `npm run build` — راجع سجل تلك الخطوة تحديدًا).

## تنبيه مهم يبقى قائمًا (غير متعلق بـGitHub Actions)

حتى مع نجاح النشر، الاتصال الفعلي بـTraccar Server لن يعمل إلا إذا كان السيرفر معدًّا لقبول CORS من دومين GitHub Pages الخاص بك (`https://<username>.github.io`)، عبر HTTPS، مع كوكيز `Secure; SameSite=None`. هذا إعداد على سيرفر Traccar نفسه، لا علاقة له بملفات هذا المشروع.
