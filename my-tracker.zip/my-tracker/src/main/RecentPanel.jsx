import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  List,
  ListItemButton,
  ListItemText,
  Typography,
  Box,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import dayjs from 'dayjs';
import { formatNotificationTitle, formatTime } from '../common/util/formatter';
import { useTranslation } from '../common/components/LocalizationProvider';
import { devicesActions } from '../store';

const useStyles = makeStyles()((theme) => ({
  accordion: {
    boxShadow: 'none',
    '&:before': { display: 'none' },
    borderBottom: `1px solid ${theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.08)' : 'rgba(15,23,32,0.08)'}`,
  },
  summary: {
    minHeight: 40,
    '& .MuiAccordionSummary-content': { margin: theme.spacing(0.5, 0) },
  },
  columnTitle: {
    fontSize: '0.6875rem',
    fontWeight: 700,
    textTransform: 'uppercase',
    letterSpacing: '0.05em',
    color: theme.palette.text.disabled,
    padding: theme.spacing(0.5, 2, 0),
  },
  empty: {
    padding: theme.spacing(0, 2, 1),
    color: theme.palette.text.secondary,
  },
}));

const RECENT_LIMIT = 3;

// كل البيانات هنا موجودة أصلًا في Redux (state.events.items، state.devices.items) —
// لا حساب جديد، فقط عرض أول 3 عناصر + تنسيق مطابق تمامًا لما تفعله EventsDrawer.jsx.
const RecentPanel = () => {
  const { classes } = useStyles();
  const t = useTranslation();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const devices = useSelector((state) => state.devices.items);
  const events = useSelector((state) => state.events.items);

  const recentEvents = events.slice(0, RECENT_LIMIT);
  const recentDevices = Object.values(devices)
    .filter((device) => device.lastUpdate)
    .sort((a, b) => dayjs(b.lastUpdate).valueOf() - dayjs(a.lastUpdate).valueOf())
    .slice(0, RECENT_LIMIT);

  const formatType = (event) =>
    formatNotificationTitle(t, {
      type: event.type,
      attributes: { alarms: event.attributes.alarm },
    });

  return (
    <Accordion className={classes.accordion} disableGutters>
      <AccordionSummary className={classes.summary} expandIcon={<ExpandMoreIcon fontSize="small" />}>
        <Typography variant="body2" fontWeight={700}>
          {t('dashboardRecentActivity')}
        </Typography>
      </AccordionSummary>
      <AccordionDetails sx={{ padding: 0 }}>
        <Typography className={classes.columnTitle}>{t('reportEvents')}</Typography>
        {recentEvents.length ? (
          <List dense disablePadding>
            {recentEvents.map((event) => (
              <ListItemButton key={event.id} onClick={() => navigate(`/event/${event.id}`)} disabled={!event.id}>
                <ListItemText
                  primary={`${devices[event.deviceId]?.name || ''} • ${formatType(event)}`}
                  secondary={formatTime(event.eventTime, 'seconds')}
                />
              </ListItemButton>
            ))}
          </List>
        ) : (
          <Box className={classes.empty}>
            <Typography variant="caption">—</Typography>
          </Box>
        )}

        <Typography className={classes.columnTitle}>{t('deviceLastUpdate')}</Typography>
        {recentDevices.length ? (
          <List dense disablePadding>
            {recentDevices.map((device) => (
              <ListItemButton key={device.id} onClick={() => dispatch(devicesActions.selectId(device.id))}>
                <ListItemText
                  primary={device.name}
                  secondary={formatTime(device.lastUpdate, 'seconds')}
                />
              </ListItemButton>
            ))}
          </List>
        ) : (
          <Box className={classes.empty}>
            <Typography variant="caption">—</Typography>
          </Box>
        )}
      </AccordionDetails>
    </Accordion>
  );
};

export default RecentPanel;
