import { Box, Typography, Tooltip, ButtonBase } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import { useTranslation } from '../common/components/LocalizationProvider';
import { VEHICLE_STATUS, getVehicleStatusMeta } from '../common/theme/status';
import useDeviceStatusCounts from './useDeviceStatusCounts';

const useStyles = makeStyles()((theme) => ({
  root: {
    display: 'flex',
    alignItems: 'stretch',
    gap: theme.spacing(0.5),
    padding: theme.spacing(1, 1.5),
    borderBottom: `1px solid ${theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.08)' : 'rgba(15,23,32,0.08)'}`,
  },
  item: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    borderRadius: theme.shape.borderRadius,
    padding: theme.spacing(0.5, 0.25),
    minWidth: 0,
  },
  count: {
    fontWeight: 800,
    lineHeight: 1.2,
    fontVariantNumeric: 'tabular-nums',
  },
  label: {
    fontSize: '0.625rem',
    color: theme.palette.text.secondary,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    maxWidth: '100%',
  },
  empty: {
    padding: theme.spacing(1.5),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
}));

// onEventsClick: نفس الدالة المُمرَّرة أصلاً إلى MainMap لفتح EventsDrawer — لا Drawer جديد.
const DashboardSummary = ({ onEventsClick }) => {
  const { classes } = useStyles();
  const t = useTranslation();
  const counts = useDeviceStatusCounts();

  if (counts.total === 0) {
    return (
      <Box className={classes.empty}>
        <Typography variant="caption">{t('deviceRegisterFirst')}</Typography>
      </Box>
    );
  }

  const movingMeta = getVehicleStatusMeta(VEHICLE_STATUS.MOVING, t);
  const stoppedMeta = getVehicleStatusMeta(VEHICLE_STATUS.STOPPED, t);
  const offlineMeta = getVehicleStatusMeta(VEHICLE_STATUS.OFFLINE, t);

  const StatItem = ({ count, label, color, onClick, title }) => {
    const content = (
      <Box
        component={onClick ? ButtonBase : 'div'}
        onClick={onClick}
        className={classes.item}
        sx={{ color: color || 'text.primary' }}
      >
        <Typography className={classes.count} variant="h6">
          {count}
        </Typography>
        <Typography className={classes.label}>{label}</Typography>
      </Box>
    );
    return title ? <Tooltip title={title}>{content}</Tooltip> : content;
  };

  return (
    <Box className={classes.root}>
      <StatItem count={counts.total} label={t('dashboardTotalVehicles')} />
      <StatItem count={counts.moving} label={movingMeta.label} color={movingMeta.color} />
      <StatItem count={counts.stopped} label={stoppedMeta.label} color={stoppedMeta.color} />
      <StatItem count={counts.offline} label={offlineMeta.label} color={offlineMeta.color} />
      <StatItem
        count={counts.alerts}
        label={t('dashboardActiveAlerts')}
        color="#DC2626"
        onClick={onEventsClick}
        title={t('reportEvents')}
      />
    </Box>
  );
};

export default DashboardSummary;
