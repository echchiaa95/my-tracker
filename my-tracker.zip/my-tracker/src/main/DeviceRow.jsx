import { useDispatch, useSelector } from 'react-redux';
import { makeStyles } from 'tss-react/mui';
import {
  IconButton,
  Tooltip,
  Avatar,
  ListItemAvatar,
  ListItemText,
  ListItemButton,
  Typography,
  Box,
} from '@mui/material';
import BatteryFullIcon from '@mui/icons-material/BatteryFull';
import BatteryChargingFullIcon from '@mui/icons-material/BatteryChargingFull';
import Battery60Icon from '@mui/icons-material/Battery60';
import BatteryCharging60Icon from '@mui/icons-material/BatteryCharging60';
import Battery20Icon from '@mui/icons-material/Battery20';
import BatteryCharging20Icon from '@mui/icons-material/BatteryCharging20';
import ErrorIcon from '@mui/icons-material/Error';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import { devicesActions } from '../store';
import {
  formatAlarm,
  formatBoolean,
  formatPercentage,
  formatSpeed,
} from '../common/util/formatter';
import { useTranslation } from '../common/components/LocalizationProvider';
import { mapIconKey, mapIcons } from '../map/core/preloadImages';
import { useAdministrator } from '../common/util/permissions';
import EngineIcon from '../resources/images/data/engine.svg?react';
import { useAttributePreference } from '../common/util/preferences';
import GeofencesValue from '../common/components/GeofencesValue';
import DriverValue from '../common/components/DriverValue';
import MotionBar from './components/MotionBar';
import { VEHICLE_STATUS, resolveVehicleStatus, getVehicleStatusMeta } from '../common/theme/status';

dayjs.extend(relativeTime);

const useStyles = makeStyles()((theme) => ({
  icon: {
    width: '25px',
    height: '25px',
    filter: 'brightness(0) invert(1)',
  },
  success: {
    color: theme.palette.success.main,
  },
  warning: {
    color: theme.palette.warning.main,
  },
  error: {
    color: theme.palette.error.main,
  },
  neutral: {
    color: theme.palette.neutral.main,
  },
  selected: {
    backgroundColor: theme.palette.mode === 'dark'
      ? 'rgba(255,255,255,0.08)'
      : `${theme.palette.primary.main}14`,
  },
  primaryLine: {
    display: 'flex',
    alignItems: 'baseline',
    gap: theme.spacing(0.5),
    minWidth: 0,
  },
  identifier: {
    color: theme.palette.text.disabled,
    fontSize: '0.75rem',
    flexShrink: 0,
  },
  statusLine: {
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(0.5),
    minWidth: 0,
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: '50%',
    flexShrink: 0,
  },
}));

const DeviceRow = ({ devices, index, style }) => {
  const { classes } = useStyles();
  const dispatch = useDispatch();
  const t = useTranslation();

  const admin = useAdministrator();
  const selectedDeviceId = useSelector((state) => state.devices.selectedId);

  const item = devices[index];
  const position = useSelector((state) => state.session.positions[item.id]);
  const speedUnit = useAttributePreference('speedUnit');

  const devicePrimary = useAttributePreference('devicePrimary', 'name');
  const deviceSecondary = useAttributePreference('deviceSecondary', '');

  const resolveFieldValue = (field) => {
    if (field === 'geofenceIds') {
      const geofenceIds = position?.geofenceIds;
      return geofenceIds?.length ? <GeofencesValue geofenceIds={geofenceIds} /> : null;
    }
    if (field === 'driverUniqueId') {
      const driverUniqueId = position?.attributes?.driverUniqueId;
      return driverUniqueId ? <DriverValue driverUniqueId={driverUniqueId} /> : null;
    }
    if (field === 'motion') {
      return <MotionBar deviceId={item.id} />;
    }
    return item[field];
  };

  const primaryValue = resolveFieldValue(devicePrimary);
  const secondaryValue = resolveFieldValue(deviceSecondary);

  // نظام الحالة الموحّد من Phase 1 (Status Pulse) — يعتمد فقط على device.status وposition.attributes.motion
  // الموجودَين أصلًا في Redux، بلا أي حساب موازٍ. لون marker الخريطة لم يُلمس (قرارك في هذه المرحلة).
  const statusKey = resolveVehicleStatus(item, position);
  const statusMeta = getVehicleStatusMeta(statusKey, t);

  // السرعة تُعرض فقط عندما تكون السيارة "تتحرك" فعليًا وتوجد قيمة سرعة حقيقية من الموقع — لا قيم وهمية
  const showSpeed = statusKey === VEHICLE_STATUS.MOVING && position?.speed > 0;

  // نص "آخر تحديث": نفس الشرط المنطقي الأصلي (status==='online' أو لا يوجد lastUpdate) لعرض الحالة الحية،
  // وإلا الوقت النسبي — لم يتغيّر الشرط، فقط النص المعروض أصبح Moving/Stopped بدل Online الخام.
  const timeText = item.status === 'online' || !item.lastUpdate
    ? statusMeta.label
    : dayjs(item.lastUpdate).fromNow();

  // الهوية (uniqueId) تُعرض بجانب الاسم فقط عندما لا يكون الحقل الأساسي/الثانوي المخصَّص من قبل
  // المستخدم (devicePrimary/deviceSecondary) يعرضها أصلًا بالفعل — تفاديًا للتكرار.
  const showIdentifierInline =
    devicePrimary === 'name' &&
    deviceSecondary !== 'uniqueId' &&
    item.uniqueId &&
    item.uniqueId !== item.name;

  return (
    <div style={style}>
      <ListItemButton
        key={item.id}
        onClick={() => dispatch(devicesActions.selectId(item.id))}
        disabled={!admin && item.disabled}
        selected={selectedDeviceId === item.id}
        className={selectedDeviceId === item.id ? classes.selected : null}
      >
        <ListItemAvatar>
          <Avatar>
            <img className={classes.icon} src={mapIcons[mapIconKey(item.category)]} alt="" />
          </Avatar>
        </ListItemAvatar>
        <ListItemText
          primary={
            <Box className={classes.primaryLine}>
              <Typography noWrap variant="body2" fontWeight={600} component="span">
                {primaryValue}
              </Typography>
              {showIdentifierInline && (
                <Typography noWrap component="span" className={classes.identifier}>
                  {item.uniqueId}
                </Typography>
              )}
            </Box>
          }
          secondary={
            <Box className={classes.statusLine}>
              <span className={classes.statusDot} style={{ backgroundColor: statusMeta.color }} />
              <Typography noWrap variant="caption" component="span" style={{ color: statusMeta.color, fontWeight: 600 }}>
                {timeText}
              </Typography>
              {showSpeed && (
                <Typography noWrap variant="caption" component="span" color="text.secondary">
                  {`• ${formatSpeed(position.speed, speedUnit, t)}`}
                </Typography>
              )}
              {typeof secondaryValue === 'string' && secondaryValue && (
                <Typography noWrap variant="caption" component="span" color="text.secondary">
                  {`• ${secondaryValue}`}
                </Typography>
              )}
              {deviceSecondary === 'motion' && secondaryValue}
            </Box>
          }
          slots={{
            primary: 'div',
            secondary: 'div',
          }}
        />
        {position && (
          <>
            {position.attributes.hasOwnProperty('alarm') && (
              <Tooltip title={`${t('eventAlarm')}: ${formatAlarm(position.attributes.alarm, t)}`}>
                <IconButton size="small">
                  <ErrorIcon fontSize="small" className={classes.error} />
                </IconButton>
              </Tooltip>
            )}
            {position.attributes.hasOwnProperty('ignition') && (
              <Tooltip
                title={`${t('positionIgnition')}: ${formatBoolean(position.attributes.ignition, t)}`}
              >
                <IconButton size="small">
                  {position.attributes.ignition ? (
                    <EngineIcon width={20} height={20} className={classes.success} />
                  ) : (
                    <EngineIcon width={20} height={20} className={classes.neutral} />
                  )}
                </IconButton>
              </Tooltip>
            )}
            {position.attributes.hasOwnProperty('batteryLevel') && (
              <Tooltip
                title={`${t('positionBatteryLevel')}: ${formatPercentage(position.attributes.batteryLevel)}`}
              >
                <IconButton size="small">
                  {(position.attributes.batteryLevel > 70 &&
                    (position.attributes.charge ? (
                      <BatteryChargingFullIcon fontSize="small" className={classes.success} />
                    ) : (
                      <BatteryFullIcon fontSize="small" className={classes.success} />
                    ))) ||
                    (position.attributes.batteryLevel > 30 &&
                      (position.attributes.charge ? (
                        <BatteryCharging60Icon fontSize="small" className={classes.warning} />
                      ) : (
                        <Battery60Icon fontSize="small" className={classes.warning} />
                      ))) ||
                    (position.attributes.charge ? (
                      <BatteryCharging20Icon fontSize="small" className={classes.error} />
                    ) : (
                      <Battery20Icon fontSize="small" className={classes.error} />
                    ))}
                </IconButton>
              </Tooltip>
            )}
          </>
        )}
      </ListItemButton>
    </div>
  );
};

export default DeviceRow;
