import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import { CssBaseline, StyledEngineProvider } from '@mui/material';
import store from './store';
import { LocalizationProvider } from './common/components/LocalizationProvider';
import ErrorHandler from './common/components/ErrorHandler';
import Navigation from './Navigation';
import preloadImages from './map/core/preloadImages';
import NativeInterface from './common/components/NativeInterface';
import ErrorBoundary from './ErrorBoundary';
import AppThemeProvider from './AppThemeProvider';
import MyTrackerRoot from './mytracker/MyTrackerRoot';

preloadImages();

// ملاحظة: النسخة الأصلية الكاملة (traccar-web) تستخدم ServerProvider مباشرة.
// في نسخة My Tracker، MyTrackerRoot يحل محلّها: يتولى رابط السيرفر + تسجيل
// الدخول عبر TraccarService + قفل PIN، ثم يعرض ServerProvider/Navigation
// الأصليين بدون أي تعديل بمجرد اكتمال هذه الخطوات.
const root = createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <Provider store={store}>
      <LocalizationProvider>
        <StyledEngineProvider injectFirst>
          <AppThemeProvider>
            <CssBaseline />
            <BrowserRouter basename={import.meta.env.BASE_URL}>
              <MyTrackerRoot>
                <Navigation />
              </MyTrackerRoot>
            </BrowserRouter>
            <ErrorHandler />
            <NativeInterface />
          </AppThemeProvider>
        </StyledEngineProvider>
      </LocalizationProvider>
    </Provider>
  </ErrorBoundary>,
);
