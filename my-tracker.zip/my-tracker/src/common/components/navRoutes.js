// تكوين تنقل موحّد — مصدر واحد للحقيقة تُبنى منه SideNav وBottomMenu.
// كل route هنا يشير إلى مسار حقيقي موجود بالفعل في Navigation.jsx — لا مسارات جديدة أُضيفت.

import DashboardRoundedIcon from '@mui/icons-material/DashboardRounded';
import DirectionsCarRoundedIcon from '@mui/icons-material/DirectionsCarRounded';
import AltRouteRoundedIcon from '@mui/icons-material/AltRouteRounded';
import HistoryRoundedIcon from '@mui/icons-material/HistoryRounded';
import PlaceRoundedIcon from '@mui/icons-material/PlaceRounded';
import NotificationsRoundedIcon from '@mui/icons-material/NotificationsRounded';
import AssessmentRoundedIcon from '@mui/icons-material/AssessmentRounded';
import BuildRoundedIcon from '@mui/icons-material/BuildRounded';
import SettingsRoundedIcon from '@mui/icons-material/SettingsRounded';

// ملاحظة مهمة (اكتُشفت أثناء التنفيذ): لا يوجد حاليًا route منفصل لـ"Vehicles" أو
// "Alerts Center" — هذه صفحات مستقبلية ضمن نطاق Phase 3/Alerts. حاليًا نربطها
// بأقرب صفحة موجودة فعليًا (settings/devices، reports/events) دون إنشاء صفحات جديدة.
export const buildNavGroups = ({ readonly, disableReports }) => [
  {
    subheader: 'navGroupMain',
    items: [
      { key: 'dashboard', href: '/', match: '^/$', icon: DashboardRoundedIcon, labelKey: 'mapTitle' },
      { key: 'vehicles', href: '/settings/devices', icon: DirectionsCarRoundedIcon, labelKey: 'deviceTitle', hidden: readonly },
      { key: 'trips', href: '/reports/trips', icon: AltRouteRoundedIcon, labelKey: 'reportTrips', hidden: disableReports },
      { key: 'history', href: '/replay', icon: HistoryRoundedIcon, labelKey: 'reportReplay' },
    ],
  },
  {
    subheader: 'navGroupManagement',
    items: [
      { key: 'geofences', href: '/geofences', icon: PlaceRoundedIcon, labelKey: 'sharedGeofences' },
      { key: 'alerts', href: '/reports/events', icon: NotificationsRoundedIcon, labelKey: 'reportEvents', hidden: disableReports, badge: 'events' },
      { key: 'reports', href: '/reports/combined', icon: AssessmentRoundedIcon, labelKey: 'reportTitle', hidden: disableReports },
      { key: 'maintenance', href: '/settings/maintenances', icon: BuildRoundedIcon, labelKey: 'sharedMaintenance', hidden: readonly },
    ],
  },
  {
    subheader: 'navGroupSystem',
    items: [
      { key: 'settings', href: '/settings/preferences', icon: SettingsRoundedIcon, labelKey: 'settingsTitle' },
    ],
  },
];

// Bottom Navigation على الموبايل: 4 عناصر رئيسية فقط + More (يُبنى في BottomMenu.jsx نفسه)
export const MOBILE_PRIMARY_KEYS = ['dashboard', 'vehicles', 'alerts'];
