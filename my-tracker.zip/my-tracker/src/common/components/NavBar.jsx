import { useState } from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Badge,
  Tooltip,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Box,
  Avatar,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsRoundedIcon from '@mui/icons-material/NotificationsRounded';
import PersonRoundedIcon from '@mui/icons-material/PersonRounded';
import TuneRoundedIcon from '@mui/icons-material/TuneRounded';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import { useTranslation } from './LocalizationProvider';
import useLogout from '../util/useLogout';

const useStyles = makeStyles()((theme) => ({
  appBar: {
    borderBottom: `1px solid ${theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.08)' : 'rgba(15,23,32,0.08)'}`,
  },
  title: {
    fontWeight: 700,
    flexGrow: 1,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: '50%',
    display: 'inline-block',
    marginInlineEnd: theme.spacing(1),
  },
  statusGroup: {
    display: 'flex',
    alignItems: 'center',
    marginInlineEnd: theme.spacing(1.5),
  },
  statusLabel: {
    color: theme.palette.text.secondary,
  },
}));

// connected: true = متصل فعليًا (نفس state.session.socket)
// connected: false = تم فقدان الاتصال، SocketController يحاول إعادة الاتصال تلقائيًا
// connected: null/undefined = لم يبدأ الاتصال بعد (تحميل أولي)
const ConnectionStatus = ({ connected }) => {
  const { classes } = useStyles();
  const t = useTranslation();

  let color;
  let labelKey;
  if (connected === true) {
    color = '#189B62'; // Signal Green — من tokens.js
    labelKey = 'stateStatusOnline';
  } else if (connected === false) {
    color = '#D97706'; // Amber Stop
    labelKey = 'stateStatusReconnecting';
  } else {
    color = '#94A3B8';
    labelKey = 'stateStatusConnecting';
  }

  return (
    <Tooltip title={t(labelKey)}>
      <Box className={classes.statusGroup}>
        <span className={classes.statusDot} style={{ backgroundColor: color }} />
        <Typography variant="caption" className={classes.statusLabel} sx={{ display: { xs: 'none', sm: 'inline' } }}>
          {t(labelKey)}
        </Typography>
      </Box>
    </Tooltip>
  );
};

// title: عنوان الصفحة الحالية (مفتاح ترجمة أو نص جاهز)
// onMenuClick: فتح/طي SideNav — تُمرَّر من الحاوية التي تستدعي NavBar
const NavBar = ({ title, onMenuClick }) => {
  const { classes } = useStyles();
  const t = useTranslation();
  const logout = useLogout();

  const socket = useSelector((state) => state.session.socket);
  const eventCount = useSelector((state) => state.events.items.length);
  const user = useSelector((state) => state.session.user);

  const [anchorEl, setAnchorEl] = useState(null);

  return (
    <AppBar position="sticky" color="inherit" elevation={0} className={classes.appBar}>
      <Toolbar>
        {onMenuClick && (
          <IconButton color="inherit" edge="start" sx={{ mr: 2 }} onClick={onMenuClick} aria-label={t('sharedMore')}>
            <MenuIcon />
          </IconButton>
        )}
        <Typography variant="h6" noWrap className={classes.title}>
          {title}
        </Typography>

        <ConnectionStatus connected={socket} />

        <Tooltip title={t('reportEvents')}>
          <IconButton color="inherit" component={Link} to="/reports/events" aria-label={t('reportEvents')}>
            <Badge color="error" badgeContent={eventCount} max={9}>
              <NotificationsRoundedIcon />
            </Badge>
          </IconButton>
        </Tooltip>

        <Tooltip title={user?.name || ''}>
          <IconButton color="inherit" onClick={(e) => setAnchorEl(e.currentTarget)} aria-label={t('settingsUser')}>
            <Avatar sx={{ width: 28, height: 28 }}>
              <PersonRoundedIcon fontSize="small" />
            </Avatar>
          </IconButton>
        </Tooltip>
        <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => setAnchorEl(null)}>
          <MenuItem component={Link} to={`/settings/user/${user?.id}`} onClick={() => setAnchorEl(null)}>
            <ListItemIcon><PersonRoundedIcon fontSize="small" /></ListItemIcon>
            <ListItemText>{t('settingsUser')}</ListItemText>
          </MenuItem>
          <MenuItem component={Link} to="/settings/preferences" onClick={() => setAnchorEl(null)}>
            <ListItemIcon><TuneRoundedIcon fontSize="small" /></ListItemIcon>
            <ListItemText>{t('sharedPreferences')}</ListItemText>
          </MenuItem>
          <MenuItem onClick={() => { setAnchorEl(null); logout(); }}>
            <ListItemIcon><ExitToAppIcon fontSize="small" /></ListItemIcon>
            <ListItemText>{t('loginLogout')}</ListItemText>
          </MenuItem>
        </Menu>
      </Toolbar>
    </AppBar>
  );
};

export default NavBar;
