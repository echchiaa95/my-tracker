import traccarService from '../../mytracker/services/traccarService';

/**
 * نسخة My Tracker: الكود الأصلي كان يفترض أن Traccar على نفس دومين الواجهة
 * (fetch('/api/...') نسبي). عند النشر على GitHub Pages فـTraccar عادة على
 * دومين مختلف، لذلك هنا نُلحق baseUrl المُهيَّأ في TraccarService تلقائيًا
 * بأي مسار "/api/..."، ونضيف credentials:'include' حتى تُرسَل كوكيز الجلسة
 * عبر الدومين (يتطلب من سيرفر Traccar CORS + SameSite=None؛ Secure — انظر
 * تعليق CORS/HTTPS في traccarService.js). هذا يصلح الاستدعاءات الـ62 التي
 * تستخدم fetchOrThrow عبر كل الإعدادات/التقارير دفعة واحدة دون تعديل كل
 * ملف على حدة.
 */
function resolveApiInput(input) {
  if (typeof input === 'string' && input.startsWith('/api') && traccarService.baseUrl) {
    return `${traccarService.baseUrl}${input}`;
  }
  return input;
}

export default async (input, init) => {
  const resolvedInput = resolveApiInput(input);
  const resolvedInit =
    typeof input === 'string' && input.startsWith('/api')
      ? { credentials: 'include', ...init }
      : init;
  const response = await fetch(resolvedInput, resolvedInit);
  if (!response.ok) {
    throw new Error(await response.text());
  }
  return response;
};
