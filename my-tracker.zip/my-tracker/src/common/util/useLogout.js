import { useDispatch } from 'react-redux';
import { sessionActions } from '../../store';
import { nativePostMessage } from '../components/NativeInterface';
import traccarService from '../../mytracker/services/traccarService';

// نسخة My Tracker: التسجيل الأصلي (تعطيل notificationToken + fetch نسبي +
// navigate('/login')) استُبدل لأن /login غير موجودة في تدفق My Tracker
// (البوابة الآن MyTrackerRoot)، ولأن الروابط النسبية لا تعمل عندما يكون
// Traccar على دومين مختلف عن GitHub Pages. traccarService.logout() يعرف
// الدومين الصحيح ويغلق الاتصال الحي أيضًا.
const useLogout = () => {
  const dispatch = useDispatch();

  return async () => {
    await traccarService.logout();
    nativePostMessage('logout');
    dispatch(sessionActions.updateUser(null));
    window.location.reload(); // يعيد MyTrackerRoot لبوابة تسجيل الدخول من جديد
  };
};

export default useLogout;
