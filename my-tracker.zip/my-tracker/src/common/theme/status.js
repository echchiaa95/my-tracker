import PlayCircleRoundedIcon from '@mui/icons-material/PlayCircleRounded';
import PauseCircleRoundedIcon from '@mui/icons-material/PauseCircleRounded';
import WifiOffRoundedIcon from '@mui/icons-material/WifiOffRounded';
import HelpRoundedIcon from '@mui/icons-material/HelpRounded';
import { statusColors } from './tokens';

// "Status Pulse" — مصدر واحد لحالة السيارة يُستخدم حرفيًا في:
// Marker على الخريطة (map/main)، DeviceRow، شارات Dashboard، رأس تفاصيل السيارة.
// لا يلمس منطق Traccar: يعتمد فقط على device.status (من الجهاز) وposition.attributes.motion
// (محسوب من السيرفر أصلاً)، دون إعادة حساب أو استبدال أي بيانات.

export const VEHICLE_STATUS = {
  MOVING: 'moving',
  STOPPED: 'stopped',
  OFFLINE: 'offline',
  UNKNOWN: 'unknown',
};

const STATUS_META = {
  [VEHICLE_STATUS.MOVING]: {
    color: statusColors.moving,
    icon: PlayCircleRoundedIcon,
    labelKey: 'deviceStatusMoving',
  },
  [VEHICLE_STATUS.STOPPED]: {
    color: statusColors.stopped,
    icon: PauseCircleRoundedIcon,
    labelKey: 'deviceStatusStopped',
  },
  [VEHICLE_STATUS.OFFLINE]: {
    color: statusColors.offline,
    icon: WifiOffRoundedIcon,
    labelKey: 'deviceStatusOffline',
  },
  [VEHICLE_STATUS.UNKNOWN]: {
    color: statusColors.unknown,
    icon: HelpRoundedIcon,
    labelKey: 'deviceStatusUnknown',
  },
};

// device: من store.devices.items[id] — status: 'online' | 'offline' | 'unknown'
// position: من store.session.positions[id] — قد تكون undefined إن لم تصل بيانات بعد
export const resolveVehicleStatus = (device, position) => {
  if (!device || device.status !== 'online') {
    return device?.status === 'unknown' ? VEHICLE_STATUS.UNKNOWN : VEHICLE_STATUS.OFFLINE;
  }
  const isMoving = Boolean(position?.attributes?.motion);
  return isMoving ? VEHICLE_STATUS.MOVING : VEHICLE_STATUS.STOPPED;
};

// t: دالة الترجمة من useTranslation()
export const getVehicleStatusMeta = (statusKey, t) => {
  const meta = STATUS_META[statusKey] || STATUS_META[VEHICLE_STATUS.UNKNOWN];
  return {
    ...meta,
    label: t(meta.labelKey),
  };
};

export default { VEHICLE_STATUS, resolveVehicleStatus, getVehicleStatusMeta };
