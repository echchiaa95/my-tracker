// Design tokens — طبقة موحّدة فوق MUI. لا تُستخدم هذه القيم مباشرة في المكوّنات،
// بل عبر theme.palette / theme.status / theme.shape كما في باقي الملفات.

export const brandColors = {
  routeTeal: '#0E6B73', // العلامة الافتراضية — يبقى قابلاً للاستبدال عبر server.attributes.colorPrimary
  midnightInk: '#0B1220',
  mist: '#F6F7F8',
};

// نظام حالة السيارة الموحّد — يُستخدم في: Marker / DeviceRow / Dashboard chips / Vehicle details
export const statusColors = {
  moving: '#189B62', // Signal Green
  stopped: '#D97706', // Amber Stop
  offline: '#64748B', // Slate Offline
  unknown: '#94A3B8',
  alert: '#DC2626', // Alert Red — للتنبيهات فقط، ليس للحالة العادية
};

export const radius = {
  sm: 6,
  md: 10,
  lg: 16,
  pill: 999,
};

export const spacingUnit = 8; // متوافق مع MUI theme.spacing الافتراضي — موثّق صراحة هنا

export const typography = {
  fontFamilyLatinDisplay: '"Plus Jakarta Sans", "IBM Plex Sans Arabic", Roboto, sans-serif',
  fontFamilyLatinBody: '"Inter", "IBM Plex Sans Arabic", Roboto, sans-serif',
  fontFamilyArabic: '"IBM Plex Sans Arabic", "Plus Jakarta Sans", Roboto, sans-serif',
  // للأرقام (سرعة/مسافة/بطارية) — أرقام محاذاة العرض لتفادي "قفز" الواجهة عند التحديث الحي
  numericFeatureSettings: '"tnum" 1, "lnum" 1',
};

export default {
  brandColors,
  statusColors,
  radius,
  spacingUnit,
  typography,
};
