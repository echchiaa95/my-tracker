import { useId, useEffect, useState } from 'react';
import { kml } from '@tmcw/togeojson';
import { useTheme } from '@mui/material/styles';
import { map } from '../core/MapView';
import { useAsyncTask } from '../../reactHelper';
import { usePreference } from '../../common/util/preferences';
import gcoord from 'gcoord';
import { findFonts } from '../core/mapUtil';

const PoiMap = () => {
  const id = useId();

  const theme = useTheme();

  const poiLayer = usePreference('poiLayer');

  const [data, setData] = useState(null);

  useAsyncTask(
    async ({ signal }) => {
      if (poiLayer) {
        const file = await fetch(poiLayer, { signal });
        const dom = new DOMParser().parseFromString(await file.text(), 'text/xml');
        setData(kml(dom));
      }
    },
    [poiLayer],
  );

  useEffect(() => {
    if (data) {
      map.addSource(id, {
        type: 'geojson',
        data:
          map.coordinateSystem === 'gcj02'
            ? gcoord.transform(structuredClone(data), gcoord.WGS84, gcoord.GCJ02)
            : data,
      });
      map.addLayer({
        source: id,
        id: 'poi-fill',
        type: 'fill',
        filter: ['==', '$type', 'Polygon'],
        paint: {
          'fill-color': ['coalesce', ['get', 'fill'], theme.palette.geometry.main],
          'fill-opacity': ['coalesce', ['get', 'fill-opacity'], 0.3],
        },
      });
      map.addLayer({
        source: id,
        id: 'poi-point',
        type: 'circle',
        paint: {
          'circle-radius': 5,
          'circle-color': ['coalesce', ['get', 'icon-color'], theme.palette.geometry.main],
        },
      });
      map.addLayer({
        source: id,
        id: 'poi-line',
        type: 'line',
        paint: {
          'line-color': ['coalesce', ['get', 'stroke'], theme.palette.geometry.main],
          'line-width': ['coalesce', ['get', 'stroke-width'], 2],
          'line-opacity': ['coalesce', ['get', 'stroke-opacity'], 1],
        },
      });
      map.addLayer({
        source: id,
        id: 'poi-title',
        type: 'symbol',
        layout: {
          'text-field': '{name}',
          'text-anchor': 'bottom',
          'text-offset': [0, -0.5],
          'text-font': findFonts(map),
          'text-size': 12,
        },
        paint: {
          'text-halo-color': 'white',
          'text-halo-width': 1,
        },
      });
      return () => {
        if (map.getLayer('poi-title')) {
          map.removeLayer('poi-title');
        }
        if (map.getLayer('poi-line')) {
          map.removeLayer('poi-line');
        }
        if (map.getLayer('poi-point')) {
          map.removeLayer('poi-point');
        }
        if (map.getLayer('poi-fill')) {
          map.removeLayer('poi-fill');
        }
        if (map.getSource(id)) {
          map.removeSource(id);
        }
      };
    }
    return () => {};
  }, [data, id, theme.palette.geometry.main]);

  return null;
};

export default PoiMap;
