/**
 * pinService — قفل تطبيق محلي برمز من 4 أرقام.
 * تنبيه صريح: هذا ليس تشفيرًا ولا حماية أمنية حقيقية، بل مجرد قفل واجهة محلي
 * (مطابق لمتطلب التوثيق: لا يُدَّعى أن PIN = تشفير).
 */

import storageService from './storageService';

// تجزئة بسيطة (غير قابلة للعكس مباشرة) — كافية لقفل واجهة محلي فقط.
async function hashPin(pin) {
  const encoder = new TextEncoder();
  const data = encoder.encode(`mytracker::${pin}`);
  const digest = await window.crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

const pinService = {
  isPinSet() {
    return Boolean(storageService.getState().pin?.hash);
  },

  async createPin(pin) {
    const hash = await hashPin(pin);
    storageService.update('pin', { hash, createdAt: new Date().toISOString() });
  },

  async verifyPin(pin) {
    const { hash } = storageService.getState().pin;
    if (!hash) return false;
    return (await hashPin(pin)) === hash;
  },

  async changePin(oldPin, newPin) {
    const valid = await this.verifyPin(oldPin);
    if (!valid) return { ok: false, error: 'PIN incorrect' };
    await this.createPin(newPin);
    return { ok: true };
  },

  removePin() {
    storageService.update('pin', { hash: null, createdAt: null });
  },
};

export default pinService;
