/**
 * TraccarService — الطبقة الوحيدة المسؤولة عن التواصل مع Traccar Server.
 * لا يوجد أي منطق اتصال بـ Traccar داخل مكونات React — كل شيء يمر من هنا.
 *
 * ملاحظات مهمة حول CORS/HTTPS (متطلب #8):
 * - عند النشر على GitHub Pages فالتطبيق يعمل من دومين مختلف عن Traccar Server.
 * - المصادقة هنا تعتمد على Session Cookie (نفس آلية Traccar الرسمية)، وهذا
 *   يتطلب من سيرفر Traccar أن يسمح صراحة بـ:
 *     Access-Control-Allow-Origin: <دومين GitHub Pages>
 *     Access-Control-Allow-Credentials: true
 *   وأن تكون الكوكيز Secure + SameSite=None، وأن يعمل السيرفر عبر HTTPS.
 * - لا يحاول هذا الملف تجاوز CORS بأي شكل. إن فشل الاتصال بسبب CORS تُرجَع
 *   رسالة خطأ واضحة (انظر ERROR_CODES) ليعرضها المستخدم في الواجهة.
 */

import { debugLog } from '../debugLog';

const ERROR_CODES = {
  INVALID_URL: 'Invalid server URL',
  CANNOT_CONNECT: 'Cannot connect to Traccar',
  AUTH_FAILED: 'Authentication failed',
  NO_DEVICES: 'No devices found',
  CONNECTION_LOST: 'Connection lost',
};

/** ينظّف رابط السيرفر: يزيل "/" الأخير ويمنع تكرار "/api". */
function normalizeServerUrl(input) {
  if (!input) return '';
  let url = input.trim();
  url = url.replace(/\/+$/, ''); // إزالة "/" الأخير
  url = url.replace(/\/api$/i, ''); // منع تكرار /api لاحقًا
  return url;
}

function isValidHttpUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

class TraccarService {
  constructor() {
    this.baseUrl = '';
    this.socket = null;
    this.pollTimer = null;
    this.listeners = new Set(); // ({ type, payload }) => void
    this.pollIntervalMs = 5000;
    this.authenticated = false;
  }

  configure(serverUrl) {
    this.baseUrl = normalizeServerUrl(serverUrl);
    return this.baseUrl;
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  _emit(type, payload) {
    this.listeners.forEach((fn) => fn({ type, payload }));
  }

  _apiUrl(path) {
    return `${this.baseUrl}/api${path}`;
  }

  _wsUrl() {
    const httpUrl = new URL(this.baseUrl);
    const wsProtocol = httpUrl.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${wsProtocol}//${httpUrl.host}/api/socket`;
  }

  /** تسجيل الدخول. يُرجع { ok, error, user }. */
  async login(email, password) {
    console.log('AUTH: starting login', { baseUrl: this.baseUrl, email });

    if (!this.baseUrl || !isValidHttpUrl(this.baseUrl)) {
      console.log('AUTH: login aborted, invalid baseUrl', this.baseUrl);
      return { ok: false, error: ERROR_CODES.INVALID_URL };
    }

    let response;
    try {
      response = await fetch(this._apiUrl('/session'), {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ email, password }).toString(),
      });
    } catch (networkError) {
      // هذا هو الفرع الذي يحدث فيه خطأ CORS من جهة المتصفح: fetch() يرفض
      // (TypeError: Failed to fetch) حتى لو رد السيرفر فعليًا بـ200 —
      // المتصفح يمنع قراءة الاستجابة قبل أن يصل الكود إلى هنا أصلًا.
      console.log('AUTH: login network/CORS error', networkError?.name, networkError?.message);
      return { ok: false, error: `${ERROR_CODES.CANNOT_CONNECT} (${networkError?.name}: ${networkError?.message})` };
    }

    console.log('AUTH: login response', {
      status: response.status,
      ok: response.ok,
      url: response.url,
    });

    if (response.status === 401 || response.status === 403) {
      console.log('AUTH: login rejected by server (401/403)');
      return { ok: false, error: ERROR_CODES.AUTH_FAILED, status: response.status };
    }
    if (!response.ok) {
      console.log('AUTH: login failed, unexpected HTTP status', response.status);
      return { ok: false, error: ERROR_CODES.CANNOT_CONNECT, status: response.status };
    }

    try {
      // كان response.json() هنا خارج try/catch سابقًا — أي خطأ تحليل كان
      // يتحول لاستثناء غير مُلتقَط يوقف التنفيذ بصمت بلا أي رسالة.
      const user = await response.json();
      this.authenticated = true;
      console.log('AUTH: login succeeded, user received', { id: user?.id, administrator: user?.administrator });
      return { ok: true, user, status: response.status };
    } catch (parseError) {
      console.log('AUTH: login response was not valid JSON', parseError?.message);
      return { ok: false, error: ERROR_CODES.CANNOT_CONNECT, status: response.status };
    }
  }

  async logout() {
    try {
      await fetch(this._apiUrl('/session'), { method: 'DELETE', credentials: 'include' });
    } catch {
      // تجاهل أخطاء الشبكة عند تسجيل الخروج
    }
    this.authenticated = false;
    this.stopLive();
  }

  /** التحقق من وجود جلسة صالحة حاليًا (مثلاً بعد إعادة فتح التطبيق). */
  async fetchSession() {
    const url = this._apiUrl('/session');
    debugLog('AUTH: fetchSession started');
    debugLog('AUTH: fetchSession URL =', url);

    let response;
    try {
      response = await fetch(url, { method: 'GET', credentials: 'include' });
    } catch (error) {
      // خطأ شبكة/CORS حقيقي — الطلب لم يصل لخادم أصلًا من منظور المتصفح،
      // وليس رفض مصادقة. نميّزه صراحة عن 401/403.
      debugLog('AUTH: fetchSession error name =', error?.name);
      debugLog('AUTH: fetchSession error message =', error?.message);
      return { ok: false, error: `${ERROR_CODES.CANNOT_CONNECT} (network/CORS: ${error?.name}: ${error?.message})`, kind: 'network' };
    }

    debugLog('AUTH: fetchSession response status =', response.status);
    debugLog('AUTH: fetchSession response ok =', response.ok);
    debugLog('AUTH: fetchSession response content-type =', response.headers.get('content-type'));

    const bodyText = await response.text();
    debugLog('AUTH: fetchSession response body =', bodyText?.slice(0, 300) || '(empty)');

    // 401 = لا توجد جلسة حاليًا (حالة طبيعية تمامًا قبل تسجيل الدخول، وليست
    // خطأً). 403 = مشكلة صلاحيات فعلية. أي حالة أخرى غير 200 = مشكلة اتصال.
    if (response.status === 401) {
      return { ok: false, error: ERROR_CODES.AUTH_FAILED, status: 401, kind: 'no-session' };
    }
    if (response.status === 403) {
      return { ok: false, error: `Forbidden (403)`, status: 403, kind: 'forbidden' };
    }
    if (!response.ok) {
      return { ok: false, error: `${ERROR_CODES.CANNOT_CONNECT} (HTTP ${response.status})`, status: response.status, kind: 'http-error' };
    }

    try {
      const user = JSON.parse(bodyText);
      this.authenticated = true;
      return { ok: true, user, status: response.status };
    } catch (parseError) {
      debugLog('AUTH: fetchSession error name =', 'JSONParseError');
      debugLog('AUTH: fetchSession error message =', parseError?.message);
      return { ok: false, error: `${ERROR_CODES.CANNOT_CONNECT} (invalid JSON: ${parseError?.message})`, kind: 'parse-error' };
    }
  }

  async getDevices() {
    try {
      const response = await fetch(this._apiUrl('/devices'), { credentials: 'include' });
      if (response.status === 401 || response.status === 403) {
        return { ok: false, error: ERROR_CODES.AUTH_FAILED };
      }
      if (!response.ok) return { ok: false, error: ERROR_CODES.CANNOT_CONNECT };
      const devices = await response.json();
      if (!devices.length) return { ok: true, devices: [], error: ERROR_CODES.NO_DEVICES };
      return { ok: true, devices };
    } catch {
      return { ok: false, error: ERROR_CODES.CANNOT_CONNECT };
    }
  }

  async getPositions() {
    try {
      const response = await fetch(this._apiUrl('/positions'), { credentials: 'include' });
      if (!response.ok) return { ok: false, error: ERROR_CODES.CANNOT_CONNECT };
      const positions = await response.json();
      return { ok: true, positions };
    } catch {
      return { ok: false, error: ERROR_CODES.CANNOT_CONNECT };
    }
  }

  /**
   * يشغّل التحديث الحي: يحاول WebSocket أولًا، وإن فشل أو انقطع
   * يتحول تلقائيًا إلى Polling كحل احتياطي.
   */
  startLive() {
    this._connectSocket();
  }

  stopLive() {
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
    this._stopPolling();
  }

  _connectSocket() {
    try {
      this.socket = new WebSocket(this._wsUrl());
    } catch {
      this._startPolling();
      return;
    }
    this.socket.onopen = () => {
      this._stopPolling();
      this._emit('status', { connected: true });
    };
    this.socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.positions) this._emit('positions', data.positions);
        if (data.devices) this._emit('devices', data.devices);
      } catch {
        // تجاهل رسائل غير صالحة
      }
    };
    this.socket.onclose = () => {
      this._emit('status', { connected: false, error: ERROR_CODES.CONNECTION_LOST });
      this._startPolling();
    };
    this.socket.onerror = () => {
      this._startPolling();
    };
  }

  _startPolling() {
    if (this.pollTimer) return;
    this.pollTimer = window.setInterval(async () => {
      const result = await this.getPositions();
      if (result.ok) {
        this._emit('positions', result.positions);
        this._emit('status', { connected: true });
      } else {
        this._emit('status', { connected: false, error: result.error });
      }
    }, this.pollIntervalMs);
  }

  _stopPolling() {
    if (this.pollTimer) {
      window.clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
  }
}

const traccarService = new TraccarService();

export default traccarService;
export { ERROR_CODES, normalizeServerUrl, isValidHttpUrl };
