import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { sessionActions } from '../store';
import ServerProvider from '../ServerProvider';
import Loader from '../common/components/Loader';
import pinService from './services/pinService';
import storageService from './services/storageService';
import traccarService, { ERROR_CODES } from './services/traccarService';
import PinSetupPage from './pages/PinSetupPage';
import PinLockPage from './pages/PinLockPage';
import ServerSetupPage from './pages/ServerSetupPage';
import TraccarReduxBridge from './TraccarReduxBridge';

/**
 * MyTrackerRoot — يحل محل App.jsx الأصلي كنقطة دخول لنسخة "My Tracker" فقط
 * (App.jsx الأصلي والمسار الكامل traccar-web يبقيان بدون أي تعديل).
 *
 * تسلسل الشاشات:
 *   لا يوجد serverUrl محفوظ  → ServerSetupPage (رابط + دخول Traccar)
 *   يوجد رابط لكن لا PIN     → PinSetupPage
 *   يوجد PIN ولم يُفتح بعد   → PinLockPage
 *   كل شيء جاهز              → children (الواجهة الأصلية: Dashboard/Map/...)
 */
const MyTrackerRoot = ({ children }) => {
  const dispatch = useDispatch();
  const [stage, setStage] = useState('loading'); // loading | server | pin-setup | locked | ready
  const [connectError, setConnectError] = useState(null);

  useEffect(() => {
    (async () => {
      const { traccar } = storageService.getState();
      if (!traccar.serverUrl) {
        setStage('server');
        return;
      }
      traccarService.configure(traccar.serverUrl);
      const session = await traccarService.fetchSession();
      if (!session.ok) {
        setStage('server');
        // عدم وجود جلسة (AUTH_FAILED) عند أول فتح للتطبيق أمر طبيعي —
        // المستخدم لم يسجّل الدخول بعد، وليس خطأً يستدعي تنبيهًا مخيفًا.
        // نعرض رسالة خطأ فقط لمشاكل حقيقية (رابط خاطئ / تعذّر الاتصال).
        if (session.error !== ERROR_CODES.AUTH_FAILED) {
          setConnectError(session.error);
        }
        return;
      }
      dispatch(sessionActions.updateUser(session.user));
      setStage(pinService.isPinSet() ? 'locked' : 'pin-setup');
    })();
  }, [dispatch]);

  if (stage === 'loading') return <Loader />;

  if (stage === 'server') {
    return (
      <ServerSetupPage
        initialError={connectError}
        onConnected={(user) => {
          dispatch(sessionActions.updateUser(user));
          setStage(pinService.isPinSet() ? 'locked' : 'pin-setup');
        }}
      />
    );
  }

  if (stage === 'pin-setup') {
    return <PinSetupPage onDone={() => setStage('ready')} />;
  }

  if (stage === 'locked') {
    return <PinLockPage onUnlocked={() => setStage('ready')} />;
  }

  return (
    <ServerProvider>
      <TraccarReduxBridge />
      {children}
    </ServerProvider>
  );
};

export default MyTrackerRoot;
