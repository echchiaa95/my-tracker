import { useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { sessionActions } from '../store';
import ServerProvider from '../ServerProvider';
import Loader from '../common/components/Loader';
import pinService from './services/pinService';
import storageService from './services/storageService';
import traccarService, { ERROR_CODES } from './services/traccarService';
import PinSetupPage from './pages/PinSetupPage';
import PinLockPage from './pages/PinLockPage';
import MyTrackerLoginPage from './pages/MyTrackerLoginPage';
import TraccarReduxBridge from './TraccarReduxBridge';
import { debugLog } from './debugLog';

/**
 * MyTrackerRoot — المصدر الوحيد للحقيقة بخصوص جلسة Traccar (مصدر وحيد،
 * بلا أي نظام مصادقة موازٍ — App.jsx الأصلي لم يعد يحتوي أي منطق redirect).
 *
 * Traccar backend غير مرئي بالكامل للمستخدم: الرابط يأتي حصرًا من
 * VITE_TRACCAR_URL (لا يوجد حقل "Server URL" في أي شاشة).
 *
 *   authStatus = 'checking'        → Loader فقط، لا أي navigate إطلاقًا
 *   authStatus = 'unauthenticated' → MyTrackerLoginPage (بريد/كلمة مرور فقط)
 *   authStatus = 'authenticated'   → pinLock: 'setup' | 'locked' | 'open'
 *                                     'open' فقط يعرض التطبيق الفعلي
 *
 * هذا الملف هو المكان الوحيد في كامل المشروع الذي يستدعي setAuthStatus —
 * تحقّقتُ ببحث شامل عبر src/ عن navigate('/login')، setUser، dispatch،
 * window.location، logout: لا يوجد أي مصدر آخر قادر على تغيير حالة
 * المصادقة (القائمة الكاملة في رد المحادثة).
 */
const MyTrackerRoot = ({ children }) => {
  const dispatch = useDispatch();
  const [authStatus, setAuthStatusState] = useState('checking'); // checking | unauthenticated | authenticated
  const [pinLock, setPinLock] = useState(null); // 'setup' | 'locked' | 'open'
  const [loginError, setLoginError] = useState(null);
  const previousStatusRef = useRef('checking');

  // كل تغيير لـauthStatus يمر من هنا فقط — يسجّل في debugLog تلقائيًا.
  // "FORCED LOGOUT / UNAUTHENTICATED" يظهر فقط عندما كانت الحالة السابقة
  // "authenticated" فعلًا (أي جلسة حقيقية انقطعت) — وليس عند أول تحميل قبل
  // أي محاولة دخول، لأن checking → unauthenticated بسبب 401 هو المسار
  // الطبيعي والمتوقَّع قبل الضغط على تسجيل الدخول وليس خطأً.
  const setAuthStatus = (next, reason) => {
    if (next === 'unauthenticated' && previousStatusRef.current === 'authenticated') {
      debugLog(
        'FORCED LOGOUT / UNAUTHENTICATED',
        '\nsource file: src/mytracker/MyTrackerRoot.jsx (المصدر الوحيد الذي يستدعي setAuthStatus في كامل المشروع)',
        `\nreason: ${reason || 'unknown'}`,
        `\nprevious authStatus: ${previousStatusRef.current}`,
      );
    } else if (next === 'unauthenticated') {
      debugLog(`AUTH: authStatus ${previousStatusRef.current} → unauthenticated (طبيعي، لا يوجد Login بعد)`, reason ? `— ${reason}` : '');
    } else {
      debugLog(`AUTH: authStatus ${previousStatusRef.current} → ${next}`, reason ? `(${reason})` : '');
    }
    previousStatusRef.current = next;
    setAuthStatusState(next);
  };

  useEffect(() => {
    (async () => {
      // مصدر واحد للرابط: VITE_TRACCAR_URL فقط، لا رابط من المستخدم إطلاقًا.
      const configuredUrl = import.meta.env.VITE_TRACCAR_URL || '';
      traccarService.configure(configuredUrl);
      debugLog('AUTH: MyTrackerRoot mounted, VITE_TRACCAR_URL =', configuredUrl);

      // fetchSession() يُنفَّذ دائمًا قبل أي قرار — لا navigate ولا تغيير
      // حالة قبل معرفة نتيجته (يمنع بالضبط سباق "user فارغ مؤقتًا").
      const session = await traccarService.fetchSession();

      if (!session.ok) {
        setAuthStatus('unauthenticated', session.error || 'no active session on initial check');
        // عدم وجود جلسة بعد (AUTH_FAILED) عند أول فتح أمر طبيعي تمامًا وليس
        // خطأً — نعرض رسالة فقط لمشاكل اتصال حقيقية.
        if (session.error !== ERROR_CODES.AUTH_FAILED) {
          setLoginError(session.error);
        }
        return;
      }

      dispatch(sessionActions.updateUser(session.user));
      setAuthStatus('authenticated', 'initial fetchSession succeeded');
      setPinLock(pinService.isPinSet() ? 'locked' : 'setup');
    })();
    // يُنفَّذ هذا الأثر مرة واحدة فقط عند التحميل الأول — لا يُعاد تشغيله عند
    // نجاح تسجيل الدخول (ذلك يمر عبر onAuthenticated أدناه مباشرة).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch]);

  if (authStatus === 'checking') {
    return <Loader />;
  }

  if (authStatus === 'unauthenticated') {
    return (
      <MyTrackerLoginPage
        initialError={loginError}
        onAuthenticated={(user) => {
          dispatch(sessionActions.updateUser(user));
          setAuthStatus('authenticated', 'onAuthenticated called from MyTrackerLoginPage');
          setPinLock(pinService.isPinSet() ? 'locked' : 'setup');
        }}
      />
    );
  }

  // authStatus === 'authenticated' من هنا فصاعدًا — Traccar مصادَق عليه
  // بالفعل؛ ما تبقّى هو فقط قفل PIN المحلي للتطبيق نفسه.
  if (pinLock === 'setup') {
    return <PinSetupPage onDone={() => setPinLock('open')} />;
  }

  if (pinLock === 'locked') {
    return <PinLockPage onUnlocked={() => setPinLock('open')} />;
  }

  return (
    <ServerProvider>
      <TraccarReduxBridge />
      {children}
    </ServerProvider>
  );
};

export default MyTrackerRoot;
