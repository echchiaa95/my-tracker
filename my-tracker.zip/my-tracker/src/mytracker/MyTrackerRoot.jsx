import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { sessionActions } from '../store';
import ServerProvider from '../ServerProvider';
import Loader from '../common/components/Loader';
import pinService from './services/pinService';
import traccarService, { ERROR_CODES } from './services/traccarService';
import PinSetupPage from './pages/PinSetupPage';
import PinLockPage from './pages/PinLockPage';
import MyTrackerLoginPage from './pages/MyTrackerLoginPage';
import TraccarReduxBridge from './TraccarReduxBridge';

/**
 * MyTrackerRoot — المصدر الوحيد للحقيقة بخصوص جلسة Traccar (مصدر وحيد،
 * بلا أي نظام مصادقة موازٍ — App.jsx الأصلي لا يحتوي أي منطق redirect).
 *
 * Traccar backend غير مرئي بالكامل للمستخدم: الرابط يأتي حصرًا من
 * VITE_TRACCAR_URL (لا يوجد حقل "Server URL" في أي شاشة).
 *
 *   authStatus = 'checking'        → Loader فقط، لا أي navigate إطلاقًا
 *   authStatus = 'unauthenticated' → MyTrackerLoginPage (بريد/كلمة مرور فقط)
 *   authStatus = 'authenticated'   → pinLock: 'setup' | 'locked' | 'open'
 *                                     'open' فقط يعرض التطبيق الفعلي
 */
const MyTrackerRoot = ({ children }) => {
  const dispatch = useDispatch();
  const [authStatus, setAuthStatus] = useState('checking'); // checking | unauthenticated | authenticated
  const [pinLock, setPinLock] = useState(null); // 'setup' | 'locked' | 'open'
  const [loginError, setLoginError] = useState(null);

  useEffect(() => {
    (async () => {
      // مصدر واحد للرابط: VITE_TRACCAR_URL فقط، لا رابط من المستخدم إطلاقًا.
      traccarService.configure(import.meta.env.VITE_TRACCAR_URL || '');

      // fetchSession() يُنفَّذ دائمًا قبل أي قرار — لا navigate ولا تغيير
      // حالة قبل معرفة نتيجته (يمنع بالضبط سباق "user فارغ مؤقتًا").
      const session = await traccarService.fetchSession();

      if (!session.ok) {
        setAuthStatus('unauthenticated');
        // عدم وجود جلسة بعد (401/404 حسب نسخة Traccar) عند أول فتح أمر
        // طبيعي تمامًا وليس خطأً — نعرض رسالة فقط لمشاكل اتصال حقيقية.
        if (session.error !== ERROR_CODES.AUTH_FAILED) {
          setLoginError(session.error);
        }
        return;
      }

      dispatch(sessionActions.updateUser(session.user));
      setAuthStatus('authenticated');
      setPinLock(pinService.isPinSet() ? 'locked' : 'setup');
    })();
    // يُنفَّذ هذا الأثر مرة واحدة فقط عند التحميل الأول — لا يُعاد تشغيله عند
    // نجاح تسجيل الدخول (ذلك يمر عبر onAuthenticated أدناه مباشرة).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch]);

  if (authStatus === 'checking') {
    return <Loader />;
  }

  if (authStatus === 'unauthenticated') {
    return (
      <MyTrackerLoginPage
        initialError={loginError}
        onAuthenticated={(user) => {
          dispatch(sessionActions.updateUser(user));
          setAuthStatus('authenticated');
          setPinLock(pinService.isPinSet() ? 'locked' : 'setup');
        }}
      />
    );
  }

  // authStatus === 'authenticated' من هنا فصاعدًا — Traccar مصادَق عليه
  // بالفعل؛ ما تبقّى هو فقط قفل PIN المحلي للتطبيق نفسه.
  if (pinLock === 'setup') {
    return <PinSetupPage onDone={() => setPinLock('open')} />;
  }

  if (pinLock === 'locked') {
    return <PinLockPage onUnlocked={() => setPinLock('open')} />;
  }

  return (
    <ServerProvider>
      <TraccarReduxBridge />
      {children}
    </ServerProvider>
  );
};

export default MyTrackerRoot;
