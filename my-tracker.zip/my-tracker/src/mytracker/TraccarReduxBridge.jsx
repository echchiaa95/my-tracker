import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { devicesActions } from '../store/devices';
import { sessionActions } from '../store';
import traccarService from './services/traccarService';

/**
 * TraccarReduxBridge — لا يحتوي أي منطق اتصال بـTraccar (المصادقة/الرابط/CORS).
 * دوره: (1) الجلب الأولي لـdevices/positions عند التركيب، (2) بدء التحديث
 * الحي (WS + polling fallback عبر traccarService)، (3) ضخّ كل التحديثات في
 * Redux الحالي (store/devices, store/session) حتى تستمر MainMap.jsx و
 * DeviceList.jsx وDashboardSummary.jsx بالعمل دون أي تعديل عليها.
 *
 * لاحقًا، عند الرغبة بإزالة Redux بالكامل، يكفي حذف هذا الملف واستبدال
 * المكونات التي تقرأ من useSelector بقراءة مباشرة من useTraccarData().
 */
const TraccarReduxBridge = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    let cancelled = false;

    (async () => {
      const devicesResult = await traccarService.getDevices();
      if (cancelled) return;
      if (devicesResult.ok) {
        dispatch(devicesActions.refresh(devicesResult.devices));
      } else {
        dispatch(sessionActions.updateSocket(false));
      }

      const positionsResult = await traccarService.getPositions();
      if (cancelled) return;
      if (positionsResult.ok) {
        dispatch(sessionActions.updatePositions(positionsResult.positions));
      }

      if (!cancelled) traccarService.startLive();
    })();

    const unsubscribe = traccarService.subscribe(({ type, payload }) => {
      if (type === 'positions') {
        dispatch(sessionActions.updatePositions(payload));
      } else if (type === 'devices') {
        dispatch(devicesActions.update(payload));
      } else if (type === 'status') {
        // يغذّي نفس state.session.socket الذي كان SocketController يحدّثه،
        // حتى تبقى مؤشرات NavBar/BottomMenu (Online/Reconnecting) صحيحة.
        dispatch(sessionActions.updateSocket(Boolean(payload.connected)));
      }
    });

    return () => {
      cancelled = true;
      unsubscribe();
      traccarService.stopLive();
    };
  }, [dispatch]);

  return null;
};

export default TraccarReduxBridge;
