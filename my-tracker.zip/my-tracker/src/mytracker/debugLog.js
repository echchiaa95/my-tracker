/**
 * debugLog — سجلّ تشخيص مؤقت ومرئي (وليس فقط console.log) لتتبّع مسار
 * المصادقة لحظة بلحظة. يُستخدم من MyTrackerLoginPage (لعرضه كصندوق Debug)
 * ومن MyTrackerRoot (لتسجيل أي انتقال لحالة unauthenticated من أي مصدر).
 *
 * تذكير: هذا أداة تشخيص مؤقتة — يُفترض إزالتها أو إخفاؤها خلف علم لاحقًا
 * بعد إيجاد السبب الجذري وإصلاحه نهائيًا.
 */

const entries = [];
const listeners = new Set();

function format(value) {
  if (typeof value === 'string') return value;
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

export function debugLog(...parts) {
  const line = parts.map(format).join(' ');
  const time = new Date().toISOString().slice(11, 23);
  const entry = `[${time}] ${line}`;
  entries.push(entry);
  // eslint-disable-next-line no-console
  console.log(line);
  listeners.forEach((fn) => fn([...entries]));
  return entry;
}

export function getDebugLog() {
  return [...entries];
}

export function subscribeDebugLog(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function clearDebugLog() {
  entries.length = 0;
  listeners.forEach((fn) => fn([]));
}
