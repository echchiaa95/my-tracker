import { SvgIcon } from '@mui/material';

/**
 * أيقونات محلية بسيطة (SvgIcon + مسارات SVG يدوية) خاصة بشاشة My Tracker
 * Login فقط. أُضيفت بديلاً عن استيراد فرعي من "@mui/icons-material" بعد
 * فشل vite/Rolldown في حلّ:
 *   @mui/icons-material/MailOutline
 *   @mui/icons-material/LockOutlined
 *   @mui/icons-material/NearMe
 * رغم أن الحزمة نفسها موجودة فعليًا في package.json/package-lock.json
 * وتُستخدم بنفس النمط (استيراد فرعي) بنجاح في باقي المشروع (مثال:
 * PersonIcon من '@mui/icons-material/Person' في BottomMenu.jsx). لتفادي
 * أي مخاطرة إضافية بلا اتصال شبكة للتحقق من توفر هذه الأسماء الثلاثة
 * تحديدًا في النسخة المثبَّتة، استُبدلت بأيقونات محلية لا تعتمد على أي
 * استيراد فرعي جديد من هذه الحزمة إطلاقًا — تستخدم فقط SvgIcon من
 * "@mui/material" (نفس الحزمة الأساسية المستخدمة في كل مكان بالمشروع دون
 * أي مشكلة).
 */

export const MailIcon = (props) => (
  <SvgIcon {...props} viewBox="0 0 24 24">
    <path
      d="M4 5h16a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
    />
    <path
      d="M3.5 6.5l8.5 6.5 8.5-6.5"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </SvgIcon>
);

export const LockIcon = (props) => (
  <SvgIcon {...props} viewBox="0 0 24 24">
    <rect x="5" y="11" width="14" height="9" rx="2" fill="none" stroke="currentColor" strokeWidth="1.6" />
    <path d="M8 11V7a4 4 0 0 1 8 0v4" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
  </SvgIcon>
);

export const LocationPinIcon = (props) => (
  <SvgIcon {...props} viewBox="0 0 24 24">
    <path
      d="M12 2C7.6 2 4 5.6 4 10c0 5.6 7 11.5 7.3 11.8.2.1.4.2.7.2s.5-.1.7-.2C13 21.5 20 15.6 20 10c0-4.4-3.6-8-8-8z"
      fill="currentColor"
    />
    <circle cx="12" cy="10" r="2.5" fill="#05070d" />
  </SvgIcon>
);
