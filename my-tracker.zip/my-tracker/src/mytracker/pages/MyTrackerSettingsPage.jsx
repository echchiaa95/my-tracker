import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  IconButton,
  Box,
  Button,
  Container,
  Divider,
  MenuItem,
  TextField,
  Typography,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import PinKeypad from '../components/PinKeypad';
import storageService from '../services/storageService';
import pinService from '../services/pinService';
import traccarService from '../services/traccarService';

/**
 * صفحة إعدادات خاصة بنسخة My Tracker (منفصلة عن settings/* الإدارية الأصلية
 * التي بقيت كما هي دون حذف، حسب القرار: "لا تنفذ Admin Dashboard الآن").
 */
const MyTrackerSettingsPage = () => {
  const navigate = useNavigate();
  const state = storageService.getState();
  const fileInputRef = useRef(null);

  const [appName, setAppName] = useState(state.settings.appName);
  const [theme, setTheme] = useState(state.settings.theme);
  const [message, setMessage] = useState(null);
  const [changePinOpen, setChangePinOpen] = useState(false);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  const saveGeneral = () => {
    storageService.update('settings', { appName, theme });
    setMessage({ severity: 'success', text: 'تم الحفظ' });
  };

  const handleExport = () => {
    const backup = storageService.exportBackup();
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'my-tracker-backup.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const result = storageService.importBackup(text);
    setMessage(
      result.ok
        ? { severity: 'success', text: 'تم الاستيراد بنجاح' }
        : { severity: 'error', text: result.error },
    );
    e.target.value = '';
  };

  const handleLockNow = () => {
    // Lock فوري: إعادة تحميل الصفحة تكفي لأن MyTrackerRoot سيطلب PIN من جديد
    window.location.reload();
  };

  const handleClearAll = () => {
    storageService.clearAll();
    pinService.removePin();
    traccarService.logout();
    setConfirmResetOpen(false);
    window.location.reload();
  };

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
      <AppBar position="sticky" color="default" elevation={1}>
        <Toolbar>
          <IconButton edge="start" onClick={() => navigate(-1)}>
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h6" sx={{ ml: 1 }}>إعدادات My Tracker</Typography>
        </Toolbar>
      </AppBar>
      <Container maxWidth="sm" sx={{ py: 2 }}>
        {message && (
          <Alert severity={message.severity} sx={{ mb: 2 }} onClose={() => setMessage(null)}>
            {message.text}
          </Alert>
        )}

        <Typography variant="subtitle1" gutterBottom>
          عام
        </Typography>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mb: 3 }}>
          <TextField label="اسم التطبيق" value={appName} onChange={(e) => setAppName(e.target.value)} />
          <TextField select label="المظهر" value={theme} onChange={(e) => setTheme(e.target.value)}>
            <MenuItem value="system">حسب النظام</MenuItem>
            <MenuItem value="dark">داكن</MenuItem>
            <MenuItem value="light">فاتح</MenuItem>
          </TextField>
          <Button variant="contained" onClick={saveGeneral}>حفظ</Button>
        </Box>

        <Divider sx={{ mb: 3 }} />

        <Typography variant="subtitle1" gutterBottom>
          الأمان
        </Typography>
        <Box sx={{ display: 'flex', gap: 2, mb: 3, flexWrap: 'wrap' }}>
          <Button variant="outlined" onClick={() => setChangePinOpen(true)}>تغيير PIN</Button>
          <Button variant="outlined" onClick={handleLockNow}>قفل التطبيق الآن</Button>
        </Box>

        <Divider sx={{ mb: 3 }} />

        <Typography variant="subtitle1" gutterBottom>
          البيانات
        </Typography>
        <Box sx={{ display: 'flex', gap: 2, mb: 3, flexWrap: 'wrap' }}>
          <Button variant="outlined" onClick={handleExport}>تصدير نسخة احتياطية</Button>
          <Button variant="outlined" onClick={() => fileInputRef.current?.click()}>استيراد نسخة احتياطية</Button>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/json"
            style={{ display: 'none' }}
            onChange={handleImportFile}
          />
          <Button variant="outlined" color="error" onClick={() => setConfirmResetOpen(true)}>
            حذف كل البيانات
          </Button>
        </Box>

        <ChangePinDialog open={changePinOpen} onClose={() => setChangePinOpen(false)} setMessage={setMessage} />

        <Dialog open={confirmResetOpen} onClose={() => setConfirmResetOpen(false)}>
          <DialogTitle>تأكيد الحذف</DialogTitle>
          <DialogContent>
            <Typography>
              سيتم حذف كل البيانات المحلية (الإعدادات، أسماء السيارات، PIN، رابط السيرفر) نهائيًا. هل أنت متأكد؟
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setConfirmResetOpen(false)}>إلغاء</Button>
            <Button color="error" onClick={handleClearAll}>حذف</Button>
          </DialogActions>
        </Dialog>
      </Container>
    </Box>
  );
};

const ChangePinDialog = ({ open, onClose, setMessage }) => {
  const [stage, setStage] = useState('old'); // old | new | confirm
  const [oldPin, setOldPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [value, setValue] = useState('');
  const [error, setError] = useState(false);

  const reset = () => {
    setStage('old');
    setOldPin('');
    setNewPin('');
    setValue('');
    setError(false);
  };

  const handleChange = async (next) => {
    setError(false);
    setValue(next);
    if (next.length !== 4) return;

    if (stage === 'old') {
      const valid = await pinService.verifyPin(next);
      if (!valid) {
        setError(true);
        setTimeout(() => setValue(''), 500);
        return;
      }
      setOldPin(next);
      setStage('new');
      setValue('');
    } else if (stage === 'new') {
      setNewPin(next);
      setStage('confirm');
      setValue('');
    } else {
      if (next === newPin) {
        await pinService.changePin(oldPin, next);
        setMessage({ severity: 'success', text: 'تم تغيير PIN' });
        onClose();
        reset();
      } else {
        setError(true);
        setTimeout(() => {
          setStage('new');
          setValue('');
          setError(false);
        }, 700);
      }
    }
  };

  const labels = { old: 'أدخل PIN الحالي', new: 'أدخل PIN جديد', confirm: 'أكّد PIN الجديد' };

  return (
    <Dialog
      open={open}
      onClose={() => {
        onClose();
        reset();
      }}
    >
      <DialogTitle>تغيير PIN</DialogTitle>
      <DialogContent>
        <Typography align="center" sx={{ mb: 2 }} color={error ? 'error' : 'textSecondary'}>
          {error ? 'رمز غير صحيح' : labels[stage]}
        </Typography>
        <PinKeypad value={value} onChange={handleChange} error={error} />
      </DialogContent>
    </Dialog>
  );
};

export default MyTrackerSettingsPage;
