import { useState } from 'react';
import { Box, Button, TextField, Typography, Alert, CircularProgress } from '@mui/material';
import LoginLayout from '../../login/LoginLayout';
import storageService from '../services/storageService';
import traccarService from '../services/traccarService';

/** إعداد رابط سيرفر Traccar + تسجيل الدخول. تُستخدم عند أول تشغيل وعند فشل الاتصال. */
const ServerSetupPage = ({ onConnected, initialError }) => {
  const saved = storageService.getState().traccar;
  const [serverUrl, setServerUrl] = useState(saved.serverUrl || '');
  const [email, setEmail] = useState(saved.email || '');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(saved.rememberSession || false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(initialError || null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const normalized = traccarService.configure(serverUrl);
    const result = await traccarService.login(email, password);

    if (!result.ok) {
      setError(result.error);
      setLoading(false);
      return;
    }

    storageService.update('traccar', {
      serverUrl: normalized,
      email: remember ? email : '',
      rememberSession: remember,
    });
    setLoading(false);
    onConnected(result.user);
  };

  return (
    <LoginLayout>
      <Typography variant="h5" gutterBottom>
        🚗 My Tracker
      </Typography>
      <Typography variant="body2" color="textSecondary" gutterBottom>
        اربط التطبيق بسيرفر Traccar الخاص بك
      </Typography>

      {error && (
        <Alert severity="error" sx={{ my: 2 }}>
          {error}
        </Alert>
      )}

      <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
        <TextField
          label="Traccar Server URL"
          placeholder="https://my-traccar-server.com"
          value={serverUrl}
          onChange={(e) => setServerUrl(e.target.value)}
          fullWidth
          required
        />
        <TextField
          label="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          fullWidth
          required
        />
        <TextField
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          fullWidth
          required
        />
        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14 }}>
          <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
          تذكر البريد الإلكتروني على هذا الجهاز
        </label>
        <Button type="submit" variant="contained" disabled={loading} fullWidth>
          {loading ? <CircularProgress size={22} /> : 'اتصال'}
        </Button>
      </Box>
    </LoginLayout>
  );
};

export default ServerSetupPage;
