import { useState } from 'react';
import { Box, Typography } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import LoginLayout from '../../login/LoginLayout';
import PinKeypad from '../components/PinKeypad';
import pinService from '../services/pinService';
import storageService from '../services/storageService';

const useStyles = makeStyles()((theme) => ({
  center: {
    textAlign: 'center',
    marginBottom: theme.spacing(4),
  },
}));

/**
 * أول تشغيل للتطبيق: إنشاء PIN ثم تأكيده. عند النجاح يستدعي onDone().
 * يعيد استخدام LoginLayout الأصلي (نفس الشكل والـsidebar) بدل تصميم جديد.
 */
const PinSetupPage = ({ onDone }) => {
  const { classes } = useStyles();
  const appName = storageService.getState().settings.appName;
  const [stage, setStage] = useState('create'); // 'create' | 'confirm'
  const [firstPin, setFirstPin] = useState('');
  const [value, setValue] = useState('');
  const [error, setError] = useState(false);

  const handleChange = async (next) => {
    setError(false);
    setValue(next);
    if (next.length !== 4) return;

    if (stage === 'create') {
      setFirstPin(next);
      setStage('confirm');
      setValue('');
      return;
    }

    if (next === firstPin) {
      await pinService.createPin(next);
      onDone();
    } else {
      setError(true);
      setTimeout(() => {
        setStage('create');
        setFirstPin('');
        setValue('');
        setError(false);
      }, 700);
    }
  };

  return (
    <LoginLayout>
      <Box className={classes.center}>
        <Typography variant="h5" gutterBottom>
          🔐 {appName}
        </Typography>
        <Typography variant="body1" color="textSecondary">
          {stage === 'create' ? 'أنشئ رمز PIN من 4 أرقام' : 'أكّد رمز PIN'}
        </Typography>
        {error && (
          <Typography variant="body2" color="error">
            الرمزان غير متطابقين، حاول مجددًا
          </Typography>
        )}
      </Box>
      <PinKeypad value={value} onChange={handleChange} error={error} />
    </LoginLayout>
  );
};

export default PinSetupPage;
