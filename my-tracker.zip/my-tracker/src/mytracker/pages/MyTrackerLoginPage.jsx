import { useState } from 'react';
import { Box, Button, TextField, Typography, Alert, CircularProgress, InputAdornment } from '@mui/material';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import NearMeIcon from '@mui/icons-material/NearMe';
import storageService from '../services/storageService';
import traccarService from '../services/traccarService';

/**
 * شاشة الدخول الخاصة بـMy Tracker: بريد إلكتروني وكلمة مرور فقط، بلا أي حقل
 * لرابط السيرفر — Traccar يبقى Backend غير مرئي للمستخدم النهائي بالكامل.
 * الرابط يأتي حصرًا من VITE_TRACCAR_URL (مصدر واحد للحقيقة).
 *
 * تصميم مستقل بالكامل (لا يُعيد استخدام LoginLayout.jsx المشترك) لسببين:
 * 1) الهوية البصرية السينمائية هنا مختلفة جذريًا عن نمط الإدارة العام.
 * 2) لا يوجد أي <form> في هذا الملف إطلاقًا — تفاديًا نهائيًا لمشكلة
 *    الـform المتداخل التي كانت تسبب Full Page Reload سابقًا. الزر عادي
 *    (type="button" + onClick)، تمامًا كما كان يعمل بعد الإصلاح.
 */
const MyTrackerLoginPage = ({ onAuthenticated, initialError }) => {
  const saved = storageService.getState().traccar;
  const [email, setEmail] = useState(saved.email || '');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(saved.rememberSession || false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(initialError || null);

  const handleLoginClick = async () => {
    if (loading) return; // يمنع الضغط المتكرر أثناء المعالجة
    if (!email || !password) return;

    setLoading(true);
    setError(null);

    const loginResult = await traccarService.login(email, password);
    if (!loginResult.ok) {
      setError(loginResult.error);
      setLoading(false);
      return;
    }

    const sessionResult = await traccarService.fetchSession();
    if (!sessionResult.ok) {
      setError(sessionResult.error);
      setLoading(false);
      return;
    }

    storageService.update('traccar', {
      email: remember ? email : '',
      rememberSession: remember,
    });
    setLoading(false);
    onAuthenticated(sessionResult.user);
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') handleLoginClick();
  };

  return (
    <Box className="mt-login-root">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@600;700&display=swap');
        @keyframes mtRoutePulse {
          0%   { stroke-dashoffset: 0; }
          100% { stroke-dashoffset: -240; }
        }
        @keyframes mtDotGlow {
          0%, 100% { opacity: 0.35; transform: scale(0.9); }
          50%      { opacity: 1;    transform: scale(1.15); }
        }
        @keyframes mtCardIn {
          from { opacity: 0; transform: translateY(14px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes mtAmbientDrift {
          0%   { transform: translate3d(0, 0, 0); }
          50%  { transform: translate3d(-2%, -1.5%, 0); }
          100% { transform: translate3d(0, 0, 0); }
        }
        .mt-login-root {
          position: relative;
          min-height: 100dvh;
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow-y: auto;
          background:
            radial-gradient(ellipse 60% 45% at 82% 8%, rgba(47,107,255,0.22), transparent 60%),
            radial-gradient(ellipse 50% 40% at 12% 92%, rgba(77,216,230,0.10), transparent 65%),
            linear-gradient(180deg, #05070d 0%, #0a1128 55%, #060912 100%);
          padding: 24px;
          box-sizing: border-box;
        }
        .mt-login-backdrop {
          position: fixed;
          inset: 0;
          overflow: hidden;
          z-index: 0;
          pointer-events: none;
        }
        .mt-login-grid {
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(148,190,255,0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(148,190,255,0.05) 1px, transparent 1px);
          background-size: 42px 42px;
          -webkit-mask-image: radial-gradient(ellipse 75% 65% at 60% 30%, black 40%, transparent 78%);
          mask-image: radial-gradient(ellipse 75% 65% at 60% 30%, black 40%, transparent 78%);
          animation: mtAmbientDrift 26s ease-in-out infinite;
        }
        .mt-login-scene {
          position: absolute;
          inset: -10%;
          opacity: 0.9;
        }
        .mt-login-dot {
          animation: mtDotGlow 3.6s ease-in-out infinite;
        }
        .mt-login-card {
          position: relative;
          z-index: 2;
          width: 100%;
          max-width: 380px;
          animation: mtCardIn 0.55s cubic-bezier(.2,.7,.3,1) both;
        }
        @media (prefers-reduced-motion: reduce) {
          .mt-login-grid, .mt-login-dot, .mt-login-card { animation: none !important; }
          .mt-login-route-line { animation: none !important; }
        }
      `}
      </style>

      {/* طبقة الخلفية الزخرفية بالكامل — position:fixed منفصلة عن تدفّق
          الصفحة، حتى تبقى الصفحة قابلة للتمرير طبيعيًا إن قصُر الارتفاع
          المتاح (مثلاً عند ظهور لوحة مفاتيح الهاتف)، فلا يختفي زر الدخول. */}
      <Box className="mt-login-backdrop">
        <Box className="mt-login-grid" />
        <Box
          component="svg"
          className="mt-login-scene"
          viewBox="0 0 800 600"
          preserveAspectRatio="xMidYMid slice"
        >
          <path
            className="mt-login-route-line"
            d="M -40 520 C 160 460, 220 300, 380 260 S 620 140, 860 60"
            fill="none"
            stroke="url(#mtRouteGradient)"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeDasharray="10 14"
            style={{ animation: 'mtRoutePulse 7s linear infinite', filter: 'drop-shadow(0 0 6px rgba(77,216,230,0.55))' }}
          />
          <defs>
            <linearGradient id="mtRouteGradient" x1="0" y1="1" x2="1" y2="0">
              <stop offset="0%" stopColor="rgba(255,122,69,0.55)" />
              <stop offset="45%" stopColor="rgba(77,216,230,0.75)" />
              <stop offset="100%" stopColor="rgba(47,107,255,0.85)" />
            </linearGradient>
          </defs>
          <circle className="mt-login-dot" cx="380" cy="260" r="5" fill="#4dd8e6" style={{ filter: 'drop-shadow(0 0 8px #4dd8e6)' }} />
          <circle className="mt-login-dot" cx="620" cy="140" r="4" fill="#2f6bff" style={{ animationDelay: '1.1s', filter: 'drop-shadow(0 0 8px #2f6bff)' }} />
          <circle className="mt-login-dot" cx="160" cy="460" r="3.5" fill="#ff7a45" style={{ animationDelay: '2s', filter: 'drop-shadow(0 0 8px #ff7a45)' }} />
        </Box>
      </Box>

      {/* بطاقة الدخول — Premium glass panel */}
      <Box
        className="mt-login-card"
        sx={{
          background: 'linear-gradient(160deg, rgba(16,22,38,0.72), rgba(8,11,20,0.82))',
          backdropFilter: 'blur(18px)',
          WebkitBackdropFilter: 'blur(18px)',
          border: '1px solid rgba(148,190,255,0.14)',
          borderRadius: '20px',
          boxShadow: '0 24px 60px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.02) inset',
          p: { xs: 3, sm: 4.5 },
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
          <Box
            sx={{
              width: 34, height: 34, borderRadius: '10px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: 'linear-gradient(135deg, #2f6bff, #4dd8e6)',
              boxShadow: '0 0 18px rgba(47,107,255,0.55)',
            }}
          >
            <NearMeIcon sx={{ fontSize: 18, color: '#05070d' }} />
          </Box>
          <Typography
            sx={{
              fontFamily: "'Space Grotesk', 'Roboto', sans-serif",
              fontWeight: 700,
              fontSize: 20,
              letterSpacing: '0.08em',
              color: '#f5f3ee',
            }}
          >
            MY TRACKER
          </Typography>
        </Box>
        <Typography sx={{ color: 'rgba(210,220,235,0.6)', fontSize: 13, letterSpacing: '0.04em', mb: 3 }}>
          Track. Control. Protect.
        </Typography>

        {error && (
          <Alert
            severity="error"
            sx={{
              mb: 2,
              bgcolor: 'rgba(255,90,60,0.12)',
              color: '#ffb4a2',
              border: '1px solid rgba(255,90,60,0.3)',
              '& .MuiAlert-icon': { color: '#ff7a45' },
            }}
          >
            {error}
          </Alert>
        )}

        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <TextField
            label="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            fullWidth
            required
            autoFocus
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <MailOutlineIcon sx={{ fontSize: 19, color: 'rgba(210,220,235,0.5)' }} />
                </InputAdornment>
              ),
            }}
            sx={loginFieldSx}
          />
          <TextField
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={handleKeyDown}
            fullWidth
            required
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <LockOutlinedIcon sx={{ fontSize: 19, color: 'rgba(210,220,235,0.5)' }} />
                </InputAdornment>
              ),
            }}
            sx={loginFieldSx}
          />
          <Box component="label" sx={{ display: 'flex', alignItems: 'center', gap: 1, fontSize: 13, color: 'rgba(210,220,235,0.65)', cursor: 'pointer' }}>
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
            تذكر البريد الإلكتروني على هذا الجهاز
          </Box>

          {/* زر عادي — type="button"، ليس داخل أي <form>. لا تُعِد إضافة
              <form> هنا أبدًا (انظر التعليق أعلى الملف). */}
          <Button
            type="button"
            onClick={handleLoginClick}
            disabled={loading}
            fullWidth
            sx={{
              mt: 0.5,
              py: 1.3,
              borderRadius: '12px',
              fontWeight: 700,
              letterSpacing: '0.06em',
              color: '#05070d',
              background: 'linear-gradient(135deg, #4dd8e6, #2f6bff)',
              boxShadow: '0 10px 28px rgba(47,107,255,0.35)',
              transition: 'transform 0.15s ease, box-shadow 0.15s ease',
              '&:hover': {
                background: 'linear-gradient(135deg, #5fe0ec, #3d78ff)',
                boxShadow: '0 12px 32px rgba(47,107,255,0.5)',
                transform: 'translateY(-1px)',
              },
              '&:disabled': { opacity: 0.7, color: '#05070d' },
            }}
          >
            {loading ? (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
                <CircularProgress size={16} sx={{ color: '#05070d' }} />
                SIGNING IN...
              </Box>
            ) : (
              'تسجيل الدخول'
            )}
          </Button>
        </Box>
      </Box>
    </Box>
  );
};

const loginFieldSx = {
  '& .MuiOutlinedInput-root': {
    color: '#f5f3ee',
    borderRadius: '10px',
    background: 'rgba(255,255,255,0.03)',
    '& fieldset': { borderColor: 'rgba(148,190,255,0.18)' },
    '&:hover fieldset': { borderColor: 'rgba(148,190,255,0.35)' },
    '&.Mui-focused fieldset': { borderColor: '#4dd8e6', boxShadow: '0 0 0 3px rgba(77,216,230,0.15)' },
  },
  '& .MuiInputLabel-root': { color: 'rgba(210,220,235,0.55)' },
  '& .MuiInputLabel-root.Mui-focused': { color: '#4dd8e6' },
};

export default MyTrackerLoginPage;
