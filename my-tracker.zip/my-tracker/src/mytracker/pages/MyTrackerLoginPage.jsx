import { useState } from 'react';
import { Box, Button, TextField, Typography, Alert, CircularProgress } from '@mui/material';
import LoginLayout from '../../login/LoginLayout';
import storageService from '../services/storageService';
import traccarService from '../services/traccarService';

/**
 * شاشة الدخول الخاصة بـMy Tracker فقط: بريد إلكتروني وكلمة مرور، بلا أي حقل
 * لرابط السيرفر — Traccar يبقى Backend غير مرئي للمستخدم النهائي بالكامل.
 * الرابط يأتي حصرًا من VITE_TRACCAR_URL (مصدر واحد للحقيقة).
 * (كانت تُسمّى سابقًا ServerSetupPage عندما كان المستخدم يُدخل الرابط يدويًا.)
 */
const MyTrackerLoginPage = ({ onAuthenticated, initialError }) => {
  const saved = storageService.getState().traccar;
  const [email, setEmail] = useState(saved.email || '');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(saved.rememberSession || false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(initialError || null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // traccarService مُهيَّأ مسبقًا من MyTrackerRoot بـVITE_TRACCAR_URL —
    // لا يُعاد ضبطه هنا، ولا يوجد أي رابط يُدخله المستخدم.
    const result = await traccarService.login(email, password);

    if (!result.ok) {
      setError(result.error);
      setLoading(false);
      return;
    }

    storageService.update('traccar', {
      email: remember ? email : '',
      rememberSession: remember,
    });
    setLoading(false);
    onAuthenticated(result.user);
  };

  return (
    <LoginLayout>
      <Typography variant="h5" gutterBottom>
        🚗 My Tracker
      </Typography>
      <Typography variant="body2" color="textSecondary" gutterBottom>
        سجّل الدخول لمتابعة سياراتك
      </Typography>

      {error && (
        <Alert severity="error" sx={{ my: 2 }}>
          {error}
        </Alert>
      )}

      <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
        <TextField
          label="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          fullWidth
          required
          autoFocus
        />
        <TextField
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          fullWidth
          required
        />
        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14 }}>
          <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
          تذكر البريد الإلكتروني على هذا الجهاز
        </label>
        <Button type="submit" variant="contained" disabled={loading} fullWidth>
          {loading ? <CircularProgress size={22} /> : 'تسجيل الدخول'}
        </Button>
      </Box>
    </LoginLayout>
  );
};

export default MyTrackerLoginPage;
