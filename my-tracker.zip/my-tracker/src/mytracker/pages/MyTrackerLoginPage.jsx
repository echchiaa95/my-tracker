import { useEffect, useState } from 'react';
import { Box, Button, TextField, Typography, Alert, CircularProgress } from '@mui/material';
import LoginLayout from '../../login/LoginLayout';
import storageService from '../services/storageService';
import traccarService from '../services/traccarService';
import { debugLog, getDebugLog, subscribeDebugLog, clearDebugLog } from '../debugLog';

/**
 * شاشة الدخول الخاصة بـMy Tracker فقط: بريد إلكتروني وكلمة مرور، بلا أي حقل
 * لرابط السيرفر — Traccar يبقى Backend غير مرئي للمستخدم النهائي بالكامل.
 * الرابط يأتي حصرًا من VITE_TRACCAR_URL (مصدر واحد للحقيقة).
 */
const MyTrackerLoginPage = ({ onAuthenticated, initialError }) => {
  const saved = storageService.getState().traccar;
  const [email, setEmail] = useState(saved.email || '');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(saved.rememberSession || false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(initialError || null);
  const [debugLines, setDebugLines] = useState(getDebugLog());

  useEffect(() => subscribeDebugLog(setDebugLines), []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    clearDebugLog();

    debugLog('[1] بدأ تسجيل الدخول');

    debugLog('[2] POST', `${traccarService.baseUrl}/api/session`);
    const loginResult = await traccarService.login(email, password);
    debugLog('[3] HTTP status:', loginResult.status ?? (loginResult.ok ? 'OK' : loginResult.error));

    if (!loginResult.ok) {
      debugLog('❌ POST فشل — التوقف هنا. رسالة الخطأ الكاملة:', loginResult.error);
      setError(loginResult.error);
      setLoading(false);
      return;
    }
    debugLog('[4] POST انتهى بنجاح');

    debugLog('[5] بدء GET', `${traccarService.baseUrl}/api/session`);
    const sessionResult = await traccarService.fetchSession();
    debugLog('[6] GET status:', sessionResult.status ?? (sessionResult.ok ? 'OK' : sessionResult.error));

    if (!sessionResult.ok) {
      debugLog(
        '❌ GET /api/session فشل رغم نجاح POST — التوقف هنا. هذا يعني أن الكوكي لم يُخزَّن أو لم يُرسَل من المتصفح. رسالة الخطأ الكاملة:',
        sessionResult.error,
      );
      setError(sessionResult.error);
      setLoading(false);
      return;
    }
    debugLog('[7] بيانات المستخدم:', { id: sessionResult.user?.id, email: sessionResult.user?.email });

    storageService.update('traccar', {
      email: remember ? email : '',
      rememberSession: remember,
    });
    setLoading(false);

    debugLog('[8] onAuthenticated تم استدعاؤها');
    onAuthenticated(sessionResult.user);
    debugLog('[9] authStatus أصبح authenticated (سيؤكده MyTrackerRoot أعلاه)');
    debugLog('[10] الانتقال إلى التطبيق الرئيسي — إذا رأيت هذه الشاشة بعد هذا السطر فالمشكلة ليست في تسجيل الدخول نفسه بل فيما يحدث بعده مباشرة');
  };

  return (
    <LoginLayout>
      <Typography variant="h5" gutterBottom>
        🚗 My Tracker
      </Typography>
      <Typography variant="body2" color="textSecondary" gutterBottom>
        سجّل الدخول لمتابعة سياراتك
      </Typography>

      {error && (
        <Alert severity="error" sx={{ my: 2, whiteSpace: 'pre-wrap' }}>
          {error}
        </Alert>
      )}

      <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
        <TextField
          label="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          fullWidth
          required
          autoFocus
        />
        <TextField
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          fullWidth
          required
        />
        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14 }}>
          <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
          تذكر البريد الإلكتروني على هذا الجهاز
        </label>
        <Button type="submit" variant="contained" disabled={loading} fullWidth>
          {loading ? <CircularProgress size={22} /> : 'تسجيل الدخول'}
        </Button>

        {/* صندوق Debug مؤقت — يُظهر تسلسل المصادقة لحظة بلحظة على الشاشة
            مباشرة، بلا حاجة لفتح Console المطوّر. يُزال لاحقًا بعد إيجاد
            السبب الجذري نهائيًا. */}
        {debugLines.length > 0 && (
          <Box
            sx={{
              mt: 1,
              p: 1.5,
              bgcolor: '#111',
              color: '#0f0',
              fontFamily: 'monospace',
              fontSize: 12,
              borderRadius: 1,
              maxHeight: 260,
              overflowY: 'auto',
              whiteSpace: 'pre-wrap',
              direction: 'ltr',
              textAlign: 'left',
            }}
          >
            <Typography variant="caption" sx={{ color: '#888', display: 'block', mb: 0.5 }}>
              DEBUG (مؤقت)
            </Typography>
            {debugLines.map((line, i) => (
              // eslint-disable-next-line react/no-array-index-key
              <div key={i}>{line}</div>
            ))}
          </Box>
        )}
      </Box>
    </LoginLayout>
  );
};

export default MyTrackerLoginPage;
