import { useEffect, useState } from 'react';
import { Box, Button, TextField, Typography, Alert, CircularProgress } from '@mui/material';
import LoginLayout from '../../login/LoginLayout';
import storageService from '../services/storageService';
import traccarService from '../services/traccarService';
import { debugLog, getDebugLog, subscribeDebugLog, clearDebugLog } from '../debugLog';

/**
 * شاشة الدخول الخاصة بـMy Tracker فقط: بريد إلكتروني وكلمة مرور، بلا أي حقل
 * لرابط السيرفر — Traccar يبقى Backend غير مرئي للمستخدم النهائي بالكامل.
 * الرابط يأتي حصرًا من VITE_TRACCAR_URL (مصدر واحد للحقيقة).
 *
 * مهم جدًا: LoginLayout يحيط بمحتواه بـ<form> خاص به بالفعل. لا تضع أي
 * <form> ثانٍ داخله ولا زر type="submit" — هذا بالضبط ما كان يسبب
 * Full Page Reload عند الضغط على الزر (form متداخل داخل form = HTML غير
 * صالح، والمتصفح كان يُرسِل الـform الخارجي بدل استدعاء onSubmit الداخلي).
 * الحل: زر عادي بـonClick، بنفس النمط المستخدم فعليًا في LoginPage.jsx
 * الأصلي لنفس المشروع (يستخدم Button onClick={handlePasswordLogin} بلا أي
 * form على الإطلاق).
 */
const MyTrackerLoginPage = ({ onAuthenticated, initialError }) => {
  const saved = storageService.getState().traccar;
  const [email, setEmail] = useState(saved.email || '');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(saved.rememberSession || false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(initialError || null);
  const [debugLines, setDebugLines] = useState(getDebugLog());

  useEffect(() => subscribeDebugLog(setDebugLines), []);

  const handleLoginClick = async (event) => {
    // لا حاجة لـpreventDefault هنا أصلًا (لا form ولا submit event)، لكن
    // نُبقيها كحماية إضافية إن استُدعيت الدالة يومًا من حدث آخر.
    event?.preventDefault?.();
    debugLog('AUTH: LOGIN BUTTON CLICKED');

    if (!email || !password) {
      debugLog('AUTH: missing credentials');
      return;
    }

    setLoading(true);
    setError(null);
    clearDebugLog();

    try {
      debugLog('AUTH: handleSubmit entered');
      debugLog('[1] بدأ تسجيل الدخول');
      debugLog('AUTH: calling onLogin');

      const loginResult = await traccarService.login(email, password);
      debugLog('[3] HTTP status:', loginResult.status ?? (loginResult.ok ? 'OK' : loginResult.error));

      if (!loginResult.ok) {
        debugLog('❌ POST فشل — التوقف هنا. رسالة الخطأ الكاملة:', loginResult.error);
        setError(loginResult.error);
        setLoading(false);
        return;
      }
      debugLog('[4] POST انتهى بنجاح');

      debugLog('[5] بدء GET', `${traccarService.baseUrl}/api/session`);
      const sessionResult = await traccarService.fetchSession();
      debugLog('AUTH: GET session after login status =', sessionResult.status ?? '(network error)');
      debugLog('AUTH: GET session after login body =', sessionResult.body?.slice(0, 300) ?? sessionResult.error);
      debugLog('[6] GET status:', sessionResult.status ?? (sessionResult.ok ? 'OK' : sessionResult.error));

      if (!sessionResult.ok) {
        debugLog(
          '❌ GET /api/session فشل رغم نجاح POST — التوقف هنا. رسالة الخطأ الكاملة:',
          sessionResult.error,
        );
        setError(sessionResult.error);
        setLoading(false);
        return;
      }
      debugLog('[7] بيانات المستخدم:', { id: sessionResult.user?.id, email: sessionResult.user?.email });

      storageService.update('traccar', {
        email: remember ? email : '',
        rememberSession: remember,
      });
      setLoading(false);

      debugLog('[8] onAuthenticated تم استدعاؤها');
      onAuthenticated(sessionResult.user);
      debugLog('[9] authStatus أصبح authenticated (سيؤكده MyTrackerRoot أعلاه)');
      debugLog('[10] الانتقال إلى التطبيق الرئيسي');
    } catch (unexpectedError) {
      // console.error كما طلبت، بالإضافة لعرضه في صندوق Debug المرئي حتى
      // لا يحتاج المستخدم فتح Console لرؤيته.
      // eslint-disable-next-line no-console
      console.error('AUTH: login error', unexpectedError);
      debugLog('❌ AUTH: login error (استثناء غير متوقَّع) =', unexpectedError?.message || String(unexpectedError));
      setError(String(unexpectedError?.message || unexpectedError));
      setLoading(false);
    }
  };

  const handleKeyDown = (event) => {
    // يسمح بالضغط على Enter داخل حقل كلمة المرور، دون أي <form>.
    if (event.key === 'Enter') {
      handleLoginClick(event);
    }
  };

  return (
    <LoginLayout>
      <Typography variant="h5" gutterBottom>
        🚗 My Tracker
      </Typography>
      <Typography variant="body2" color="textSecondary" gutterBottom>
        سجّل الدخول لمتابعة سياراتك
      </Typography>

      {error && (
        <Alert severity="error" sx={{ my: 2, whiteSpace: 'pre-wrap' }}>
          {error}
        </Alert>
      )}

      {/* لا component="form" هنا عمدًا — انظر التعليق أعلى الملف. */}
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
        <TextField
          label="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          fullWidth
          required
          autoFocus
        />
        <TextField
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyDown={handleKeyDown}
          fullWidth
          required
        />
        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 14 }}>
          <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
          تذكر البريد الإلكتروني على هذا الجهاز
        </label>
        {/* لا type="submit" — زر عادي فقط، بنفس نمط LoginPage.jsx الأصلي. */}
        <Button type="button" variant="contained" disabled={loading} fullWidth onClick={handleLoginClick}>
          {loading ? <CircularProgress size={22} /> : 'تسجيل الدخول'}
        </Button>

        {/* صندوق Debug مؤقت — يُظهر تسلسل المصادقة لحظة بلحظة على الشاشة
            مباشرة، بلا حاجة لفتح Console المطوّر. يُزال لاحقًا بعد إيجاد
            السبب الجذري نهائيًا. */}
        {debugLines.length > 0 && (
          <Box
            sx={{
              mt: 1,
              p: 1.5,
              bgcolor: '#111',
              color: '#0f0',
              fontFamily: 'monospace',
              fontSize: 12,
              borderRadius: 1,
              maxHeight: 260,
              overflowY: 'auto',
              whiteSpace: 'pre-wrap',
              direction: 'ltr',
              textAlign: 'left',
            }}
          >
            <Typography variant="caption" sx={{ color: '#888', display: 'block', mb: 0.5 }}>
              DEBUG (مؤقت)
            </Typography>
            {debugLines.map((line, i) => (
              // eslint-disable-next-line react/no-array-index-key
              <div key={i}>{line}</div>
            ))}
          </Box>
        )}
      </Box>
    </LoginLayout>
  );
};

export default MyTrackerLoginPage;
