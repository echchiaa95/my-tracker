import { useState } from 'react';
import { Box, Typography } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import LoginLayout from '../../login/LoginLayout';
import PinKeypad from '../components/PinKeypad';
import pinService from '../services/pinService';
import storageService from '../services/storageService';

const useStyles = makeStyles()((theme) => ({
  center: {
    textAlign: 'center',
    marginBottom: theme.spacing(4),
  },
}));

/** شاشة إدخال PIN عند فتح التطبيق أو بعد Lock. */
const PinLockPage = ({ onUnlocked }) => {
  const { classes } = useStyles();
  const appName = storageService.getState().settings.appName;
  const [value, setValue] = useState('');
  const [error, setError] = useState(false);

  const handleChange = async (next) => {
    setError(false);
    setValue(next);
    if (next.length !== 4) return;

    const valid = await pinService.verifyPin(next);
    if (valid) {
      onUnlocked();
    } else {
      setError(true);
      setTimeout(() => {
        setValue('');
        setError(false);
      }, 500);
    }
  };

  return (
    <LoginLayout>
      <Box className={classes.center}>
        <Typography variant="h5" gutterBottom>
          🔐 {appName}
        </Typography>
        <Typography variant="body1" color="textSecondary">
          أدخل رمز PIN
        </Typography>
        {error && (
          <Typography variant="body2" color="error">
            رمز غير صحيح
          </Typography>
        )}
      </Box>
      <PinKeypad value={value} onChange={handleChange} error={error} />
    </LoginLayout>
  );
};

export default PinLockPage;
