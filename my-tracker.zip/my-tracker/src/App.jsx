import { Outlet, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useMediaQuery, useTheme } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import BottomMenu from './common/components/BottomMenu';
import CachingController from './CachingController';
import { useCatch } from './reactHelper';
import { sessionActions } from './store';
import UpdateController from './UpdateController';
import MotionController from './main/MotionController';
import TermsDialog from './common/components/TermsDialog';
import Loader from './common/components/Loader';
import fetchOrThrow from './common/util/fetchOrThrow';

const useStyles = makeStyles()(() => ({
  page: {
    flexGrow: 1,
    overflow: 'auto',
  },
  menu: {
    zIndex: 4,
    '@media print': {
      display: 'none',
    },
  },
}));

const App = () => {
  const { classes } = useStyles();
  const theme = useTheme();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const desktop = useMediaQuery(theme.breakpoints.up('md'));

  const termsUrl = useSelector((state) => state.session.server.attributes.termsUrl);
  const user = useSelector((state) => state.session.user);

  const acceptTerms = useCatch(async () => {
    const response = await fetchOrThrow(`/api/users/${user.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...user, attributes: { ...user.attributes, termsAccepted: true } }),
    });
    dispatch(sessionActions.updateUser(await response.json()));
  });

  // ملاحظة My Tracker: الكود الأصلي هنا كان يحتوي useAsyncTask يتحقق من
  // "if (!user)" ثم يستدعي fetch('/api/session') ثم navigate('/login') عند
  // الفشل — أي نظام مصادقة موازٍ ومتنافس مع MyTrackerRoot (الذي يضمن وجود
  // user في Redux قبل تركيب <App/> أصلًا عبر MyTrackerRoot.jsx). كان هذا
  // النظام الموازي هو السبب الفعلي لعودة التطبيق إلى /login (LoginPage
  // الأصلية) بعد نجاح تسجيل الدخول: أي لحظة يكون فيها user فارغًا مؤقتًا
  // كانت تُطلق navigate('/login') فورًا. أُزيل هنا لأن MyTrackerRoot هو
  // المصدر الوحيد الآن لحالة المصادقة (matches requirement: "مصدر واحد
  // للحقيقة بالنسبة لجلسة Traccar").

  if (user == null) {
    return <Loader />;
  }
  if (termsUrl && !user.attributes.termsAccepted) {
    return <TermsDialog open onCancel={() => navigate('/login')} onAccept={() => acceptTerms()} />;
  }
  return (
    <>
      {/* SocketController الأصلي مُعطَّل في نسخة My Tracker: كان يفتح اتصال
          WebSocket بمسار نسبي (/api/socket) يفترض أن Traccar على نفس الدومين،
          وهو ما لا ينطبق عند النشر على GitHub Pages. TraccarReduxBridge
          (مُفعَّل من MyTrackerRoot) يقوم بنفس دور ضخّ positions/devices في
          Redux، لكن عبر TraccarService الذي يدعم دومين Traccar المختلف. */}
      <CachingController />
      <UpdateController />
      <MotionController />
      <div className={classes.page}>
        <Outlet />
      </div>
      {!desktop && (
        <div className={classes.menu}>
          <BottomMenu />
        </div>
      )}
    </>
  );
};

export default App;
