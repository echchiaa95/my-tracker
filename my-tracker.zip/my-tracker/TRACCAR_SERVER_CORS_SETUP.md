# إعداد سيرفر Traccar (traccar.elbordiji.com) للعمل مع GitHub Pages

هذا الملف **لا يُطبَّق تلقائيًا** — هو الإعداد المطلوب على سيرفر Traccar نفسه
(وليس في مشروع my-tracker)، لأن الواجهة الأمامية لا يمكنها تجاوز CORS من
جهتها. بدون هذا الإعداد، تسجيل الدخول سيفشل بخطأ CORS في المتصفح رغم صحة
الرابط وكلمة المرور.

## لماذا هذا ضروري

- التطبيق يعمل على: `https://echchiaa95.github.io`
- Traccar يعمل على: `https://traccar.elbordiji.com`
- نطاقان مختلفان تمامًا، والمصادقة تعتمد على **session cookie**. المتصفح
  يمنع هذا افتراضيًا ما لم يصرّح السيرفر بشكل صريح.

## المطلوب من السيرفر (عادة عبر Nginx/Traefik أمام Traccar، وليس Traccar نفسه)

أضف هذه الترويسات (Headers) على كل استجابات `/api/*`:

```
Access-Control-Allow-Origin: https://echchiaa95.github.io
Access-Control-Allow-Credentials: true
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
Access-Control-Allow-Headers: Content-Type, Authorization
```

ملاحظة مهمة: عند استخدام `Access-Control-Allow-Credentials: true` يُمنع
استخدام `*` في `Access-Control-Allow-Origin` — يجب أن يكون الدومين محددًا
بالضبط كما أعلاه.

مثال Nginx (كـ reverse proxy أمام Traccar):

```nginx
location /api/ {
    add_header Access-Control-Allow-Origin "https://echchiaa95.github.io" always;
    add_header Access-Control-Allow-Credentials "true" always;
    add_header Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS" always;
    add_header Access-Control-Allow-Headers "Content-Type, Authorization" always;

    if ($request_method = OPTIONS) {
        return 204;
    }

    proxy_pass http://127.0.0.1:8082;
    proxy_set_header Host $host;
}
```

## كوكي الجلسة

يجب أن يكون الكوكي الذي يضبطه Traccar عند تسجيل الدخول:

```
Secure; SameSite=None
```

بدون `SameSite=None; Secure` سيرفضه المتصفح تمامًا عند إرساله من دومين مختلف
(GitHub Pages)، بغض النظر عن صحة إعدادات CORS.

## WebSocket

المسار `wss://traccar.elbordiji.com/api/socket` يعتمد على نفس كوكي الجلسة
(لا يمكن للمتصفح إرسال Authorization header يدويًا في اتصال WebSocket)، لذلك
إعداد الكوكي أعلاه (`SameSite=None; Secure`) شرط لعمل التحديث المباشر أيضًا،
وليس فقط REST API.

## إذا تعذّر ضبط هذا على السيرفر

التطبيق (my-tracker) مبني بالفعل ليتعامل مع هذه الحالة بأمان دون أن يتوقف:
عند فشل WebSocket ينتقل تلقائيًا لـ Polling، وعند فشل تسجيل الدخول تظهر
رسالة خطأ واضحة (`Cannot connect to Traccar` أو `Authentication failed`)
بدل توقف صامت. لكن لا حل بديل آمن لمشكلة CORS/Cookies نفسها من جهة الواجهة
فقط — هذا الإعداد على السيرفر شرط لا غنى عنه لتسجيل الدخول عبر GitHub Pages.
