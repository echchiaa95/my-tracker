/**
 * My Tracker — Native Android Wi-Fi TCP bridge for ELM327 OBD-II adapters.
 *
 * Conceptual API exposed to the JavaScript layer (AndroidWifiAdapter):
 *   connect(ip, port, timeoutMs) / disconnect() / send(data) / getState()
 * plus streaming events: 'data' (RX chunks), 'disconnected' (socket loss),
 * 'log' (debug trace used by the developer debug panel).
 */

export interface ConnectOptions {
  /** Adapter IPv4 address, e.g. "192.168.0.10". Validated on the native side. */
  ip: string;
  /** Adapter TCP port, e.g. 35000. Validated on the native side. */
  port: number;
  /** TCP connect timeout in milliseconds. */
  timeoutMs: number;
}

export interface ConnectResult {
  connected: boolean;
  /** "ip:port" actually connected to — echoed back for display. */
  remoteInfo: string;
}

export interface SendOptions {
  /** Raw text to write (ELM327 ASCII, usually already terminated with \r). */
  data: string;
}

export interface DataEvent {
  /** Incoming ASCII chunk from the adapter (ISO-8859-1 decoded). */
  chunk: string;
}

export interface DisconnectedEvent {
  /** Machine reason: 'closed' | 'reset' | 'refused' | 'timeout' | 'error' | 'local' */
  reason: string;
  /** Human-readable technical detail (debug only, never shown raw to users). */
  detail: string;
}

export interface LogEvent {
  direction: 'tx' | 'rx' | 'sys';
  text: string;
  at: number;
}

export interface StateResult {
  connected: boolean;
}

export interface ObdWifiPlugin {
  connect(options: ConnectOptions): Promise<ConnectResult>;
  disconnect(): Promise<void>;
  send(options: SendOptions): Promise<void>;
  getState(): Promise<StateResult>;

  addListener(eventName: 'data', listenerFunc: (event: DataEvent) => void): Promise<import('@capacitor/core').PluginListenerHandle>;
  addListener(eventName: 'disconnected', listenerFunc: (event: DisconnectedEvent) => void): Promise<import('@capacitor/core').PluginListenerHandle>;
  addListener(eventName: 'log', listenerFunc: (event: LogEvent) => void): Promise<import('@capacitor/core').PluginListenerHandle>;
  removeAllListeners(): Promise<void>;
}
