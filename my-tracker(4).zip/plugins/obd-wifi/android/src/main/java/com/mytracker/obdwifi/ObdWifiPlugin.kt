package com.mytracker.obdwifi

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.InputStream
import java.net.ConnectException
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NoRouteToHostException
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.nio.charset.StandardCharsets
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * جسر Wi-Fi TCP الأصلي لأجهزة ELM327 (My Tracker).
 *
 * المبادئ:
 * - خيط مستقل للقراءة حتى لا يحجب الإرسال (منع تجميد الواجهة).
 * - كل محاولة اتصال لها مهلة زمنية.
 * - منع تعدد الاتصالات المتزامنة.
 * - ربط الـsocket فقط بشبكة Wi-Fi (Network.bindSocket) — لا نغير شبكة التطبيق
 *   الافتراضية أبدًا (لا bindProcessToNetwork) حتى يبقى الإنترنت عبر 4G/5G.
 * - اكتشاف تلقائي محلي (شبكة فرعية فقط) مع تحقق بـ ATZ/ATI من هوية ELM327.
 * - أحداث streaming: data / disconnected / log (للوحة debug).
 */
@CapacitorPlugin(name = "ObdWifi")
class ObdWifiPlugin : Plugin() {

    private var socket: Socket? = null
    private val connected = AtomicBoolean(false)
    private val reading = AtomicBoolean(false)
    private val detecting = AtomicBoolean(false)
    private var detectExecutor: ExecutorService? = null

    companion object {
        private val PROBE_PORTS = intArrayOf(35000, 5000, 50000, 23)
        private const val PROBE_CONNECT_MS = 600
        private const val PROBE_READ_MS = 1000
        private const val PROBE_CONCURRENCY = 4
    }

    /* ---------- أدوات مساعدة ---------- */

    private fun emitLog(direction: String, text: String) {
        val o = JSObject()
        o.put("direction", direction)
        o.put("text", text)
        o.put("at", System.currentTimeMillis())
        notifyListeners("log", o)
    }

    private fun notifyDisconnected(reason: String, detail: String) {
        val o = JSObject()
        o.put("reason", reason)
        o.put("detail", detail)
        notifyListeners("disconnected", o)
    }

    private fun closeQuietly() {
        try { socket?.close() } catch (_: Exception) { }
        socket = null
    }

    /**
     * إيجاد كائن Network الخاص بشبكة Wi-Fi المتصلة حاليًا.
     * لا يتطلب صلاحيات خاصة. يعيد null إذا لم يكن هناك Wi-Fi متصل.
     */
    private fun wifiNetwork(): Network? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return null
        val nets: Array<Network> = cm.allNetworks ?: return null
        for (n in nets) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            ) {
                return n
            }
        }
        return null
    }

    /** ربط الـsocket بشبكة Wi-Fi فقط (دون المساس بالشبكة الافتراضية للتطبيق). */
    private fun bindToWifi(s: Socket): Boolean {
        return try {
            val net = wifiNetwork() ?: return false
            net.bindSocket(s)
            emitLog("sys", "socket bound to Wi-Fi network")
            true
        } catch (e: Exception) {
            emitLog("sys", "Wi-Fi bind skipped: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    private fun gatewayOf(cm: ConnectivityManager, net: Network): String? {
        val lp: LinkProperties = cm.getLinkProperties(net) ?: return null
        for (r in lp.routes) {
            val gw = r.gateway
            if (r.isDefaultRoute && gw is Inet4Address) return gw.hostAddress
        }
        // احتياطي: خادم DHCP
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val g = wm?.dhcpInfo?.gateway ?: 0
        if (g != 0) {
            return "%d.%d.%d.%d".format(g and 0xFF, g shr 8 and 0xFF, g shr 16 and 0xFF, g shr 24 and 0xFF)
        }
        return null
    }

    private fun deviceWifiIp(cm: ConnectivityManager, net: Network): String? {
        val lp = cm.getLinkProperties(net) ?: return null
        for (a in lp.linkAddresses) {
            val addr = a.address
            if (addr is Inet4Address && !addr.isLoopbackAddress) return addr.hostAddress
        }
        return null
    }

    /** بادئة الشبكة الفرعية (prefixLength) لعنوان IPv4 الخاص بالجهاز على Wi-Fi. */
    private fun wifiPrefixLength(cm: ConnectivityManager, net: Network): Int? {
        val lp = cm.getLinkProperties(net) ?: return null
        for (a in lp.linkAddresses) {
            val addr = a.address
            if (addr is Inet4Address && !addr.isLoopbackAddress) return a.prefixLength
        }
        return null
    }

    private fun ipv4ToInt(ip: String): Int? {
        val p = ip.split(".")
        if (p.size != 4) return null
        var r = 0
        for (s in p) {
            val v = s.toIntOrNull() ?: return null
            if (v !in 0..255) return null
            r = r shl 8 or v
        }
        return r
    }

    private fun intToIpv4(i: Int): String =
        "%d.%d.%d.%d".format(i shr 24 and 0xFF, i shr 16 and 0xFF, i shr 8 and 0xFF, i and 0xFF)

    /* ---------- API: معلومات Wi-Fi (PART 1) ---------- */

    @PluginMethod
    fun getWifiInfo(call: PluginCall) {
        thread(name = "obd-wifiinfo") {
            try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val net = wifiNetwork()
                val o = JSObject()
                if (cm == null || net == null) {
                    o.put("connected", false)
                    emitLog("sys", "Wi-Fi network required")
                    call.resolve(o)
                    return@thread
                }
                o.put("connected", true)
                // SSID فقط إذا كان الإذن ممنوحًا أصلًا — لا نطلب Location أبدًا
                try {
                    val granted = Build.VERSION.SDK_INT < 26 ||
                        context.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED
                    if (granted) {
                        val wm = context.applicationContext
                            .getSystemService(Context.WIFI_SERVICE) as? WifiManager
                        val ssid = wm?.connectionInfo?.ssid?.trim('"')
                        if (!ssid.isNullOrEmpty() && ssid != "<unknown ssid>") o.put("ssid", ssid)
                    }
                } catch (_: Exception) { }
                deviceWifiIp(cm, net)?.let { o.put("ip", it) }
                gatewayOf(cm, net)?.let { o.put("gateway", it) }
                emitLog("sys", "Wi-Fi network available")
                call.resolve(o)
            } catch (e: Exception) {
                call.reject("WIFI_INFO_FAILED", e)
            }
        }
    }

    /* ---------- API: اكتشاف ELM327 (PART 2+3) ---------- */

    @PluginMethod
    fun detect(call: PluginCall) {
        if (!detecting.compareAndSet(false, true)) {
            return call.reject("DETECT_RUNNING")
        }
        detectExecutor?.shutdownNow()
        val exec: ExecutorService = Executors.newFixedThreadPool(PROBE_CONCURRENCY)
        detectExecutor = exec
        emitLog("sys", "ELM327 detection started")
        thread(name = "obd-detect") {
            try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val net = wifiNetwork()
                if (cm == null || net == null) {
                    emitLog("sys", "Wi-Fi network required")
                    call.resolve(JSObject().put("detected", false))
                    return@thread
                }
                // مرشحون من الشبكة الفرعية المحلية فقط — لا مسح خارجي أبدًا.
                // الاستراتيجية: العناوين الشائعة أولًا، ثم تعداد فعلي لشبكة الـ/24
                // المحلية المأخوذة من LinkProperties (prefixLength) عند توفرها.
                // إذا تعذّر الحصول على معلومات الشبكة الفرعية نكتفي بالقائمة المخمّنة
                // (auto-detection بذلك يكون best-effort وليس شاملًا مضمونًا).
                val candidates = LinkedHashSet<String>()
                val gw = gatewayOf(cm, net)
                val devIp = deviceWifiIp(cm, net)
                val base = gw ?: devIp
                if (base != null) {
                    val parts = base.split(".")
                    if (parts.size == 4) {
                        // تخمينات شائعة أولًا (أسرع اصطياد)
                        candidates.add(base)
                        candidates.add("${parts[0]}.${parts[1]}.${parts[2]}.10")
                        candidates.add("${parts[0]}.${parts[1]}.${parts[2]}.100")
                        candidates.add("${parts[0]}.${parts[1]}.${parts[2]}.1")
                        candidates.add("${parts[0]}.${parts[1]}.${parts[2]}.254")
                    }
                }
                // تعداد فعلي للشبكة الفرعية المحلية (/24 أو أصغر) عند توفر البادئة
                val prefix = wifiPrefixLength(cm, net)
                if (devIp != null && prefix != null && prefix in 24..31) {
                    val ipInt = ipv4ToInt(devIp)
                    if (ipInt != null) {
                        val mask = -1 shl (32 - prefix)
                        val network = ipInt and mask
                        val hostCount = (1 shl (32 - prefix)) - 2
                        if (hostCount in 1..254) {
                            for (h in 1..hostCount) {
                                val a = network + h
                                candidates.add(intToIpv4(a))
                            }
                        }
                    }
                }
                // حد أمان إجمالي لعدد المرشحين
                val finalCandidates = candidates.take(256)
                if (finalCandidates.isEmpty()) {
                    emitLog("sys", "no local subnet available — auto-detect is best-effort")
                    call.resolve(JSObject().put("detected", false))
                    return@thread
                }
                emitLog("sys", "candidate scan started: ${finalCandidates.size} IPs x ${PROBE_PORTS.size} ports (local subnet only)")

                val found = java.util.concurrent.LinkedBlockingQueue<Pair<String, Int>>()
                val stop = AtomicBoolean(false)

                for (ip in finalCandidates) {
                    if (stop.get()) break
                    for (port in PROBE_PORTS) {
                        if (stop.get()) break
                        exec.submit {
                            if (stop.get()) return@submit
                            emitLog("sys", "testing $ip:$port")
                            val r = probe(ip, port, net)
                            if (r && stop.compareAndSet(false, true)) {
                                found.put(ip to port)
                                emitLog("sys", "ELM327 detected at $ip:$port")
                            }
                        }
                    }
                }
                val hit = found.poll(20, TimeUnit.SECONDS)
                if (hit != null) {
                    val o = JSObject()
                    o.put("detected", true)
                    o.put("ip", hit.first)
                    o.put("port", hit.second)
                    call.resolve(o)
                } else {
                    emitLog("sys", "detection failed: no ELM327 answered")
                    call.resolve(JSObject().put("detected", false))
                }
            } catch (e: Exception) {
                emitLog("sys", "detection error: ${e.javaClass.simpleName}")
                call.reject("DETECT_FAILED", e)
            } finally {
                try { exec.shutdownNow() } catch (_: Exception) { }
                detecting.set(false)
            }
        }
    }

    /** فحص منفذ واحد مع تحقق من هوية ELM327 (ATZ ثم ATI عند الحاجة). */
    private fun probe(ip: String, port: Int, net: Network): Boolean {
        var s: Socket? = null
        try {
            s = Socket()
            net.bindSocket(s) // حصر الفحص على شبكة Wi-Fi المحلية
            s.connect(InetSocketAddress(ip, port), PROBE_CONNECT_MS)
            emitLog("sys", "TCP connected $ip:$port (probe)")
            val out = s.getOutputStream()
            out.write("ATZ\r".toByteArray(StandardCharsets.ISO_8859_1))
            out.flush()
            emitLog("sys", "ELM327 probe sent (ATZ)")
            val resp = readProbe(s.getInputStream(), PROBE_READ_MS)
            if (isElmResponse(resp)) {
                emitLog("sys", "ELM327 response received")
                return true
            }
            // محاولة ثانية: ATI
            out.write("ATI\r".toByteArray(StandardCharsets.ISO_8859_1))
            out.flush()
            emitLog("sys", "ELM327 probe sent (ATI)")
            return isElmResponse(readProbe(s.getInputStream(), PROBE_READ_MS))
        } catch (_: Exception) {
            return false
        } finally {
            try { s?.close() } catch (_: Exception) { }
        }
    }

    private fun readProbe(input: InputStream, timeoutMs: Int): String {
        val deadline = System.currentTimeMillis() + timeoutMs
        val sb = StringBuilder()
        val buf = ByteArray(256)
        s@ while (System.currentTimeMillis() < deadline) {
            if (input.available() > 0) {
                val n = input.read(buf, 0, minOf(buf.size, input.available()))
                if (n > 0) sb.append(String(buf, 0, n, StandardCharsets.ISO_8859_1))
                if (sb.contains(">")) break@s
            } else {
                try { Thread.sleep(25) } catch (_: InterruptedException) { break@s }
            }
        }
        return sb.toString()
    }

    private fun isElmResponse(r: String): Boolean {
        if (r.isBlank()) return false
        val up = r.uppercase()
        return up.contains("ELM327") || up.contains("OK") || up.contains(">") ||
            up.contains("BUS") || up.contains("SEARCHING") || up.contains("ELM")
    }

    /* ---------- API: الاتصال مع الربط بالشبكة (PART 4+5) ---------- */

    @PluginMethod
    fun connect(call: PluginCall) {
        val ip = call.getString("ip")?.trim().orEmpty()
        val port = call.getInt("port", -1) ?: -1
        val timeoutMs = (call.getLong("timeoutMs", 8000L) ?: 8000L).coerceIn(1000L, 60000L)

        if (!isValidIp(ip)) return call.reject("INVALID_IP")
        if (port < 1 || port > 65535) return call.reject("INVALID_PORT")

        // إلغاء أي فحص جارٍ ثم إغلاق أي اتصال سابق (منع التعدد)
        detectExecutor?.shutdownNow()
        detecting.set(false)
        if (connected.getAndSet(false)) {
            reading.set(false)
            closeQuietly()
        }

        thread(name = "obd-connect") {
            var s: Socket? = null
            try {
                s = Socket()
                if (!bindToWifi(s)) {
                    // لا توجد شبكة Wi-Fi — رفض فوري بدل انتظار مهلة عبر 4G
                    try { s.close() } catch (_: Exception) { }
                    emitLog("sys", "connect aborted: no Wi-Fi network")
                    return@thread call.reject("WIFI_NETWORK_REQUIRED")
                }
                emitLog("sys", "TCP connect $ip:$port (timeout ${timeoutMs}ms)")
                s.connect(InetSocketAddress(ip, port), timeoutMs.toInt())
                socket = s
                connected.set(true)
                emitLog("sys", "TCP connected: ${s.remoteSocketAddress}")
                startReadLoop(s)
                val ret = JSObject()
                ret.put("connected", true)
                ret.put("remoteInfo", "$ip:$port")
                call.resolve(ret)
            } catch (e: Exception) {
                try { s?.close() } catch (_: Exception) { }
                connected.set(false)
                socket = null
                emitLog("sys", "connect failed: ${e.javaClass.simpleName}: ${e.message}")
                val code = when (e) {
                    is SocketTimeoutException -> "TIMEOUT"
                    is ConnectException -> "CONNECTION_REFUSED"
                    is NoRouteToHostException, is UnknownHostException -> "UNREACHABLE"
                    else -> "CONNECT_FAILED"
                }
                call.reject(code, e)
            }
        }
    }

    private fun startReadLoop(s: Socket) {
        reading.set(true)
        thread(name = "obd-read") {
            val buf = ByteArray(1024)
            try {
                val input: InputStream = s.getInputStream()
                while (reading.get() && !s.isClosed) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (n > 0) {
                        val chunk = String(buf, 0, n, StandardCharsets.ISO_8859_1)
                        emitLog("rx", chunk)
                        val o = JSObject()
                        o.put("chunk", chunk)
                        notifyListeners("data", o)
                    }
                }
                handleDrop("closed", "stream ended")
            } catch (e: Exception) {
                handleDrop("error", "${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    /** انقطاع غير متوقع فقط — لا يُستدعى عند فصل طلبه المستخدم. */
    private fun handleDrop(reason: String, detail: String) {
        if (!connected.getAndSet(false)) return
        reading.set(false)
        closeQuietly()
        emitLog("sys", "disconnected: $reason — $detail")
        notifyDisconnected(reason, detail)
    }

    @PluginMethod
    fun send(call: PluginCall) {
        val data = call.getString("data") ?: return call.reject("EMPTY")
        if (!connected.get()) return call.reject("NOT_CONNECTED")
        thread(name = "obd-write") {
            try {
                val out = socket?.getOutputStream()
                out?.write(data.toByteArray(StandardCharsets.ISO_8859_1))
                out?.flush()
                emitLog("tx", data)
                call.resolve()
            } catch (e: Exception) {
                emitLog("sys", "write failed: ${e.message}")
                call.reject("WRITE_FAILED", e)
            }
        }
    }

    @PluginMethod
    fun disconnect(call: PluginCall) {
        detectExecutor?.shutdownNow()
        detecting.set(false)
        thread(name = "obd-disconnect") {
            if (connected.getAndSet(false)) {
                reading.set(false)
                closeQuietly()
                emitLog("sys", "disconnect (local)")
            }
            call.resolve()
        }
    }

    @PluginMethod
    fun getState(call: PluginCall) {
        val o = JSObject()
        o.put("connected", connected.get())
        call.resolve(o)
    }

    override fun handleOnDestroy() {
        detectExecutor?.shutdownNow()
        reading.set(false)
        connected.set(false)
        closeQuietly()
    }

    private fun isValidIp(ip: String): Boolean {
        val parts = ip.split(".")
        if (parts.size != 4) return false
        return parts.all { p ->
            val v = p.toIntOrNull() ?: return@all false
            v in 0..255 && p.length <= 3 && (p == "0" || !p.startsWith("0"))
        }
    }
}
