import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mytracker.app',
  appName: 'My Tracker',
  webDir: 'build',
  backgroundColor: '#05070d',
  android: {
    allowMixedContent: false,
  },
};

export default config;
