import { useSelector } from 'react-redux';
import { ThemeProvider } from '@mui/material';
import { CacheProvider } from '@emotion/react';
import createCache from '@emotion/cache';
import { prefixer } from 'stylis';
import rtlPlugin from 'stylis-plugin-rtl';
import theme from './common/theme';
import { useLocalization } from './common/components/LocalizationProvider';
import storageService from './mytracker/services/storageService';

const cache = {
  ltr: createCache({
    key: 'muiltr',
    stylisPlugins: [prefixer],
  }),
  rtl: createCache({
    key: 'muirtl',
    stylisPlugins: [prefixer, rtlPlugin],
  }),
};

const AppThemeProvider = ({ children }) => {
  const server = useSelector((state) => state.session.server);
  const { direction, language } = useLocalization();

  const serverDarkMode = server?.attributes?.darkMode;

  // هوية My Tracker سينمائية داكنة افتراضيًا (نفس مرجع صفحات Diagnostics).
  // الأولوية: اختيار المستخدم الصريح من "إعدادات My Tracker" (فاتح/داكن)،
  // ثم إعداد السيرفر، ثم النظام — والافتراضي عند 'system' هو الداكن.
  const mtTheme = storageService.getState().settings.theme; // 'dark' | 'light' | 'system'
  const darkMode =
    mtTheme === 'light'
      ? false
      : mtTheme === 'dark'
        ? true
        : serverDarkMode !== undefined
          ? serverDarkMode
          : true;

  const themeInstance = theme(server, darkMode, direction, language);

  return (
    <CacheProvider value={cache[direction]}>
      <ThemeProvider theme={themeInstance}>{children}</ThemeProvider>
    </CacheProvider>
  );
};

export default AppThemeProvider;
