import { useMemo } from 'react';
import { createTheme } from '@mui/material/styles';
import palette from './palette';
import dimensions from './dimensions';
import components from './components';
import { radius, typography as typographyTokens } from './tokens';

// اللغة العربية تستخدم IBM Plex Sans Arabic كخط أساسي للعناوين والنص معًا؛
// اللغات اللاتينية تستخدم زوج Plus Jakarta Sans (عناوين) + Inter (نص).
// Roboto يبقى fallback أخير — لا حذف، فقط أولوية جديدة.
export default (server, darkMode, direction, language) =>
  useMemo(() => {
    const isArabic = language === 'ar';
    return createTheme({
      typography: {
        fontFamily: isArabic
          ? typographyTokens.fontFamilyArabic
          : typographyTokens.fontFamilyLatinBody,
        h1: {
          fontFamily: isArabic
            ? typographyTokens.fontFamilyArabic
            : typographyTokens.fontFamilyLatinDisplay,
        },
        h2: {
          fontFamily: isArabic
            ? typographyTokens.fontFamilyArabic
            : typographyTokens.fontFamilyLatinDisplay,
        },
        h3: {
          fontFamily: isArabic
            ? typographyTokens.fontFamilyArabic
            : typographyTokens.fontFamilyLatinDisplay,
        },
        h4: {
          fontFamily: isArabic
            ? typographyTokens.fontFamilyArabic
            : typographyTokens.fontFamilyLatinDisplay,
        },
        h5: {
          fontFamily: isArabic
            ? typographyTokens.fontFamilyArabic
            : typographyTokens.fontFamilyLatinDisplay,
        },
        h6: {
          fontFamily: isArabic
            ? typographyTokens.fontFamilyArabic
            : typographyTokens.fontFamilyLatinDisplay,
        },
      },
      shape: {
        borderRadius: radius.md,
      },
      palette: palette(server, darkMode),
      direction,
      dimensions,
      components,
    });
  }, [server, darkMode, direction, language]);
