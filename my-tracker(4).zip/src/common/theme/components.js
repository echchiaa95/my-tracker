export default {
  MuiUseMediaQuery: {
    defaultProps: {
      noSsr: true,
    },
  },
  // هوية My Tracker الداكنة على مستوى الصفحة كلها: خلفية سينمائية ثابتة
  // (نفس تدرّج صفحات Diagnostics) بدل لون مسطح. في الوضع الفاتح لا تغيير.
  MuiCssBaseline: {
    styleOverrides: (theme) =>
      theme.palette.mode === 'dark'
        ? {
            body: {
              backgroundColor: '#05070d',
              backgroundImage:
                'radial-gradient(ellipse 70% 40% at 85% 0%, rgba(47,107,255,0.14), transparent 60%), radial-gradient(ellipse 50% 35% at 8% 100%, rgba(77,216,230,0.07), transparent 65%), linear-gradient(180deg, #05070d 0%, #0a1128 60%, #060912 100%)',
              backgroundAttachment: 'fixed',
              color: '#e8eefc',
            },
          }
        : {},
  },
  MuiAppBar: {
    styleOverrides: {
      root: ({ theme }) =>
        theme.palette.mode === 'dark'
          ? {
              backgroundColor: 'rgba(13,21,38,0.85)',
              backdropFilter: 'blur(14px)',
              borderBottom: '1px solid rgba(120,160,255,0.14)',
              backgroundImage: 'none',
            }
          : {},
    },
  },
  MuiDrawer: {
    styleOverrides: {
      paper: ({ theme }) =>
        theme.palette.mode === 'dark'
          ? {
              backgroundColor: '#0a1128',
              backgroundImage: 'none',
              borderInlineStart: '1px solid rgba(120,160,255,0.14)',
            }
          : {},
    },
  },
  MuiBottomNavigation: {
    styleOverrides: {
      root: ({ theme }) =>
        theme.palette.mode === 'dark'
          ? {
              backgroundColor: 'rgba(10,17,40,0.92)',
              backdropFilter: 'blur(14px)',
              borderTop: '1px solid rgba(120,160,255,0.14)',
            }
          : {},
    },
  },
  MuiBottomNavigationAction: {
    styleOverrides: {
      root: ({ theme }) =>
        theme.palette.mode === 'dark'
          ? {
              color: '#8a94a6',
              '&.Mui-selected': {
                color: '#4dd8e6',
              },
            }
          : {},
    },
  },
  MuiDialog: {
    styleOverrides: {
      paper: ({ theme }) =>
        theme.palette.mode === 'dark'
          ? {
              backgroundColor: '#0a1128',
              backgroundImage: 'none',
              border: '1px solid rgba(120,160,255,0.14)',
            }
          : {},
    },
  },
  MuiOutlinedInput: {
    styleOverrides: {
      root: ({ theme }) => ({
        backgroundColor: theme.palette.background.default,
        borderRadius: theme.shape.borderRadius,
      }),
    },
  },
  MuiButton: {
    defaultProps: {
      disableElevation: true, // منتج SaaS نظيف — لا ظلال قوية على الأزرار (متطلب صريح من العميل)
    },
    styleOverrides: {
      root: {
        textTransform: 'none', // النصوص العربية/الفرنسية لا تُكتب Uppercase
        fontWeight: 600,
      },
      sizeMedium: {
        height: '40px',
      },
    },
  },
  MuiCard: {
    styleOverrides: {
      root: ({ theme }) => ({
        borderRadius: theme.shape.borderRadius,
        boxShadow: 'none',
        border: `1px solid ${theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.08)' : 'rgba(15,23,32,0.08)'}`,
      }),
    },
  },
  MuiChip: {
    styleOverrides: {
      root: ({ theme }) => ({
        borderRadius: theme.shape.borderRadius,
        fontWeight: 600,
      }),
    },
  },
  MuiPaper: {
    styleOverrides: {
      root: {
        backgroundImage: 'none', // يمنع تدرّج MUI الافتراضي للـelevation في Dark mode
      },
    },
  },
  MuiFormControl: {
    defaultProps: {
      size: 'small',
    },
  },
  MuiSnackbar: {
    defaultProps: {
      anchorOrigin: {
        vertical: 'bottom',
        horizontal: 'center',
      },
    },
  },
  MuiTooltip: {
    defaultProps: {
      enterDelay: 500,
      enterNextDelay: 500,
    },
  },
  MuiTableCell: {
    styleOverrides: {
      root: ({ theme }) => ({
        '@media print': {
          color: theme.palette.alwaysDark.main,
        },
      }),
    },
  },
};
