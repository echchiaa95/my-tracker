import { grey } from '@mui/material/colors';
import { brandColors, statusColors, myTrackerDark } from './tokens';

const validatedColor = (color) => (/^#([0-9A-Fa-f]{3}){1,2}$/.test(color) ? color : null);

// القيم الافتراضية الجديدة (Route Teal) — يبقى السيرفر قادرًا على استبدالها بالكامل
// عبر server.attributes.colorPrimary/colorSecondary، بدون أي تغيير في هذه الآلية.
// الوضع الداكن يستخدم هوية My Tracker السينمائية (نفس مرجع صفحات Diagnostics).
export default (server, darkMode) => ({
  mode: darkMode ? 'dark' : 'light',
  background: darkMode
    ? {
        default: myTrackerDark.bgDeep,
        paper: myTrackerDark.surface,
      }
    : {
        default: brandColors.mist,
      },
  primary: {
    main:
      validatedColor(server?.attributes?.colorPrimary) ||
      (darkMode ? myTrackerDark.electricBlue : brandColors.routeTeal),
  },
  secondary: {
    main:
      validatedColor(server?.attributes?.colorSecondary) ||
      (darkMode ? myTrackerDark.cyan : statusColors.moving),
  },
  neutral: {
    main: grey[500],
  },
  geometry: {
    main: '#3bb2d0',
  },
  alwaysDark: {
    main: grey[900],
  },
  // نظام حالة السيارة الموحّد (Status Pulse) — انظر ./status.js لآلية الاستخدام
  vehicleStatus: statusColors,
});
