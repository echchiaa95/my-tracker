import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Box, Typography, Dialog, DialogTitle, DialogContent, DialogActions, TextField } from '@mui/material';
import {
  DiagPage,
  GlassCard,
  SectionTitle,
  MutedText,
  PrimaryButton,
  GhostButton,
  TestModeBanner,
  DiagHeader,
  EmptyState,
  ErrorCard,
  injectDiagStyles,
  DIAG_COLORS,
} from '../components/diagUi';
import {
  DiagCarIcon,
  BluetoothIcon,
  UsbIcon,
  WifiIcon,
  WifiOffIcon,
  FlaskIcon,
  BackIcon,
  ClearIcon,
  RescanIcon,
  ReportIcon,
  ShareIcon,
  CheckIcon,
} from '../components/DiagIcons';
import { HealthGauge, DtcCard, LiveDataGrid, ScanStepRow } from '../components/DiagWidgets';
import { useDiagT } from '../services/diagL10n';
import diagnosticService from '../services/diagnosticService';
import { explainDtc } from '../services/dtcDictionary';
import { analyze } from '../services/analysisEngine';
import historyStore from '../services/historyStore';
import { openPrintableReport, shareReport } from '../services/reportView';
import { describeError } from '../services/errorMessages';
import storageService from '../../services/storageService';

const SCAN_STEP_KEYS = ['init', 'vin', 'supported', 'dtc', 'freeze', 'live'];
const STEP_LABEL_KEY = {
  init: 'stepInit',
  vin: 'stepVin',
  supported: 'stepSupported',
  dtc: 'stepDtc',
  freeze: 'stepFreeze',
  live: 'stepLive',
};

const initialSteps = () => Object.fromEntries(SCAN_STEP_KEYS.map((k) => [k, 'pending']));

/** معلومات المركبة من بيانات Traccar الموجودة — الحقول الناقصة تبقى '—'. */
function extractVehicleInfo(device) {
  const a = device?.attributes || {};
  return {
    make: a.make || '—',
    model: a.model || '—',
    year: a.year || '—',
    engine: a.engine || '—',
    fuelType: a.fuelType || a.fuel || '—',
    vin: a.vin || null,
  };
}

/**
 * DiagnosticScanPage — رحلة الفحص الكاملة:
 * Select Vehicle → Compatibility/Connect → Scan (بخطوات مرئية) → Result.
 */
const DiagnosticScanPage = () => {
  injectDiagStyles();
  const navigate = useNavigate();
  const { t, lang } = useDiagT();
  const devices = useSelector((state) => Object.values(state.devices.items));
  const customNames = storageService.getState().vehicles || {};

  const [phase, setPhase] = useState('select'); // select | connect | scanning | result
  const [vehicle, setVehicle] = useState(null);
  const [conn, setConn] = useState(() => diagnosticService.snapshot());
  const [steps, setSteps] = useState(initialSteps);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null); // { analysis, raw, sessionId }
  const [clearDialog, setClearDialog] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [clearOutcome, setClearOutcome] = useState(null); // {status, summary}
  const [notice, setNotice] = useState(null);
  // Wi-Fi OBD (Android native فقط): لوحة الاتصال بحفظ IP/Port محليًا
  const [wifiOpen, setWifiOpen] = useState(false);
  const [wifiCfg, setWifiCfg] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('mytracker.wifi.cfg')) || { ip: '', port: '35000' };
    } catch {
      return { ip: '', port: '35000' };
    }
  });
  const [wifiBusy, setWifiBusy] = useState(false);
  const [wifiDetect, setWifiDetect] = useState('idle'); // idle|running|found|none|error
  const [rtLive, setRtLive] = useState(null);
  const [showDebug, setShowDebug] = useState(false);
  const [, setDebugTick] = useState(0);
  const mountedRef = useRef(true);

  // تحديث سجل debug المعروض أثناء الفحص
  useEffect(() => {
    if (!showDebug) return undefined;
    const id = setInterval(() => setDebugTick((n) => n + 1), 600);
    return () => clearInterval(id);
  }, [showDebug]);

  // لوحة "مباشر": لقطات PID حية أثناء بقاء الاتصال في شاشة النتائج
  useEffect(() => {
    if (phase !== 'result') { setRtLive(null); return undefined; }
    let cancelled = false;
    let timer = null;
    const tick = async () => {
      try {
        const snap = await diagnosticService.readLiveSnapshot(lang);
        if (!cancelled) setRtLive(snap);
      } catch { /* الاتصال غير جاهز — نتوقف بصمت */ }
      if (!cancelled) timer = setTimeout(tick, 2500);
    };
    tick();
    return () => { cancelled = true; if (timer) clearTimeout(timer); };
  }, [phase, lang]);

  useEffect(() => {
    mountedRef.current = true;
    const unsub = diagnosticService.subscribe((s) => {
      if (mountedRef.current) setConn(s);
    });
    return () => {
      mountedRef.current = false;
      unsub();
      diagnosticService.disconnect(); // مغادرة الصفحة = إنهاء جلسة OBD
    };
  }, []);

  // كشف التوافق قد يسبق اكتمال حقن جسر Capacitor الأصلي في WebView بعض
  // الأجهزة — نعيد التقييم قصيرًا بعد الإقلاع بدل الاكتفاء بقيمة التصيير الأولى.
  // في المتصفح العادي تبقى القيمة false دائمًا (لا تغيير في سلوك Web).
  const [compat, setCompat] = useState(() => diagnosticService.checkCompatibility());
  useEffect(() => {
    const id = setInterval(() => {
      setCompat(diagnosticService.checkCompatibility());
    }, 400);
    const stop = setTimeout(() => clearInterval(id), 6000);
    return () => {
      clearInterval(id);
      clearTimeout(stop);
    };
  }, []);

  const vehicleDisplayName = (d) => customNames[d.id]?.customName || d.name;

  /* ---------- اختيار المركبة ---------- */
  const pickVehicle = (d) => {
    setVehicle(d);
    setError(null);
    setPhase('connect');
  };

  /* ---------- الاتصال ---------- */
  const connect = async (type) => {
    setError(null);
    const r = await diagnosticService.connect(type);
    if (!r.ok) {
      if (r.error === 'BLE_CANCELLED' || r.error === 'SERIAL_CANCELLED') return; // إلغاء المستخدم
      setError(r.error);
      return;
    }
    startScan();
  };

  /* ---------- اتصال Wi-Fi OBD (Android native) ---------- */
  const connectWifi = async () => {
    setError(null);
    setWifiBusy(true);
    localStorage.setItem('mytracker.wifi.cfg', JSON.stringify(wifiCfg));
    const r = await diagnosticService.connect('wifi', {
      ip: wifiCfg.ip,
      port: Number(wifiCfg.port),
      timeoutMs: 8000,
    });
    setWifiBusy(false);
    if (!r.ok) {
      setError(r.error);
      return;
    }
    startScan();
  };

  const detectWifiAdapter = async () => {
    if (wifiDetect === 'running') return;

    setWifiDetect('running');

    try {
      const r = await diagnosticService.detectWifiAdapter();

      const ip = r?.ip ? String(r.ip).trim() : '';
      const port = r?.port ? Number(r.port) : null;

      if (ip && port) {
        const cfg = {
          ip,
          port: String(port),
        };

        setWifiCfg(cfg);

        try {
          localStorage.setItem(
            'mytracker.wifi.cfg',
            JSON.stringify(cfg)
          );
        } catch {
          // localStorage failure must not break detection
        }

        setWifiDetect('found');
      } else {
        setWifiDetect('none');
      }
    } catch (error) {
      console.error('[WiFi OBD] Auto detection failed:', error);
      setWifiDetect('error');
    }
  };

  const wifiFieldSx = {
    flex: 1,
    '& .MuiOutlinedInput-root': {
      color: DIAG_COLORS.text,
      fontSize: 14,
      borderRadius: 2,
      background: 'rgba(255,255,255,.04)',
      '& fieldset': { borderColor: 'rgba(255,255,255,.14)' },
      '&:hover fieldset': { borderColor: 'rgba(0,229,255,.4)' },
      '&.Mui-focused fieldset': { borderColor: DIAG_COLORS.cyan },
    },
    '& .MuiInputLabel-root': { color: 'rgba(255,255,255,.55)', fontSize: 13 },
  };

  /* ---------- الفحص ---------- */
  const startScan = async () => {
    setPhase('scanning');
    setSteps(initialSteps());
    setError(null);
    try {
      const raw = await diagnosticService.scan((key, status) => {
        if (mountedRef.current) setSteps((prev) => ({ ...prev, [key]: status }));
      });
      const analysis = analyze(raw, lang);
      const info = extractVehicleInfo(vehicle);
      const session = historyStore.save({
        vehicleId: vehicle.id,
        vehicleName: vehicleDisplayName(vehicle),
        vehicleInfo: { ...info, vin: raw.vin || info.vin },
        mode: diagnosticService.mode,
        vin: raw.vin || info.vin || null,
        dtcs: raw.dtcs,
        dtcsDetailed: analysis.dtcsDetailed,
        health: { score: analysis.score, status: analysis.status },
        liveSnapshot: raw.liveData,
        freezeFrame: raw.freezeFrame,
        connection: {
          type: diagnosticService.adapter?.type,
          deviceName: diagnosticService.deviceName,
        },
      });
      if (!mountedRef.current) return;
      setResult({ analysis, raw, sessionId: session.id });
      setPhase('result');
    } catch (err) {
      if (!mountedRef.current) return;
      setSteps((prev) => {
        const next = { ...prev };
        const active = Object.keys(next).find((k) => next[k] === 'active');
        if (active) next[active] = 'error';
        return next;
      });
      setError(err?.message || 'UNKNOWN');
    }
  };

  /* ---------- مسح الأعطال + إعادة فحص ومقارنة ---------- */
  const handleClear = async () => {
    setClearDialog(false);
    setClearing(true);
    setClearOutcome(null);
    const before = result.raw.dtcs;
    try {
      const cleared = await diagnosticService.clearDTC();
      if (!cleared) {
        setClearOutcome({ status: 'failed', summary: t('clearFailed') });
      } else {
        // إعادة فحص للمقارنة: هل عادت الرموز؟
        const after = await diagnosticService.readDTC();
        const returned = after.filter((c) => before.includes(c));
        const gone = before.filter((c) => !after.includes(c));
        if (after.length === 0) {
          setClearOutcome({ status: 'cleared', summary: t('clearSuccess', before.length) });
        } else if (returned.length) {
          setClearOutcome({
            status: 'returned',
            summary: t('clearReturned', returned.length, returned.join(', ')),
          });
        } else {
          setClearOutcome({
            status: 'cleared',
            summary: t('clearPartial', gone.length, after.length, after.join(', ')),
          });
        }
        // تحديث النتيجة المعروضة والجلسة المحفوظة
        const newAnalysis = analyze(
          { dtcs: after, liveData: result.raw.liveData, freezeFrame: result.raw.freezeFrame },
          lang,
        );
        setResult((prev) => ({
          ...prev,
          raw: { ...prev.raw, dtcs: after },
          analysis: newAnalysis,
        }));
        historyStore.update(result.sessionId, {
          dtcs: after,
          dtcsDetailed: newAnalysis.dtcsDetailed,
          health: { score: newAnalysis.score, status: newAnalysis.status },
          clearResult: { status: 'cleared', summary: t('clearResultLabel') },
          rescanResult: {
            status: returned.length ? 'returned' : 'clean',
            summary: returned.length
              ? t('clearReturned', returned.length, returned.join(', '))
              : t('noDtcsFound'),
          },
        });
      }
    } catch (err) {
      setClearOutcome({ status: 'unsupported', summary: describeError(err?.message, lang).title });
    } finally {
      setClearing(false);
    }
  };

  /* ---------- مشاركة / تقرير ---------- */
  const currentSession = () =>
    historyStore.getById(result.sessionId) || {
      ...result.raw,
      vehicleName: vehicleDisplayName(vehicle),
      timestamp: Date.now(),
      health: { score: result.analysis.score, status: result.analysis.status },
      dtcsDetailed: result.analysis.dtcsDetailed,
      vehicleInfo: extractVehicleInfo(vehicle),
      mode: diagnosticService.mode,
    };

  const handleShare = async () => {
    const r = await shareReport(currentSession(), lang);
    if (r.ok && r.method === 'clipboard') setNotice(t('shareCopied'));
    else if (!r.ok && r.error !== 'CANCELLED') setNotice(t('shareFailed'));
  };

  const handleReport = () => {
    const r = openPrintableReport(currentSession(), lang);
    if (!r.ok) setNotice(t('popupBlocked'));
  };

  /* ================= العرض ================= */

  const renderSelect = () => (
    <>
      <SectionTitle>{t('selectVehicle')}</SectionTitle>
      {devices.length === 0 ? (
        <EmptyState icon={<DiagCarIcon />} title={t('noVehicles')} hint={t('noVehiclesHint')} />
      ) : (
        devices.map((d) => (
          <GlassCard key={d.id} onClick={() => pickVehicle(d)}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4 }}>
              <Box
                sx={{
                  width: 44,
                  height: 44,
                  borderRadius: 2.5,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  background: 'rgba(47,107,255,.16)',
                  color: DIAG_COLORS.cyan,
                  flexShrink: 0,
                }}
              >
                <DiagCarIcon />
              </Box>
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography sx={{ fontWeight: 700, fontSize: 15 }}>
                  {vehicleDisplayName(d)}
                </Typography>
                <MutedText sx={{ fontSize: 12 }}>
                  {[d.attributes?.make, d.attributes?.model, d.attributes?.year]
                    .filter(Boolean)
                    .join(' · ') || d.uniqueId}
                </MutedText>
              </Box>
            </Box>
          </GlassCard>
        ))
      )}
    </>
  );

  const renderWifiPanel = () => {
    const info = conn.connected ? diagnosticService.getConnectionInfo() : null;
    const debugLog = diagnosticService.getDebugLog();
    return (
      <GlassCard sx={{ mt: 1, borderColor: 'rgba(0,229,255,.28)' }}>
        <SectionTitle>{t('wifiPanelTitle')}</SectionTitle>
        <MutedText component="ol" sx={{ pl: 2.4, fontSize: 12.5, '& li': { mb: 0.5 } }}>
          <li>{t('wifiStep1')}</li>
          <li>{t('wifiStep2')}</li>
          <li>{t('wifiStep3')}</li>
          <li>{t('wifiStep4')}</li>
        </MutedText>
        <Box sx={{ display: 'flex', gap: 1, my: 1.4, flexDirection: { xs: 'column', sm: 'row' } }}>
          <TextField
            sx={wifiFieldSx}
            size="small"
            label={t('wifiIpLabel')}
            placeholder="192.168.x.x"
            value={wifiCfg.ip}
            onChange={(e) => setWifiCfg((p) => ({ ...p, ip: e.target.value }))}
            dir="ltr"
          />
          <TextField
            sx={{ ...wifiFieldSx, maxWidth: { sm: 140 } }}
            size="small"
            label={t('wifiPortLabel')}
            placeholder="35000"
            value={wifiCfg.port}
            onChange={(e) => setWifiCfg((p) => ({ ...p, port: e.target.value }))}
            inputMode="numeric"
            dir="ltr"
          />
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
          <GhostButton
            size="small"
            sx={{ fontSize: 12 }}
            disabled={wifiDetect === 'running'}
            onClick={detectWifiAdapter}
          >
            {wifiDetect === 'running' ? t('wifiDetecting') : t('wifiDetect')}
          </GhostButton>
          {wifiDetect === 'found' && (
            <MutedText sx={{ color: DIAG_COLORS.green, fontSize: 12 }}>
              {t('wifiDetected')}
            </MutedText>
          )}
          {wifiDetect === 'none' && (
            <MutedText sx={{ fontSize: 12 }}>{t('wifiNotFound')}</MutedText>
          )}
          {wifiDetect === 'error' && (
            <MutedText sx={{ color: DIAG_COLORS.red, fontSize: 12 }}>
              {t('wifiRequired')}
            </MutedText>
          )}
        </Box>
        {wifiBusy ? (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
            <Box className="dg-spinner" />
            <MutedText>{t('wifiConnecting')}</MutedText>
          </Box>
        ) : (
          <PrimaryButton
            startIcon={<WifiIcon />}
            onClick={connectWifi}
            disabled={!wifiCfg.ip.trim() || !String(wifiCfg.port).trim()}
          >
            {t('wifiConnect')}
          </PrimaryButton>
        )}
        {info && conn.connected && (
          <Box sx={{ mt: 1.6, fontSize: 12.5 }}>
            <MutedText>{t('connAdapter')}: {info.adapter}</MutedText>
            <MutedText>{t('connType')}: {info.connection}</MutedText>
            <MutedText dir="ltr" sx={{ textAlign: lang === 'ar' ? 'right' : 'left' }}>
              {t('connIp')}: {info.ip} · {t('connPort')}: {info.port}
            </MutedText>
            <MutedText>{t('connProtocol')}: {t('protocolAuto')}</MutedText>
            <MutedText sx={{ color: DIAG_COLORS.green }}>
              {t('connStatus')}: {t('statusConnected')}
            </MutedText>
          </Box>
        )}
        <GhostButton sx={{ mt: 1, fontSize: 11 }} onClick={() => setShowDebug((v) => !v)}>
          {t('wifiDebug')}
        </GhostButton>
        {showDebug && (
          <Box
            sx={{
              mt: 1,
              maxHeight: 180,
              overflow: 'auto',
              fontFamily: 'monospace',
              fontSize: 10.5,
              background: 'rgba(0,0,0,.35)',
              borderRadius: 1.5,
              p: 1,
            }}
          >
            {debugLog.map((l, i) => (
              <Box
                key={`${l.at}-${i}`}
                sx={{
                  color:
                    l.direction === 'tx'
                      ? DIAG_COLORS.cyan
                      : l.direction === 'rx'
                        ? DIAG_COLORS.green
                        : '#8899aa',
                  whiteSpace: 'pre-wrap',
                  wordBreak: 'break-all',
                }}
              >
                {l.direction.toUpperCase()} {l.text}
              </Box>
            ))}
            {!debugLog.length && (
              <MutedText sx={{ fontSize: 11 }}>{t('wifiDebugEmpty')}</MutedText>
            )}
          </Box>
        )}
      </GlassCard>
    );
  };

  const renderConnect = () => {
    const info = extractVehicleInfo(vehicle);
    return (
      <>
        <GlassCard>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4 }}>
            <Box sx={{ color: DIAG_COLORS.cyan }}>
              <DiagCarIcon fontSize="large" />
            </Box>
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontWeight: 800, fontSize: 16 }}>
                {vehicleDisplayName(vehicle)}
              </Typography>
              <MutedText sx={{ fontSize: 12.5 }}>
                {t('vehicleLine1', info.make, info.model, info.year)}
              </MutedText>
              <MutedText sx={{ fontSize: 12.5 }}>
                {t('vehicleLine2', info.engine, info.fuelType)}
              </MutedText>
              <MutedText sx={{ fontSize: 12.5 }}>
                {info.vin ? `VIN: ${info.vin}` : t('vinAuto')}
              </MutedText>
            </Box>
          </Box>
        </GlassCard>

        <SectionTitle>{t('connectTitle')}</SectionTitle>

        <GlassCard sx={{ mb: 1 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            <PrimaryButton
              startIcon={<BluetoothIcon />}
              disabled={!compat.ble}
              onClick={() => connect('ble')}
            >
              {t('bleBtn')}
              {!compat.ble ? ` — ${t('bleUnsupported')}` : ''}
            </PrimaryButton>
            <GhostButton
              startIcon={<UsbIcon />}
              disabled={!compat.serial}
              onClick={() => connect('serial')}
            >
              {t('usbBtn')}
              {!compat.serial ? ` — ${t('usbDesktopOnly')}` : ''}
            </GhostButton>
            {compat.wifi ? (
              <GhostButton startIcon={<WifiIcon />} onClick={() => setWifiOpen((v) => !v)}>
                {t('wifiBtnNative')}
              </GhostButton>
            ) : (
              <GhostButton startIcon={<WifiOffIcon />} disabled>
                {t('wifiBtn')}
              </GhostButton>
            )}
          </Box>
          {compat.wifi && wifiOpen && renderWifiPanel()}
          {!compat.ble && !compat.serial && (
            <MutedText sx={{ mt: 1.2, fontSize: 12, color: DIAG_COLORS.amber }}>
              {t('browserNoSupport')}
            </MutedText>
          )}
          {conn.state === 'connecting' && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2, mt: 1.4 }}>
              <Box className="dg-spinner" />
              <MutedText>{t('connecting')}</MutedText>
            </Box>
          )}
        </GlassCard>

        {error && (
          <ErrorCard
            title={describeError(error, lang).title}
            hint={describeError(error, lang).hint}
          />
        )}

        <GlassCard sx={{ borderStyle: 'dashed', textAlign: 'center' }}>
          <MutedText sx={{ mb: 1 }}>{t('testModeHint')}</MutedText>
          <GhostButton startIcon={<FlaskIcon />} onClick={() => connect('mock')}>
            {t('testModeBtn')}
          </GhostButton>
        </GlassCard>

        <GhostButton
          onClick={() => {
            setPhase('select');
            setError(null);
          }}
        >
          {t('changeVehicle')}
        </GhostButton>
      </>
    );
  };

  const renderScanning = () => (
    <>
      <SectionTitle>{error ? t('scanStopped') : t('scanningTitle')}</SectionTitle>
      <GlassCard>
        {SCAN_STEP_KEYS.map((k) => (
          <ScanStepRow key={k} label={t(STEP_LABEL_KEY[k])} status={steps[k]} />
        ))}
      </GlassCard>
      {error && (
        <>
          <ErrorCard
            title={describeError(error, lang).title}
            hint={describeError(error, lang).hint}
          />
          <Box sx={{ mt: 1 }}>
            <PrimaryButton startIcon={<RescanIcon />} onClick={() => setPhase('connect')}>
              {t('retry')}
            </PrimaryButton>
          </Box>
        </>
      )}
    </>
  );

  const renderResult = () => {
    const { analysis, raw } = result;
    return (
      <>
        {/* النتيجة الصحية */}
        <GlassCard sx={{ textAlign: 'center' }}>
          <HealthGauge score={analysis.score} status={analysis.status} />
          <MutedText>{analysis.summary}</MutedText>
          {raw.vin && <MutedText sx={{ fontSize: 12, mt: 0.5 }}>VIN: {raw.vin}</MutedText>}
        </GlassCard>

        {/* نتيجة المسح/إعادة الفحص */}
        {clearOutcome && (
          <GlassCard
            sx={{
              borderColor:
                clearOutcome.status === 'cleared' ? 'rgba(46,204,113,.4)' : 'rgba(245,166,35,.4)',
            }}
          >
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
              <Box
                sx={{
                  color: clearOutcome.status === 'cleared' ? DIAG_COLORS.green : DIAG_COLORS.amber,
                  mt: 0.2,
                }}
              >
                {clearOutcome.status === 'cleared' ? (
                  <CheckIcon fontSize="small" />
                ) : (
                  <RescanIcon fontSize="small" />
                )}
              </Box>
              <MutedText sx={{ flex: 1 }}>{clearOutcome.summary}</MutedText>
            </Box>
          </GlassCard>
        )}

        {/* رموز الأعطال */}
        <SectionTitle>{t('dtcsTitle', analysis.dtcsDetailed.length)}</SectionTitle>
        {analysis.dtcsDetailed.length === 0 ? (
          <GlassCard>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
              <CheckIcon sx={{ color: DIAG_COLORS.green }} />
              <Typography sx={{ fontWeight: 700, fontSize: 14.5 }}>{t('noDtcsFound')}</Typography>
            </Box>
          </GlassCard>
        ) : (
          <>
            {analysis.dtcsDetailed.map((d) => (
              <DtcCard key={d.code} dtc={d} />
            ))}
            <GhostButton
              danger
              startIcon={<ClearIcon />}
              disabled={clearing}
              onClick={() => setClearDialog(true)}
            >
              {clearing ? t('clearing') : t('clearDtcs')}
            </GhostButton>
            <MutedText sx={{ fontSize: 11.5, mt: 0.6, textAlign: 'center' }}>
              {t('clearWarning')}
            </MutedText>
          </>
        )}

        {/* لوحة البيانات الحية المستمرة */}
        {rtLive && Object.keys(rtLive).length > 0 && (
          <>
            <SectionTitle>{t('rtLiveTitle')}</SectionTitle>
            <GlassCard>
              <LiveDataGrid liveData={rtLive} />
            </GlassCard>
          </>
        )}

        {/* البيانات الحية */}
        <SectionTitle>{t('liveDataTitle')}</SectionTitle>
        <GlassCard>
          <LiveDataGrid liveData={raw.liveData} />
        </GlassCard>

        {/* Freeze Frame */}
        {raw.freezeFrame && (
          <>
            <SectionTitle>{t('freezeFrameTitle')}</SectionTitle>
            <GlassCard>
              <LiveDataGrid liveData={raw.freezeFrame} />
            </GlassCard>
          </>
        )}

        {/* الإجراءات */}
        <SectionTitle>{t('reportTitle')}</SectionTitle>
        <Box sx={{ display: 'flex', gap: 1, mb: 1 }}>
          <PrimaryButton startIcon={<ReportIcon />} onClick={handleReport}>
            {t('downloadPdf')}
          </PrimaryButton>
          <GhostButton startIcon={<ShareIcon />} onClick={handleShare}>
            {t('share')}
          </GhostButton>
        </Box>
        {notice && (
          <MutedText sx={{ textAlign: 'center', color: DIAG_COLORS.cyan, mb: 1 }}>
            {notice}
          </MutedText>
        )}

        <GhostButton startIcon={<RescanIcon />} onClick={startScan} sx={{ mb: 1 }}>
          {t('rescan')}
        </GhostButton>
        <GhostButton onClick={() => navigate('/diagnostics')}>{t('backToDashboard')}</GhostButton>

        {/* تأكيد المسح */}
        <Dialog
          open={clearDialog}
          onClose={() => setClearDialog(false)}
          PaperProps={{
            sx: { background: DIAG_COLORS.bg1, color: DIAG_COLORS.text, borderRadius: 3, mx: 2 },
          }}
        >
          <DialogTitle sx={{ fontWeight: 800, fontSize: 17 }}>{t('clearDialogTitle')}</DialogTitle>
          <DialogContent>
            <MutedText sx={{ whiteSpace: 'pre-line' }}>
              {t('clearDialogBody', analysis.dtcsDetailed.length)}
            </MutedText>
          </DialogContent>
          <DialogActions sx={{ p: 2, gap: 1 }}>
            <GhostButton onClick={() => setClearDialog(false)}>{t('cancel')}</GhostButton>
            <PrimaryButton color={DIAG_COLORS.red} onClick={handleClear}>
              {t('confirmClear')}
            </PrimaryButton>
          </DialogActions>
        </Dialog>
      </>
    );
  };

  const titles = {
    select: [t('newScan'), t('selectVehicleHint')],
    connect: [t('titleConnect'), vehicle ? vehicleDisplayName(vehicle) : ''],
    scanning: [t('titleScanning'), vehicle ? vehicleDisplayName(vehicle) : ''],
    result: [t('titleResult'), vehicle ? vehicleDisplayName(vehicle) : ''],
  };

  return (
    <DiagPage>
      {conn.mode === 'test' && <TestModeBanner />}
      <DiagHeader
        title={titles[phase][0]}
        subtitle={titles[phase][1]}
        onBack={() => navigate('/diagnostics')}
        backIcon={<BackIcon />}
      />
      {phase === 'select' && renderSelect()}
      {phase === 'connect' && renderConnect()}
      {phase === 'scanning' && renderScanning()}
      {phase === 'result' && renderResult()}
    </DiagPage>
  );
};

export default DiagnosticScanPage;
