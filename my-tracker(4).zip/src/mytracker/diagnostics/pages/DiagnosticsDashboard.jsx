import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Box, Typography } from '@mui/material';
import {
  DiagPage,
  GlassCard,
  SectionTitle,
  MutedText,
  PrimaryButton,
  StatusPill,
  TestModeBanner,
  DiagHeader,
  EmptyState,
  injectDiagStyles,
  DIAG_COLORS,
} from '../components/diagUi';
import {
  DiagPulseIcon,
  HistoryIcon,
  LinkIcon,
  ChevronIcon,
  BluetoothIcon,
  FlaskIcon,
} from '../components/DiagIcons';
import { HealthGauge } from '../components/DiagWidgets';
import { useDiagT } from '../services/diagL10n';
import diagnosticService from '../services/diagnosticService';
import historyStore from '../services/historyStore';

/**
 * Diagnostic Dashboard — نقطة دخول Vehicle Diagnostics V1:
 * فحص جديد / آخر نتيجة / السجل / حالة الاتصال. المعلومات المهمة ظاهرة فورًا.
 */
const DiagnosticsDashboard = () => {
  injectDiagStyles();
  const navigate = useNavigate();
  const { t, lang } = useDiagT();
  const [conn, setConn] = useState(() => diagnosticService.snapshot());
  // تُقرأ عند التركيب — الصفحة تُعاد تركيبها عند كل تنقّل إليها
  const sessions = historyStore.list();
  const devices = useSelector((state) => Object.values(state.devices.items));

  useEffect(() => diagnosticService.subscribe(setConn), []);

  const last = sessions[0] || null;
  const lastCodes = useMemo(() => {
    if (!last) return [];
    return last.dtcs || (last.dtcsDetailed || []).map((d) => d.code);
  }, [last]);

  const vehicleName = useMemo(() => {
    if (!last) return null;
    const d = devices.find((x) => x.id === last.vehicleId);
    return d?.name || last.vehicleName || t('vehicleFallback');
  }, [last, devices, t]);

  return (
    <DiagPage>
      <DiagHeader title={t('diagnosticsTitle')} subtitle={t('dashSubtitle')} />

      {conn.mode === 'test' && conn.connected && <TestModeBanner />}

      {/* حالة الاتصال */}
      <GlassCard>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4 }}>
          <Box sx={{ color: conn.connected ? DIAG_COLORS.green : DIAG_COLORS.muted }}>
            <LinkIcon />
          </Box>
          <Box sx={{ flex: 1 }}>
            <Typography sx={{ fontWeight: 700, fontSize: 15 }}>
              {conn.connected ? t('connConnected') : t('connDisconnected')}
            </Typography>
            <MutedText sx={{ fontSize: 12.5 }}>
              {conn.connected ? conn.deviceName : t('connDisconnectedHint')}
            </MutedText>
          </Box>
          <StatusPill
            label={conn.connected ? t('pillConnected') : t('pillDisconnected')}
            color={conn.connected ? DIAG_COLORS.green : DIAG_COLORS.muted}
          />
        </Box>
      </GlassCard>

      {/* فحص جديد */}
      <GlassCard sx={{ mt: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4, mb: 1.5 }}>
          <Box
            sx={{
              width: 46,
              height: 46,
              borderRadius: 3,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: 'linear-gradient(135deg, rgba(47,107,255,.25), rgba(77,216,230,.18))',
              color: DIAG_COLORS.cyan,
            }}
          >
            <DiagPulseIcon />
          </Box>
          <Box>
            <Typography sx={{ fontWeight: 800, fontSize: 16 }}>{t('newScan')}</Typography>
            <MutedText sx={{ fontSize: 12.5 }}>{t('newScanHint')}</MutedText>
          </Box>
        </Box>
        <PrimaryButton onClick={() => navigate('/diagnostics/scan')} startIcon={<DiagPulseIcon />}>
          {t('startScan')}
        </PrimaryButton>
      </GlassCard>

      {/* آخر نتيجة */}
      <SectionTitle>{t('lastResult')}</SectionTitle>
      {last ? (
        <GlassCard onClick={() => navigate('/diagnostics/history')}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <HealthGauge score={last.health?.score} status={last.health?.status} />
            <Box sx={{ flex: 1 }}>
              <Typography sx={{ fontWeight: 700, fontSize: 15 }}>{vehicleName}</Typography>
              <MutedText sx={{ fontSize: 12.5 }}>
                {new Date(last.timestamp).toLocaleString(lang)}
              </MutedText>
              <MutedText sx={{ fontSize: 12.5 }}>
                {lastCodes.length
                  ? t('dtcCount', lastCodes.length, lastCodes.join(', '))
                  : t('noDtcsStored')}
              </MutedText>
              {last.mode === 'test' && (
                <Box sx={{ mt: 0.6 }}>
                  <StatusPill label="TEST MODE" color={DIAG_COLORS.amber} />
                </Box>
              )}
            </Box>
            <ChevronIcon sx={{ color: DIAG_COLORS.muted }} />
          </Box>
        </GlassCard>
      ) : (
        <EmptyState
          icon={<DiagPulseIcon />}
          title={t('historyEmptyTitle')}
          hint={t('historyEmptyHint')}
        />
      )}

      {/* السجل */}
      <SectionTitle>{t('history')}</SectionTitle>
      <GlassCard onClick={() => navigate('/diagnostics/history')}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4 }}>
          <Box sx={{ color: DIAG_COLORS.blue }}>
            <HistoryIcon />
          </Box>
          <Box sx={{ flex: 1 }}>
            <Typography sx={{ fontWeight: 700, fontSize: 15 }}>
              {sessions.length ? t('historyCount', sessions.length) : t('historyPageEmpty')}
            </Typography>
            <MutedText sx={{ fontSize: 12.5 }}>{t('historyHint')}</MutedText>
          </Box>
          <ChevronIcon sx={{ color: DIAG_COLORS.muted }} />
        </Box>
      </GlassCard>

      {/* معلومة التوافق */}
      <GlassCard sx={{ mt: 2.5, borderStyle: 'dashed' }}>
        <Box sx={{ display: 'flex', gap: 1.2, alignItems: 'flex-start' }}>
          <BluetoothIcon sx={{ color: DIAG_COLORS.muted, fontSize: 20, mt: 0.2 }} />
          <MutedText sx={{ fontSize: 12 }}>
            <FlaskIcon sx={{ fontSize: 14, verticalAlign: '-2px' }} /> {t('compatNote')}
          </MutedText>
        </Box>
      </GlassCard>
    </DiagPage>
  );
};

export default DiagnosticsDashboard;
