import { SvgIcon } from '@mui/material';

/**
 * أيقونات Diagnostics المحلية — SvgIcon بمسارات SVG يدوية فقط.
 * لا نستورد أي أيقونة جديدة من "@mui/icons-material" بعد حادثة فشل
 * Rolldown السابقة في GitHub Actions (انظر MY_TRACKER_SUMMARY 9.3).
 */

const make = (paths, viewBox = '0 0 24 24') => {
  const Icon = (props) => (
    <SvgIcon {...props} viewBox={viewBox}>
      {paths}
    </SvgIcon>
  );
  return Icon;
};

const stroke = (d, extra = {}) => (
  <path
    d={d}
    fill="none"
    stroke="currentColor"
    strokeWidth="1.7"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...extra}
  />
);

export const DiagCarIcon = make(
  <>
    {stroke('M4 13l1.5-4.5A2 2 0 0 1 7.4 7h9.2a2 2 0 0 1 1.9 1.5L20 13')}
    {stroke(
      'M4 13h16v4.5a1 1 0 0 1-1 1h-1.5a1 1 0 0 1-1-1V16h-9v1.5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V13z',
    )}
    {stroke('M7.5 13.5h2M14.5 13.5h2')}
  </>,
);

export const DiagPulseIcon = make(<>{stroke('M3 12h4l2.5-6 4 12 2.5-6h5')}</>);

export const BluetoothIcon = make(<>{stroke('M7 7l10 10-5 4V3l5 4L7 17')}</>);

export const UsbIcon = make(
  <>
    {stroke('M12 3v18')}
    {stroke('M12 6L9 3M12 6l3-3')}
    <circle cx="12" cy="19.5" r="1.6" fill="currentColor" />
  </>,
);

export const WifiOffIcon = make(
  <>
    {stroke('M5 9a11 11 0 0 1 5.2-2.4M12 5c2.9 0 5.6 1.1 7.7 3')}
    {stroke('M8.5 12.5a6 6 0 0 1 2.2-1.4M14 11.3a6 6 0 0 1 1.6 1.2')}
    <circle cx="12" cy="16.5" r="1.4" fill="currentColor" />
    {stroke('M4 4l16 16')}
  </>,
);

export const CheckIcon = make(<>{stroke('M5 12.5l4.5 4.5L19 7.5')}</>);

export const WarningIcon = make(
  <>
    {stroke('M12 4L2.5 20h19L12 4z')}
    {stroke('M12 10v4')}
    <circle cx="12" cy="17" r="0.9" fill="currentColor" />
  </>,
);

export const ErrorIcon = make(
  <>
    <circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" strokeWidth="1.7" />
    {stroke('M9 9l6 6M15 9l-6 6')}
  </>,
);

export const HistoryIcon = make(
  <>
    {stroke('M4 12a8 8 0 1 1 2.3 5.7')}
    {stroke('M4 18v-5h5')}
    {stroke('M12 8v4.5l3 2')}
  </>,
);

export const ReportIcon = make(
  <>
    {stroke('M7 3h7l4 4v14H7z')}
    {stroke('M14 3v4h4')}
    {stroke('M9.5 12h5M9.5 15.5h5')}
  </>,
);

export const ShareIcon = make(
  <>
    <circle cx="6" cy="12" r="2.2" fill="none" stroke="currentColor" strokeWidth="1.6" />
    <circle cx="17.5" cy="5.5" r="2.2" fill="none" stroke="currentColor" strokeWidth="1.6" />
    <circle cx="17.5" cy="18.5" r="2.2" fill="none" stroke="currentColor" strokeWidth="1.6" />
    {stroke('M8 10.8l7.5-4.2M8 13.2l7.5 4.2', { strokeWidth: 1.4 })}
  </>,
);

export const BackIcon = make(<>{stroke('M15 5l-7 7 7 7')}</>);

export const RescanIcon = make(
  <>
    {stroke('M20 12a8 8 0 1 1-2.3-5.7')}
    {stroke('M20 4v5h-5')}
  </>,
);

export const TrashIcon = make(
  <>
    {stroke('M5 7h14')}
    {stroke('M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2')}
    {stroke('M7 7l1 13h8l1-13')}
  </>,
);

export const ClearIcon = make(
  <>
    {stroke('M14 4l6 6-9.5 9.5H5.5V14L14 4z')}
    {stroke('M12 6.5l5 5')}
  </>,
);

export const GaugeIcon = make(
  <>
    {stroke('M4.5 19a9 9 0 1 1 15 0')}
    {stroke('M12 14l3.5-4.5')}
    <circle cx="12" cy="14.5" r="1.4" fill="currentColor" />
  </>,
);

export const ChipIcon = make(
  <>
    <rect
      x="7"
      y="7"
      width="10"
      height="10"
      rx="2"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
    />
    {stroke('M9 3v4M15 3v4M9 17v4M15 17v4M3 9h4M3 15h4M17 9h4M17 15h4', { strokeWidth: 1.4 })}
  </>,
);

export const FlaskIcon = make(
  <>
    {stroke('M10 3h4')}
    {stroke('M11 3v5.5L5.5 18a2 2 0 0 0 1.8 3h9.4a2 2 0 0 0 1.8-3L13 8.5V3')}
    {stroke('M8 14.5h8')}
  </>,
);

export const ChevronIcon = make(<>{stroke('M9 6l6 6-6 6')}</>);

export const CloseIcon = make(<>{stroke('M6 6l12 12M18 6L6 18')}</>);

export const LinkIcon = make(
  <>
    {stroke('M9 15l6-6')}
    {stroke('M10.5 6.5l1.8-1.8a3.5 3.5 0 0 1 5 5l-1.8 1.8')}
    {stroke('M13.5 17.5l-1.8 1.8a3.5 3.5 0 0 1-5-5l1.8-1.8')}
  </>,
);

export const EngineIcon = make(
  <>
    {stroke('M4 10v8h3l2 2h5l2-2h4v-6l-2-2h-3l-2-3H8v3H4z')}
    {stroke('M8 10V7h4')}
  </>,
);
