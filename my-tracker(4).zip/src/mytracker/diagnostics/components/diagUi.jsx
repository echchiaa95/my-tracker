import { Box, Typography, Button } from '@mui/material';
import { useDiagT } from '../services/diagL10n';

/**
 * diagUi — لغة التصميم المشتركة لشاشات Diagnostics: نفس الهوية السينمائية
 * الداكنة لشاشة My Tracker Login (navy + أزرق كهربائي + سماوي)، بطاقات
 * زجاجية، وأنيميشن خفيف يحترم prefers-reduced-motion.
 * كل الأنماط مضمّنة هنا عبر <style> مرة واحدة — لا مكتبات إضافية.
 */

export const DIAG_COLORS = {
  bg0: '#05070d',
  bg1: '#0a1128',
  card: 'rgba(16, 24, 48, 0.62)',
  cardBorder: 'rgba(120, 160, 255, 0.14)',
  text: '#e8eefc',
  muted: '#8a94a6',
  blue: '#2f6bff',
  cyan: '#4dd8e6',
  green: '#2ecc71',
  amber: '#f5a623',
  red: '#ff5252',
};

let stylesInjected = false;

/** حقن CSS المشترك مرة واحدة فقط. */
export function injectDiagStyles() {
  if (stylesInjected || typeof document === 'undefined') return;
  stylesInjected = true;
  const el = document.createElement('style');
  el.id = 'mytracker-diag-styles';
  el.textContent = `
    @keyframes dgFadeUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes dgPulseDot { 0%,100% { opacity: .4; transform: scale(.9);} 50% { opacity: 1; transform: scale(1.12);} }
    @keyframes dgSpin { to { transform: rotate(360deg); } }
    .dg-root {
      min-height: 100%;
      color: ${DIAG_COLORS.text};
      background:
        radial-gradient(ellipse 70% 40% at 85% 0%, rgba(47,107,255,0.16), transparent 60%),
        radial-gradient(ellipse 50% 35% at 8% 100%, rgba(77,216,230,0.08), transparent 65%),
        linear-gradient(180deg, ${DIAG_COLORS.bg0} 0%, ${DIAG_COLORS.bg1} 60%, #060912 100%);
      padding: 16px 16px 96px;
      box-sizing: border-box;
    }
    .dg-root * { -webkit-tap-highlight-color: transparent; }
    .dg-card {
      background: ${DIAG_COLORS.card};
      border: 1px solid ${DIAG_COLORS.cardBorder};
      border-radius: 18px;
      backdrop-filter: blur(14px);
      -webkit-backdrop-filter: blur(14px);
      padding: 16px;
      animation: dgFadeUp .35s ease both;
    }
    .dg-pressable { cursor: pointer; transition: transform .15s ease, border-color .15s ease; }
    .dg-pressable:active { transform: scale(.98); border-color: rgba(77,216,230,.4); }
    .dg-spinner {
      width: 18px; height: 18px; border-radius: 50%;
      border: 2.5px solid rgba(77,216,230,.25);
      border-top-color: ${DIAG_COLORS.cyan};
      animation: dgSpin .8s linear infinite;
    }
    @media (prefers-reduced-motion: reduce) {
      .dg-card, .dg-spinner { animation: none !important; }
    }
  `;
  document.head.appendChild(el);
}

export const DiagPage = ({ children }) => {
  const { dir } = useDiagT();
  return (
    <Box className="dg-root" dir={dir} sx={{ maxWidth: 560, margin: '0 auto', direction: dir }}>
      {children}
    </Box>
  );
};

export const GlassCard = ({ children, onClick, sx, ...rest }) => (
  <Box
    className={onClick ? 'dg-card dg-pressable' : 'dg-card'}
    onClick={onClick}
    sx={{ mb: 1.5, ...sx }}
    {...rest}
  >
    {children}
  </Box>
);

export const SectionTitle = ({ children, action }) => (
  <Box
    sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1, mt: 2.5 }}
  >
    <Typography sx={{ fontSize: 15, fontWeight: 700, color: DIAG_COLORS.text }}>
      {children}
    </Typography>
    {action}
  </Box>
);

export const MutedText = ({ children, sx }) => (
  <Typography sx={{ fontSize: 13, color: DIAG_COLORS.muted, lineHeight: 1.7, ...sx }}>
    {children}
  </Typography>
);

export const PrimaryButton = ({ children, startIcon, color = DIAG_COLORS.blue, ...props }) => (
  <Button
    fullWidth
    variant="contained"
    disableElevation
    startIcon={startIcon}
    sx={{
      py: 1.5,
      borderRadius: 3,
      fontSize: 15,
      fontWeight: 700,
      background: `linear-gradient(135deg, ${color}, ${DIAG_COLORS.cyan})`,
      color: '#05070d',
      minHeight: 52,
      '&.Mui-disabled': { background: 'rgba(120,140,180,.2)', color: 'rgba(232,238,252,.4)' },
    }}
    {...props}
  >
    {children}
  </Button>
);

export const GhostButton = ({ children, startIcon, danger, ...props }) => (
  <Button
    fullWidth
    variant="outlined"
    startIcon={startIcon}
    sx={{
      py: 1.3,
      borderRadius: 3,
      fontSize: 14,
      fontWeight: 600,
      minHeight: 48,
      color: danger ? DIAG_COLORS.red : DIAG_COLORS.text,
      borderColor: danger ? 'rgba(255,82,82,.4)' : 'rgba(120,160,255,.25)',
      '&:hover': {
        borderColor: danger ? DIAG_COLORS.red : DIAG_COLORS.cyan,
        background: 'rgba(77,216,230,.06)',
      },
    }}
    {...props}
  >
    {children}
  </Button>
);

export const StatusPill = ({ label, color }) => (
  <Box
    component="span"
    sx={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 0.7,
      px: 1.2,
      py: 0.35,
      borderRadius: 99,
      fontSize: 12,
      fontWeight: 700,
      color,
      background: `${color}1c`,
      border: `1px solid ${color}44`,
    }}
  >
    <Box
      component="span"
      sx={{
        width: 7,
        height: 7,
        borderRadius: '50%',
        background: color,
        animation: 'dgPulseDot 2.4s ease-in-out infinite',
      }}
    />
    {label}
  </Box>
);

/** شريط TEST MODE الثابت — يظهر طوال جلسة المحاكاة. */
export const TestModeBanner = () => {
  const { t } = useDiagT();
  return (
    <Box
      sx={{
        position: 'sticky',
        top: 8,
        zIndex: 10,
        mb: 1.5,
        py: 0.8,
        px: 1.5,
        borderRadius: 2.5,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 1,
        background: 'rgba(245,166,35,.14)',
        border: '1px dashed rgba(245,166,35,.55)',
        color: DIAG_COLORS.amber,
        fontSize: 13,
        fontWeight: 700,
        letterSpacing: 0.5,
        textAlign: 'center',
      }}
    >
      {t('testModeBanner')}
    </Box>
  );
};

/** رأس الصفحة مع زر رجوع. */
export const DiagHeader = ({ title, subtitle, onBack, backIcon }) => (
  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
    {onBack && (
      <Box
        onClick={onBack}
        className="dg-pressable"
        sx={{
          width: 40,
          height: 40,
          borderRadius: 2.5,
          flexShrink: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: DIAG_COLORS.card,
          border: `1px solid ${DIAG_COLORS.cardBorder}`,
          color: DIAG_COLORS.text,
        }}
      >
        {backIcon}
      </Box>
    )}
    <Box>
      <Typography sx={{ fontSize: 20, fontWeight: 800, letterSpacing: 0.2 }}>{title}</Typography>
      {subtitle && <MutedText sx={{ fontSize: 12.5 }}>{subtitle}</MutedText>}
    </Box>
  </Box>
);

/** بطاقة حالة فارغة واضحة. */
export const EmptyState = ({ icon, title, hint }) => (
  <GlassCard sx={{ textAlign: 'center', py: 4 }}>
    <Box sx={{ color: DIAG_COLORS.muted, mb: 1, '& svg': { fontSize: 40 } }}>{icon}</Box>
    <Typography sx={{ fontWeight: 700, fontSize: 15 }}>{title}</Typography>
    {hint && <MutedText sx={{ mt: 0.5 }}>{hint}</MutedText>}
  </GlassCard>
);

/** بطاقة خطأ مفهومة: السبب + ماذا يفعل المستخدم. */
export const ErrorCard = ({ title, hint, onRetry, retryLabel }) => {
  const { t } = useDiagT();
  return (
    <GlassCard sx={{ borderColor: 'rgba(255,82,82,.35)' }}>
      <Typography sx={{ fontWeight: 700, fontSize: 15, color: DIAG_COLORS.red, mb: 0.5 }}>
        {title}
      </Typography>
      {hint && <MutedText>{hint}</MutedText>}
      {onRetry && (
        <Box sx={{ mt: 1.5 }}>
          <GhostButton onClick={onRetry}>{retryLabel || t('retry')}</GhostButton>
        </Box>
      )}
    </GlassCard>
  );
};
