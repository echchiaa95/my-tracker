/**
 * AnalysisEngine — طبقة تحليل مستقلة: تدمج نتيجة الفحص (DTC + Live Data +
 * Freeze Frame) وتُنتج Health Score وحالة وملاحظات مفهومة، بلغة واجهة
 * المستخدم الحالية. الحساب مبني حصرًا على بيانات حقيقية حُصل عليها فعلًا؛
 * عند نقص البيانات تكون الحالة 'insufficient' بدل اختراع نتيجة.
 */

import { lookupDtc, SEVERITY_ORDER } from './dtcDatabase';

const L = {
  ar: {
    overheating: 'حرارة مرتفعة جدًا',
    overheatingDetail: (v) => `حرارة سائل التبريد ${v}°م — أوقف المركبة وافحص نظام التبريد`,
    coolantHigh: 'حرارة أعلى من المعتاد',
    coolantHighDetail: (v) => `حرارة سائل التبريد ${v}°م`,
    lowVoltage: 'جهد كهربائي منخفض',
    lowVoltageDetail: (v) => `جهد وحدة التحكم ${v}V — افحص البطارية والشحن`,
    milOn: 'لمبة العطل مضاءة',
    milOnDetail: (v) => `المركبة قطعت ${v} كم ولمبة العطل مضاءة`,
    insufficient: 'بيانات غير كافية لحساب نتيجة صحية',
    noDtcs: 'لا توجد رموز أعطال مخزنة',
    healthy: 'لا توجد مؤشرات أعطال حالية',
    warning: (n) => `توجد ${n} مؤشرات تستدعي المتابعة`,
    fault: 'توجد أعطال تحتاج تدخلًا',
  },
  en: {
    overheating: 'Critical overheating',
    overheatingDetail: (v) =>
      `Coolant temperature ${v}°C — stop the vehicle and check the cooling system`,
    coolantHigh: 'Coolant temperature above normal',
    coolantHighDetail: (v) => `Coolant temperature ${v}°C`,
    lowVoltage: 'Low electrical voltage',
    lowVoltageDetail: (v) => `Control module voltage ${v}V — check battery and charging`,
    milOn: 'Check-engine light is on',
    milOnDetail: (v) => `Vehicle driven ${v} km with the MIL on`,
    insufficient: 'Insufficient data to compute a health score',
    noDtcs: 'No stored fault codes',
    healthy: 'No current fault indicators',
    warning: (n) => `${n} indicator(s) need attention`,
    fault: 'Faults detected that require attention',
  },
  fr: {
    overheating: 'Surchauffe critique',
    overheatingDetail: (v) =>
      `Température du liquide de refroidissement ${v}°C — arrêtez le véhicule et vérifiez le refroidissement`,
    coolantHigh: 'Température du liquide au-dessus de la normale',
    coolantHighDetail: (v) => `Température du liquide de refroidissement ${v}°C`,
    lowVoltage: 'Tension électrique faible',
    lowVoltageDetail: (v) => `Tension du module ${v}V — vérifiez batterie et charge`,
    milOn: 'Le témoin moteur est allumé',
    milOnDetail: (v) => `Le véhicule a parcouru ${v} km avec le témoin allumé`,
    insufficient: 'Données insuffisantes pour calculer un score de santé',
    noDtcs: 'Aucun code défaut enregistré',
    healthy: 'Aucun indicateur de défaut actuel',
    warning: (n) => `${n} indicateur(s) à surveiller`,
    fault: 'Des défauts nécessitent une intervention',
  },
};

/**
 * @param {object} input — { dtcs: string[], liveData, freezeFrame }
 * @param {string} lang — 'ar' | 'en' | 'fr'
 */
export function analyze({ dtcs = [], liveData = null, freezeFrame = null }, lang = 'ar') {
  const s = L[lang] || L.en;
  const findings = [];
  const dtcsDetailed = dtcs.map((code) => {
    const info = lookupDtc(code, lang);
    findings.push({
      type: 'dtc',
      code,
      severity: info.severity,
      title: code,
      detail: info.desc,
    });
    return { ...info, status: 'stored' };
  });

  // ملاحظات من Live Data — فقط للقيم المقروءة فعلًا
  if (liveData) {
    const coolant = liveData.coolantTemp?.value;
    if (typeof coolant === 'number') {
      if (coolant >= 110) {
        findings.push({
          type: 'live',
          severity: 'fault',
          title: s.overheating,
          detail: s.overheatingDetail(coolant),
        });
      } else if (coolant >= 102) {
        findings.push({
          type: 'live',
          severity: 'warning',
          title: s.coolantHigh,
          detail: s.coolantHighDetail(coolant),
        });
      }
    }
    const voltage = liveData.controlVoltage?.value;
    if (typeof voltage === 'number' && voltage > 0 && voltage < 12) {
      findings.push({
        type: 'live',
        severity: 'warning',
        title: s.lowVoltage,
        detail: s.lowVoltageDetail(voltage),
      });
    }
    const milDistance = liveData.milDistance?.value;
    if (typeof milDistance === 'number' && milDistance > 0) {
      findings.push({
        type: 'live',
        severity: 'info',
        title: s.milOn,
        detail: s.milOnDetail(milDistance),
      });
    }
  }

  const hasLive = liveData && Object.keys(liveData).length >= 2;
  if (!hasLive && dtcs.length > 0 === false && !liveData) {
    return {
      score: null,
      status: 'insufficient',
      findings,
      dtcsDetailed,
      summary: s.insufficient,
      freezeFrame,
    };
  }

  let score = 100;
  for (const f of findings) {
    if (f.severity === 'fault') score -= 25;
    else if (f.severity === 'warning') score -= 10;
    else score -= 3;
  }
  const hasFault = findings.some((f) => f.severity === 'fault');
  score = Math.max(hasFault ? 5 : 40, Math.min(100, score));

  if (!hasLive && dtcs.length === 0) {
    // نجح الفحص لكن لا بيانات حية كافية ولا أعطال — نتيجة مبنية على DTC فقط
    return { score: 95, status: 'healthy', findings, dtcsDetailed, summary: s.noDtcs, freezeFrame };
  }

  let status = 'healthy';
  if (hasFault) status = 'fault';
  else if (findings.some((f) => SEVERITY_ORDER[f.severity] >= 2)) status = 'warning';

  const summary =
    status === 'healthy'
      ? s.healthy
      : status === 'warning'
        ? s.warning(dtcs.length || findings.length)
        : s.fault;

  return { score, status, findings, dtcsDetailed, summary, freezeFrame };
}

export const STATUS_META = {
  healthy: { ar: 'سليمة', en: 'Healthy', fr: 'En bon état', color: '#2ecc71' },
  warning: { ar: 'تنبيه', en: 'Warning', fr: 'Avertissement', color: '#f5a623' },
  fault: { ar: 'عطل', en: 'Fault', fr: 'Défaut', color: '#ff5252' },
  insufficient: {
    ar: 'بيانات غير كافية',
    en: 'Insufficient Data',
    fr: 'Données insuffisantes',
    color: '#8a94a6',
  },
};

export const SEVERITY_META = {
  fault: { ar: 'عطل', en: 'Fault', fr: 'Défaut', color: '#ff5252' },
  warning: { ar: 'تحذير', en: 'Warning', fr: 'Avertissement', color: '#f5a623' },
  info: { ar: 'معلومة', en: 'Info', fr: 'Info', color: '#4dd8e6' },
};
