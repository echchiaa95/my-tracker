/**
 * ReportView — تقرير التشخيص عبر نافذة طباعة (window.print → Save as PDF)
 * بدون أي مكتبة PDF. يتبع لغة واجهة المستخدم الحالية (ar/fr/en، RTL تلقائي
 * للعربية). تفاصيل DTC تُشتق من الأكواد المخزنة باللغة الحالية حتى لا
 * "تتجمد" لغة التقارير القديمة.
 */

import { STATUS_META, SEVERITY_META } from './analysisEngine';
import { SYSTEM_LABELS, lookupDtc } from './dtcDatabase';

const esc = (s) =>
  String(s ?? '—').replace(
    /[&<>"]/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c],
  );

const R = {
  ar: {
    title: 'تقرير تشخيص المركبة',
    brand: 'MY TRACKER',
    testMode: 'TEST MODE (بيانات تجريبية)',
    realMode: 'مركبة حقيقية',
    scanMode: 'وضع الفحص',
    connection: 'الاتصال',
    vehicleInfo: 'معلومات المركبة',
    vehicle: 'المركبة',
    makeModel: 'الشركة / الموديل',
    year: 'السنة',
    engine: 'المحرك',
    fuel: 'نوع الوقود',
    health: 'الحالة الصحية',
    insufficient: 'بيانات غير كافية',
    dtcs: 'رموز الأعطال (DTC)',
    noDtcs: 'لا توجد رموز أعطال.',
    stored: 'مخزّن',
    cleared: 'تم المسح',
    causes: 'الأسباب المحتملة',
    checks: 'الفحوصات المقترحة',
    freezeFrame: 'Freeze Frame',
    liveSnapshot: 'لقطة البيانات الحية',
    clearResult: 'نتيجة مسح الأعطال',
    rescanResult: 'نتيجة إعادة الفحص',
    footer: 'مسح رمز العطل لا يعني إصلاح سبب المشكلة — يُنصح بمعالجة السبب الجذري.',
    shareTitle: 'تقرير تشخيص المركبة',
    date: 'التاريخ',
    status: 'الحالة',
    faults: 'الأعطال',
    none: 'لا يوجد',
    locale: 'ar',
  },
  en: {
    title: 'Vehicle Diagnostic Report',
    brand: 'MY TRACKER',
    testMode: 'TEST MODE (demo data)',
    realMode: 'Real vehicle',
    scanMode: 'Scan mode',
    connection: 'Connection',
    vehicleInfo: 'Vehicle Information',
    vehicle: 'Vehicle',
    makeModel: 'Make / Model',
    year: 'Year',
    engine: 'Engine',
    fuel: 'Fuel type',
    health: 'Health Status',
    insufficient: 'Insufficient Data',
    dtcs: 'Fault Codes (DTC)',
    noDtcs: 'No fault codes.',
    stored: 'Stored',
    cleared: 'Cleared',
    causes: 'Possible causes',
    checks: 'Recommended checks',
    freezeFrame: 'Freeze Frame',
    liveSnapshot: 'Live data snapshot',
    clearResult: 'Clear DTC result',
    rescanResult: 'Re-scan result',
    footer:
      'Clearing a fault code does not fix the root cause — addressing the underlying issue is recommended.',
    shareTitle: 'Vehicle Diagnostic Report',
    date: 'Date',
    status: 'Status',
    faults: 'Faults',
    none: 'None',
    locale: 'en',
  },
  fr: {
    title: 'Rapport de diagnostic du véhicule',
    brand: 'MY TRACKER',
    testMode: 'TEST MODE (données démo)',
    realMode: 'Véhicule réel',
    scanMode: 'Mode d’analyse',
    connection: 'Connexion',
    vehicleInfo: 'Informations du véhicule',
    vehicle: 'Véhicule',
    makeModel: 'Marque / Modèle',
    year: 'Année',
    engine: 'Moteur',
    fuel: 'Carburant',
    health: 'État de santé',
    insufficient: 'Données insuffisantes',
    dtcs: 'Codes défaut (DTC)',
    noDtcs: 'Aucun code défaut.',
    stored: 'Enregistré',
    cleared: 'Effacé',
    causes: 'Causes possibles',
    checks: 'Vérifications recommandées',
    freezeFrame: 'Freeze Frame',
    liveSnapshot: 'Aperçu des données en direct',
    clearResult: 'Résultat de l’effacement',
    rescanResult: 'Résultat de la nouvelle analyse',
    footer:
      'Effacer un code défaut ne répare pas la cause — il est recommandé de traiter la cause racine.',
    shareTitle: 'Rapport de diagnostic du véhicule',
    date: 'Date',
    status: 'Statut',
    faults: 'Défauts',
    none: 'Aucun',
    locale: 'fr',
  },
};

const dict = (lang) => R[lang] || R.en;
const meta = (m, lang) => ({ ...m, label: m?.[lang] || m?.en || '' });

/** تفاصيل DTC باللغة الحالية: من الأكواد المخزنة إن وُجدت، وإلا من المخزَّن. */
export function sessionDtcs(session, lang) {
  if (Array.isArray(session.dtcs) && session.dtcs.length) {
    return session.dtcs.map((code) => lookupDtc(code, lang));
  }
  return session.dtcsDetailed || [];
}

function buildReportHtml(session, lang = 'ar') {
  const s = dict(lang);
  const rtl = lang === 'ar';
  const statusMeta = meta(STATUS_META[session.health?.status] || STATUS_META.insufficient, lang);
  const dateStr = new Date(session.timestamp).toLocaleString(s.locale);
  const info = session.vehicleInfo || {};

  const dtcRows =
    sessionDtcs(session, lang)
      .map((d) => {
        const sev = meta(SEVERITY_META[d.severity], lang);
        return `
    <div class="dtc">
      <div class="dtc-head"><b>${esc(d.code)}</b>
        <span class="pill" style="background:${sev.color}22;color:${sev.color}">${esc(sev.label)}</span>
        <span class="muted">${esc(SYSTEM_LABELS[d.system]?.[lang] || SYSTEM_LABELS[d.system]?.en)}</span>
        <span class="muted">${d.status === 'cleared' ? s.cleared : s.stored}</span>
      </div>
      <p>${esc(d.desc)}</p>
      <p class="muted">${esc(s.causes)}: ${esc((d.causes || []).join(' • '))}</p>
      <p class="muted">${esc(s.checks)}: ${esc((d.checks || []).join(' • '))}</p>
    </div>`;
      })
      .join('') || `<p class="muted">${esc(s.noDtcs)}</p>`;

  // ترجمات فرنسية لأسماء/وحدات PID (السجل يحوي ar/en فقط) — تُستخدم عند اختيار FR
  const FR_PID_NAME = {
    'حمل المحرك': 'Charge moteur',
    'حرارة سائل التبريد': 'Température liquide de refroidissement',
    'ضغط مجمع السحب (MAP)': "Pression d'admission (MAP)",
    'دورات المحرك': 'Régime moteur',
    'سرعة المركبة': 'Vitesse véhicule',
    'حرارة هواء السحب': "Température d'air admission",
    'تدفق الهواء (MAF)': "Débit d'air (MAF)",
    'موضع خانق الهواء': 'Position du papillon',
    'زمن التشغيل منذ بدء المحرك': 'Temps de fonctionnement moteur',
    'المسافة مع لمبة العطل': 'Distance avec voyant allumé',
    'مستوى الوقود': 'Niveau carburant',
    'الضغط الجوي': 'Pression atmosphérique',
  };
  const FR_PID_UNIT = { 'كم/س': 'km/h', '°م': '°C' };
  const pidName = (n) =>
    n?.[lang] || (lang === 'fr' ? FR_PID_NAME[n?.ar] : undefined) || n?.en || n?.ar || '';
  const pidUnit = (u) =>
    u?.[lang] || (lang === 'fr' ? FR_PID_UNIT[u?.ar] : undefined) || u?.en || u?.ar || u || '';
  const row = (v) =>
    `<tr><td>${esc(pidName(v.name))}</td><td><bdi dir="ltr">${esc(v.value)} ${esc(pidUnit(v.unit))}</bdi></td></tr>`;
  const liveRows = session.liveSnapshot
    ? Object.values(session.liveSnapshot).map(row).join('')
    : '';
  const ffRows = session.freezeFrame ? Object.values(session.freezeFrame).map(row).join('') : '';

  return `<!DOCTYPE html><html lang="${s.locale}" dir="${rtl ? 'rtl' : 'ltr'}"><head><meta charset="utf-8">
<title>${esc(s.title)} — ${esc(session.vehicleName || '')}</title>
<style>
  html{background:#fff}
  body{font-family:'Segoe UI',Tahoma,Arial,sans-serif;color:#1a2233;background:#fff;max-width:760px;margin:0 auto;padding:32px 24px;line-height:1.7}
  h1{font-size:22px;margin:0 0 4px}
  h2{font-size:16px;margin:28px 0 8px;border-bottom:2px solid #2f6bff;padding-bottom:4px;color:#0a1128}
  .brand{color:#2f6bff}
  .muted{color:#68728a;font-size:13px}
  table{width:100%;border-collapse:collapse;font-size:14px}
  td,th{border:1px solid #dde3ee;padding:6px 10px;text-align:${rtl ? 'right' : 'left'}}
  .health{display:inline-block;padding:8px 18px;border-radius:12px;background:${statusMeta.color}18;color:${statusMeta.color};font-weight:700;font-size:18px}
  .dtc{border:1px solid #e4e9f2;border-radius:10px;padding:10px 14px;margin:8px 0}
  .dtc-head{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
  .pill{padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600}
  .footer{margin-top:36px;font-size:12px;color:#98a1b3;border-top:1px solid #e4e9f2;padding-top:10px}
  @media print{body{padding:0}}
</style></head><body>
  <h1>${esc(s.title)} <span class="brand">— ${esc(s.brand)}</span></h1>
  <p class="muted">${esc(dateStr)} · ${esc(s.scanMode)}: ${session.mode === 'test' ? s.testMode : s.realMode} · ${esc(s.connection)}: ${esc(session.connection?.deviceName || '—')}</p>

  <h2>${esc(s.vehicleInfo)}</h2>
  <table>
    ${(() => {
      const vRow = (label, value) => (value ? `<tr><td>${esc(label)}</td><td>${esc(value)}</td></tr>` : '');
      const makeModel = info.make && info.model ? `${info.make} / ${info.model}` : (info.make || info.model);
      return [
        vRow(s.vehicle, session.vehicleName),
        vRow(s.makeModel, makeModel),
        vRow(s.year, info.year),
        vRow(s.engine, info.engine),
        vRow(s.fuel, info.fuelType),
        vRow('VIN', session.vin || info.vin),
      ].join('');
    })()}
  </table>

  <h2>${esc(s.health)}</h2>
  <span class="health">${session.health?.score != null ? `<bdi dir="ltr">${session.health.score} / 100</bdi>` : esc(s.insufficient)} — ${esc(statusMeta.label)}</span>

  <h2>${esc(s.dtcs)}</h2>
  ${dtcRows}

  ${ffRows ? `<h2>${esc(s.freezeFrame)}</h2><table>${ffRows}</table>` : ''}
  ${liveRows ? `<h2>${esc(s.liveSnapshot)}</h2><table>${liveRows}</table>` : ''}

  ${session.clearResult ? `<h2>${esc(s.clearResult)}</h2><p>${esc(session.clearResult.summary)}</p>` : ''}
  ${session.rescanResult ? `<h2>${esc(s.rescanResult)}</h2><p>${esc(session.rescanResult.summary)}</p>` : ''}

  <div class="footer">${esc(s.footer)} · ${esc(s.brand)} — Vehicle Diagnostics V1</div>
</body></html>`;
}

/**
 * بناء PDF من محتوى التقرير المعروض (صورة عبر html2canvas — تدعم العربية RTL دون مشاكل)
 * ثم مشاركته عبر @capacitor/share أو تحميله مباشرة كاحتياطي.
 */
async function saveReportPdf(iframe, btn, uiLang) {
  const orig = btn.textContent;
  btn.disabled = true;
  btn.textContent = uiLang === 'ar' ? '⏳ جارٍ التحضير…' : '⏳…';
  try {
    const html2canvas = (await import('html2canvas')).default;
    const { jsPDF } = await import('jspdf');
    const doc = iframe.contentDocument;
    if (!doc?.body) throw new Error('REPORT_DOC_UNAVAILABLE');
    const canvas = await html2canvas(doc.body, {
      scale: 2,
      backgroundColor: '#ffffff',
      logging: false,
      useCORS: true,
    });
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageW = 210;
    const pageH = 297;
    const imgH = (canvas.height * pageW) / canvas.width;
    const img = canvas.toDataURL('image/jpeg', 0.92);
    let position = 0;
    pdf.addImage(img, 'JPEG', 0, position, pageW, imgH);
    let heightLeft = imgH - pageH;
    while (heightLeft > 0) {
      position -= pageH;
      pdf.addPage();
      pdf.addImage(img, 'JPEG', 0, position, pageW, imgH);
      heightLeft -= pageH;
    }
    const fileName = `mytracker-report-${new Date().toISOString().slice(0, 10)}.pdf`;
    // المحاولة الأولى: حفظ في الكاش ومشاركته عبر البلجن الرسمي
    try {
      const { Filesystem, Directory } = await import('@capacitor/filesystem');
      const { Share } = await import('@capacitor/share');
      const base64 = pdf.output('datauristring').split(',')[1];
      const written = await Filesystem.writeFile({ path: fileName, data: base64, directory: Directory.Cache });
      await Share.share({ title: fileName, url: written.uri });
    } catch {
      pdf.save(fileName); // تحميل مباشر كاحتياطي
    }
    btn.textContent = uiLang === 'ar' ? '✓ تم' : '✓';
    setTimeout(() => { btn.textContent = orig; }, 2000);
  } catch {
    btn.textContent = uiLang === 'ar' ? '✗ فشل' : '✗';
    setTimeout(() => { btn.textContent = orig; }, 2000);
  } finally {
    btn.disabled = false;
  }
}

/**
 * عرض التقرير داخل التطبيق (overlay) بدل window.open — خلفية بيضاء واضحة،
 * محدد لغة (AR/FR/EN)، زر إغلاق، زر PDF حقيقي، وزر الرجوع يغلق التقرير بدل الخروج.
 */
export function openPrintableReport(session, lang = 'ar') {
  let currentLang = lang;
  document.getElementById('diag-report-overlay')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'diag-report-overlay';
  overlay.style.cssText =
    'position:fixed;inset:0;z-index:99999;background:#fff;display:flex;flex-direction:column;';

  const closeLabel = lang === 'ar' ? 'إغلاق' : 'Fermer';
  const printLabel = lang === 'ar' ? 'حفظ PDF' : 'Enregistrer PDF';
  const title = (session.vehicleName || (lang === 'ar' ? 'التقرير' : 'Rapport'));

  const bar = document.createElement('div');
  bar.style.cssText =
    'display:flex;gap:8px;align-items:center;padding:10px 12px;background:#0a1128;color:#fff;font-family:sans-serif;direction:ltr;flex-wrap:wrap;';
  bar.innerHTML = `
    <button id="diag-report-close" style="background:#2f6bff;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-size:14px;font-weight:600;">✕ ${closeLabel}</button>
    <button id="diag-report-print" style="background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.35);border-radius:8px;padding:8px 14px;font-size:14px;">🖨 ${printLabel}</button>
    <span id="diag-lang-group" style="display:inline-flex;gap:4px;margin-left:auto;">
      <button data-lang="ar" style="border:1px solid rgba(255,255,255,.4);background:transparent;color:#fff;border-radius:6px;padding:6px 10px;font-size:13px;">عربي</button>
      <button data-lang="fr" style="border:1px solid rgba(255,255,255,.4);background:transparent;color:#fff;border-radius:6px;padding:6px 10px;font-size:13px;">FR</button>
      <button data-lang="en" style="border:1px solid rgba(255,255,255,.4);background:transparent;color:#fff;border-radius:6px;padding:6px 10px;font-size:13px;">EN</button>
    </span>
    <span style="font-size:13px;opacity:.75;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:120px;"></span>`;
  bar.querySelector('span:last-child').textContent = title;

  const iframe = document.createElement('iframe');
  iframe.style.cssText = 'flex:1;border:0;background:#fff;width:100%;';

  overlay.appendChild(bar);
  overlay.appendChild(iframe);
  document.body.appendChild(overlay);

  const render = () => {
    iframe.srcdoc = buildReportHtml(session, currentLang);
    bar.querySelectorAll('#diag-lang-group button').forEach((b) => {
      const active = b.dataset.lang === currentLang;
      b.style.background = active ? '#2f6bff' : 'transparent';
      b.style.borderColor = active ? '#2f6bff' : 'rgba(255,255,255,.4)';
    });
  };
  render();

  const close = () => {
    overlay.remove();
    window.removeEventListener('popstate', onPop);
  };
  const onPop = () => close();
  // زر الرجوع في أندرويد يغلق التقرير بدل إنهاء التطبيق
  window.history.pushState({ diagReportOverlay: true }, '');
  window.addEventListener('popstate', onPop);

  bar.querySelector('#diag-report-close').onclick = close;
  bar.querySelector('#diag-report-print').onclick = (e) => saveReportPdf(iframe, e.currentTarget, currentLang);
  bar.querySelectorAll('#diag-lang-group button').forEach((b) => {
    b.onclick = () => { currentLang = b.dataset.lang; render(); };
  });

  return { ok: true };
}

/** مشاركة ملخص نصي عبر Web Share API، مع fallback بالنسخ للحافظة. */
export async function shareReport(session, lang = 'ar') {
  const s = dict(lang);
  const statusMeta = meta(STATUS_META[session.health?.status] || STATUS_META.insufficient, lang);
  const codes = sessionDtcs(session, lang).map((d) => d.code);
  const text = [
    `${s.title} — ${session.vehicleName || s.vehicle} (${s.brand})`,
    `${s.date}: ${new Date(session.timestamp).toLocaleString(s.locale)}`,
    `VIN: ${session.vin || '—'}`,
    `${s.status}: ${session.health?.score != null ? `${session.health.score}/100` : '—'} (${statusMeta.label})`,
    `${s.faults}: ${codes.length ? codes.join(', ') : s.none}`,
    session.mode === 'test' ? `⚠️ ${s.testMode}` : '',
    s.footer,
  ]
    .filter(Boolean)
    .join('\n');

  if (navigator.share) {
    try {
      await navigator.share({ title: s.shareTitle, text });
      return { ok: true, method: 'share' };
    } catch (err) {
      if (err?.name === 'AbortError') return { ok: false, error: 'CANCELLED' };
    }
  }
  try {
    await navigator.clipboard.writeText(text);
    return { ok: true, method: 'clipboard' };
  } catch {
    return { ok: false, error: 'SHARE_FAILED' };
  }
}
