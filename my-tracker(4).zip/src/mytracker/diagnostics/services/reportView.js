/**
 * ReportView — تقرير التشخيص عبر نافذة طباعة (window.print → Save as PDF)
 * بدون أي مكتبة PDF. يتبع لغة واجهة المستخدم الحالية (ar/fr/en، RTL تلقائي
 * للعربية). تفاصيل DTC تُشتق من الأكواد المخزنة باللغة الحالية حتى لا
 * "تتجمد" لغة التقارير القديمة.
 */

import { STATUS_META, SEVERITY_META } from './analysisEngine';
import { SYSTEM_LABELS, lookupDtc } from './dtcDatabase';

const esc = (s) =>
  String(s ?? '—').replace(
    /[&<>"]/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c],
  );

const R = {
  ar: {
    title: 'تقرير تشخيص المركبة',
    brand: 'MY TRACKER',
    testMode: 'TEST MODE (بيانات تجريبية)',
    realMode: 'مركبة حقيقية',
    scanMode: 'وضع الفحص',
    connection: 'الاتصال',
    vehicleInfo: 'معلومات المركبة',
    vehicle: 'المركبة',
    makeModel: 'الشركة / الموديل',
    year: 'السنة',
    engine: 'المحرك',
    fuel: 'نوع الوقود',
    health: 'الحالة الصحية',
    insufficient: 'بيانات غير كافية',
    dtcs: 'رموز الأعطال (DTC)',
    noDtcs: 'لا توجد رموز أعطال.',
    stored: 'مخزّن',
    cleared: 'تم المسح',
    causes: 'الأسباب المحتملة',
    checks: 'الفحوصات المقترحة',
    freezeFrame: 'Freeze Frame',
    liveSnapshot: 'لقطة البيانات الحية',
    clearResult: 'نتيجة مسح الأعطال',
    rescanResult: 'نتيجة إعادة الفحص',
    footer: 'مسح رمز العطل لا يعني إصلاح سبب المشكلة — يُنصح بمعالجة السبب الجذري.',
    shareTitle: 'تقرير تشخيص المركبة',
    date: 'التاريخ',
    status: 'الحالة',
    faults: 'الأعطال',
    none: 'لا يوجد',
    locale: 'ar',
  },
  en: {
    title: 'Vehicle Diagnostic Report',
    brand: 'MY TRACKER',
    testMode: 'TEST MODE (demo data)',
    realMode: 'Real vehicle',
    scanMode: 'Scan mode',
    connection: 'Connection',
    vehicleInfo: 'Vehicle Information',
    vehicle: 'Vehicle',
    makeModel: 'Make / Model',
    year: 'Year',
    engine: 'Engine',
    fuel: 'Fuel type',
    health: 'Health Status',
    insufficient: 'Insufficient Data',
    dtcs: 'Fault Codes (DTC)',
    noDtcs: 'No fault codes.',
    stored: 'Stored',
    cleared: 'Cleared',
    causes: 'Possible causes',
    checks: 'Recommended checks',
    freezeFrame: 'Freeze Frame',
    liveSnapshot: 'Live data snapshot',
    clearResult: 'Clear DTC result',
    rescanResult: 'Re-scan result',
    footer:
      'Clearing a fault code does not fix the root cause — addressing the underlying issue is recommended.',
    shareTitle: 'Vehicle Diagnostic Report',
    date: 'Date',
    status: 'Status',
    faults: 'Faults',
    none: 'None',
    locale: 'en',
  },
  fr: {
    title: 'Rapport de diagnostic du véhicule',
    brand: 'MY TRACKER',
    testMode: 'TEST MODE (données démo)',
    realMode: 'Véhicule réel',
    scanMode: 'Mode d’analyse',
    connection: 'Connexion',
    vehicleInfo: 'Informations du véhicule',
    vehicle: 'Véhicule',
    makeModel: 'Marque / Modèle',
    year: 'Année',
    engine: 'Moteur',
    fuel: 'Carburant',
    health: 'État de santé',
    insufficient: 'Données insuffisantes',
    dtcs: 'Codes défaut (DTC)',
    noDtcs: 'Aucun code défaut.',
    stored: 'Enregistré',
    cleared: 'Effacé',
    causes: 'Causes possibles',
    checks: 'Vérifications recommandées',
    freezeFrame: 'Freeze Frame',
    liveSnapshot: 'Aperçu des données en direct',
    clearResult: 'Résultat de l’effacement',
    rescanResult: 'Résultat de la nouvelle analyse',
    footer:
      'Effacer un code défaut ne répare pas la cause — il est recommandé de traiter la cause racine.',
    shareTitle: 'Rapport de diagnostic du véhicule',
    date: 'Date',
    status: 'Statut',
    faults: 'Défauts',
    none: 'Aucun',
    locale: 'fr',
  },
};

const dict = (lang) => R[lang] || R.en;
const meta = (m, lang) => ({ ...m, label: m?.[lang] || m?.en || '' });

/** تفاصيل DTC باللغة الحالية: من الأكواد المخزنة إن وُجدت، وإلا من المخزَّن. */
export function sessionDtcs(session, lang) {
  if (Array.isArray(session.dtcs) && session.dtcs.length) {
    return session.dtcs.map((code) => lookupDtc(code, lang));
  }
  return session.dtcsDetailed || [];
}

function buildReportHtml(session, lang = 'ar') {
  const s = dict(lang);
  const rtl = lang === 'ar';
  const statusMeta = meta(STATUS_META[session.health?.status] || STATUS_META.insufficient, lang);
  const dateStr = new Date(session.timestamp).toLocaleString(s.locale);
  const info = session.vehicleInfo || {};

  const dtcRows =
    sessionDtcs(session, lang)
      .map((d) => {
        const sev = meta(SEVERITY_META[d.severity], lang);
        return `
    <div class="dtc">
      <div class="dtc-head"><b>${esc(d.code)}</b>
        <span class="pill" style="background:${sev.color}22;color:${sev.color}">${esc(sev.label)}</span>
        <span class="muted">${esc(SYSTEM_LABELS[d.system]?.[lang] || SYSTEM_LABELS[d.system]?.en)}</span>
        <span class="muted">${d.status === 'cleared' ? s.cleared : s.stored}</span>
      </div>
      <p>${esc(d.desc)}</p>
      <p class="muted">${esc(s.causes)}: ${esc((d.causes || []).join(' • '))}</p>
      <p class="muted">${esc(s.checks)}: ${esc((d.checks || []).join(' • '))}</p>
    </div>`;
      })
      .join('') || `<p class="muted">${esc(s.noDtcs)}</p>`;

  const row = (v) =>
    `<tr><td>${esc(v.name?.[lang] || v.name?.ar || v.name)}</td><td><bdi dir="ltr">${esc(v.value)} ${esc(v.unit?.[lang] || v.unit?.ar || v.unit || '')}</bdi></td></tr>`;
  const liveRows = session.liveSnapshot
    ? Object.values(session.liveSnapshot).map(row).join('')
    : '';
  const ffRows = session.freezeFrame ? Object.values(session.freezeFrame).map(row).join('') : '';

  return `<!DOCTYPE html><html lang="${s.locale}" dir="${rtl ? 'rtl' : 'ltr'}"><head><meta charset="utf-8">
<title>${esc(s.title)} — ${esc(session.vehicleName || '')}</title>
<style>
  body{font-family:'Segoe UI',Tahoma,Arial,sans-serif;color:#1a2233;max-width:760px;margin:0 auto;padding:32px 24px;line-height:1.7}
  h1{font-size:22px;margin:0 0 4px}
  h2{font-size:16px;margin:28px 0 8px;border-bottom:2px solid #2f6bff;padding-bottom:4px;color:#0a1128}
  .brand{color:#2f6bff}
  .muted{color:#68728a;font-size:13px}
  table{width:100%;border-collapse:collapse;font-size:14px}
  td,th{border:1px solid #dde3ee;padding:6px 10px;text-align:${rtl ? 'right' : 'left'}}
  .health{display:inline-block;padding:8px 18px;border-radius:12px;background:${statusMeta.color}18;color:${statusMeta.color};font-weight:700;font-size:18px}
  .dtc{border:1px solid #e4e9f2;border-radius:10px;padding:10px 14px;margin:8px 0}
  .dtc-head{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
  .pill{padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600}
  .footer{margin-top:36px;font-size:12px;color:#98a1b3;border-top:1px solid #e4e9f2;padding-top:10px}
  @media print{body{padding:0}}
</style></head><body>
  <h1>${esc(s.title)} <span class="brand">— ${esc(s.brand)}</span></h1>
  <p class="muted">${esc(dateStr)} · ${esc(s.scanMode)}: ${session.mode === 'test' ? s.testMode : s.realMode} · ${esc(s.connection)}: ${esc(session.connection?.deviceName || '—')}</p>

  <h2>${esc(s.vehicleInfo)}</h2>
  <table>
    <tr><td>${esc(s.vehicle)}</td><td>${esc(session.vehicleName)}</td></tr>
    <tr><td>${esc(s.makeModel)}</td><td>${esc(info.make)} / ${esc(info.model)}</td></tr>
    <tr><td>${esc(s.year)}</td><td>${esc(info.year)}</td></tr>
    <tr><td>${esc(s.engine)}</td><td>${esc(info.engine)}</td></tr>
    <tr><td>${esc(s.fuel)}</td><td>${esc(info.fuelType)}</td></tr>
    <tr><td>VIN</td><td><bdi dir="ltr">${esc(session.vin || info.vin)}</bdi></td></tr>
  </table>

  <h2>${esc(s.health)}</h2>
  <span class="health">${session.health?.score != null ? `<bdi dir="ltr">${session.health.score} / 100</bdi>` : esc(s.insufficient)} — ${esc(statusMeta.label)}</span>

  <h2>${esc(s.dtcs)}</h2>
  ${dtcRows}

  ${ffRows ? `<h2>${esc(s.freezeFrame)}</h2><table>${ffRows}</table>` : ''}
  ${liveRows ? `<h2>${esc(s.liveSnapshot)}</h2><table>${liveRows}</table>` : ''}

  ${session.clearResult ? `<h2>${esc(s.clearResult)}</h2><p>${esc(session.clearResult.summary)}</p>` : ''}
  ${session.rescanResult ? `<h2>${esc(s.rescanResult)}</h2><p>${esc(session.rescanResult.summary)}</p>` : ''}

  <div class="footer">${esc(s.footer)} · ${esc(s.brand)} — Vehicle Diagnostics V1</div>
</body></html>`;
}

/** فتح نافذة طباعة بالتقرير (Save as PDF من المتصفح). */
export function openPrintableReport(session, lang = 'ar') {
  const html = buildReportHtml(session, lang);
  const win = window.open('', '_blank');
  if (!win) return { ok: false, error: 'POPUP_BLOCKED' };
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => {
    try {
      win.print();
    } catch {
      /* المستخدم يطبع يدويًا */
    }
  }, 400);
  return { ok: true };
}

/** مشاركة ملخص نصي عبر Web Share API، مع fallback بالنسخ للحافظة. */
export async function shareReport(session, lang = 'ar') {
  const s = dict(lang);
  const statusMeta = meta(STATUS_META[session.health?.status] || STATUS_META.insufficient, lang);
  const codes = sessionDtcs(session, lang).map((d) => d.code);
  const text = [
    `${s.title} — ${session.vehicleName || s.vehicle} (${s.brand})`,
    `${s.date}: ${new Date(session.timestamp).toLocaleString(s.locale)}`,
    `VIN: ${session.vin || '—'}`,
    `${s.status}: ${session.health?.score != null ? `${session.health.score}/100` : '—'} (${statusMeta.label})`,
    `${s.faults}: ${codes.length ? codes.join(', ') : s.none}`,
    session.mode === 'test' ? `⚠️ ${s.testMode}` : '',
    s.footer,
  ]
    .filter(Boolean)
    .join('\n');

  if (navigator.share) {
    try {
      await navigator.share({ title: s.shareTitle, text });
      return { ok: true, method: 'share' };
    } catch (err) {
      if (err?.name === 'AbortError') return { ok: false, error: 'CANCELLED' };
    }
  }
  try {
    await navigator.clipboard.writeText(text);
    return { ok: true, method: 'clipboard' };
  } catch {
    return { ok: false, error: 'SHARE_FAILED' };
  }
}
