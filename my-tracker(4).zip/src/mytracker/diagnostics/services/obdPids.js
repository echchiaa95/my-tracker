/**
 * تعريفات PIDs القياسية لـ OBD-II (Mode 01) مع دوال فك الترميز.
 * كل PID: { key, name: {ar,en}, unit: {ar,en}, bytes, decode(A,B,...) }.
 * decode تُرجع رقمًا أو null إذا كانت البيانات غير صالحة.
 */

const decoders = {
  // A*100/255 — نسبة مئوية
  pct: (A) => Math.round((A * 10000) / 255) / 100,
  // A-40 — درجة حرارة مئوية
  temp: (A) => A - 40,
};

const PIDS = [
  {
    pid: '04',
    key: 'engineLoad',
    name: { ar: 'حمل المحرك', en: 'Engine Load' },
    unit: { ar: '٪', en: '%' },
    bytes: 1,
    decode: (b) => decoders.pct(b[0]),
    primary: true,
  },
  {
    pid: '05',
    key: 'coolantTemp',
    name: { ar: 'حرارة سائل التبريد', en: 'Coolant Temp' },
    unit: { ar: '°م', en: '°C' },
    bytes: 1,
    decode: (b) => decoders.temp(b[0]),
    primary: true,
  },
  {
    pid: '0B',
    key: 'map',
    name: { ar: 'ضغط مجمع السحب (MAP)', en: 'Intake Manifold Pressure' },
    unit: { ar: 'kPa', en: 'kPa' },
    bytes: 1,
    decode: (b) => b[0],
  },
  {
    pid: '0C',
    key: 'rpm',
    name: { ar: 'دورات المحرك', en: 'RPM' },
    unit: { ar: 'rpm', en: 'rpm' },
    bytes: 2,
    decode: (b) => Math.round((b[0] * 256 + b[1]) / 4),
    primary: true,
  },
  {
    pid: '0D',
    key: 'speed',
    name: { ar: 'سرعة المركبة', en: 'Vehicle Speed' },
    unit: { ar: 'كم/س', en: 'km/h' },
    bytes: 1,
    decode: (b) => b[0],
    primary: true,
  },
  {
    pid: '0F',
    key: 'intakeTemp',
    name: { ar: 'حرارة هواء السحب', en: 'Intake Air Temp' },
    unit: { ar: '°م', en: '°C' },
    bytes: 1,
    decode: (b) => decoders.temp(b[0]),
  },
  {
    pid: '10',
    key: 'maf',
    name: { ar: 'تدفق الهواء (MAF)', en: 'MAF Air Flow' },
    unit: { ar: 'g/s', en: 'g/s' },
    bytes: 2,
    decode: (b) => Math.round(b[0] * 256 + b[1]) / 100,
  },
  {
    pid: '11',
    key: 'throttle',
    name: { ar: 'موضع خانق الهواء', en: 'Throttle Position' },
    unit: { ar: '٪', en: '%' },
    bytes: 1,
    decode: (b) => decoders.pct(b[0]),
    primary: true,
  },
  {
    pid: '13',
    key: 'o2Present',
    name: { ar: 'حساسات الأكسجين الموجودة', en: 'O2 Sensors Present' },
    unit: { ar: '', en: '' },
    bytes: 1,
    decode: (b) => b[0],
  },
  {
    pid: '14',
    key: 'o2b1s1',
    name: { ar: 'حساس O2 (بنك1-حساس1)', en: 'O2 Sensor B1S1' },
    unit: { ar: 'V', en: 'V' },
    bytes: 2,
    decode: (b) => Math.round(b[0] * 0.005 * 1000) / 1000,
  },
  {
    pid: '15',
    key: 'o2b1s2',
    name: { ar: 'حساس O2 (بنك1-حساس2)', en: 'O2 Sensor B1S2' },
    unit: { ar: 'V', en: 'V' },
    bytes: 2,
    decode: (b) => Math.round(b[0] * 0.005 * 1000) / 1000,
  },
  {
    pid: '1F',
    key: 'runTime',
    name: { ar: 'زمن التشغيل منذ بدء المحرك', en: 'Run Time' },
    unit: { ar: 'ث', en: 's' },
    bytes: 2,
    decode: (b) => b[0] * 256 + b[1],
  },
  {
    pid: '21',
    key: 'milDistance',
    name: { ar: 'المسافة مع لمبة العطل', en: 'Distance with MIL' },
    unit: { ar: 'كم', en: 'km' },
    bytes: 2,
    decode: (b) => b[0] * 256 + b[1],
  },
  {
    pid: '2F',
    key: 'fuelLevel',
    name: { ar: 'مستوى الوقود', en: 'Fuel Level' },
    unit: { ar: '٪', en: '%' },
    bytes: 1,
    decode: (b) => decoders.pct(b[0]),
  },
  {
    pid: '33',
    key: 'baro',
    name: { ar: 'الضغط الجوي', en: 'Barometric Pressure' },
    unit: { ar: 'kPa', en: 'kPa' },
    bytes: 1,
    decode: (b) => b[0],
  },
  {
    pid: '42',
    key: 'controlVoltage',
    name: { ar: 'جهد وحدة التحكم', en: 'Control Module Voltage' },
    unit: { ar: 'V', en: 'V' },
    bytes: 2,
    decode: (b) => Math.round(((b[0] * 256 + b[1]) / 1000) * 100) / 100,
  },
  {
    pid: '46',
    key: 'ambientTemp',
    name: { ar: 'حرارة الهواء الخارجي', en: 'Ambient Air Temp' },
    unit: { ar: '°م', en: '°C' },
    bytes: 1,
    decode: (b) => decoders.temp(b[0]),
  },
  {
    pid: '5C',
    key: 'oilTemp',
    name: { ar: 'حرارة زيت المحرك', en: 'Engine Oil Temp' },
    unit: { ar: '°م', en: '°C' },
    bytes: 1,
    decode: (b) => decoders.temp(b[0]),
  },
];

const PID_BY_CODE = Object.fromEntries(PIDS.map((p) => [p.pid, p]));

/** أهم القيم التي تُعرض أولًا (View More يكشف الباقي). */
const PRIMARY_PID_KEYS = PIDS.filter((p) => p.primary).map((p) => p.key);

/**
 * فك ترميز استجابة "الـPIDs المدعومة" (0100/0120/0140 …).
 * dataBytes: مصفوفة 4 بايتات (بتات) تبدأ من PID الأساس +1.
 * تُرجع قائمة أكواد PIDs المدعومة كنصوص hex بخانتين.
 */
function decodeSupportedPids(basePid, dataBytes) {
  const supported = [];
  const base = parseInt(basePid, 16);
  dataBytes.forEach((byte, byteIndex) => {
    for (let bit = 7; bit >= 0; bit -= 1) {
      if (byte & (1 << bit)) {
        const pidNum = base + byteIndex * 8 + (8 - bit);
        supported.push(pidNum.toString(16).toUpperCase().padStart(2, '0'));
      }
    }
  });
  return supported;
}

export { PIDS, PID_BY_CODE, PRIMARY_PID_KEYS, decodeSupportedPids };
