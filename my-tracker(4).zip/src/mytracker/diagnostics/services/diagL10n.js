import { useLocalization } from '../../../common/components/LocalizationProvider';

/**
 * diagL10n — ترجمة واجهات Diagnostics (ar/en/fr) تتبع language setting
 * الحالية للتطبيق (نفس مصدر LocalizationProvider). أي لغة أخرى → English.
 * القاعدة: لا نصوص ثابتة داخل JSX لشاشات Diagnostics.
 */

const ar = {
  // عام
  vehicleFallback: 'مركبة',
  retry: 'إعادة المحاولة',
  cancel: 'إلغاء',
  delete: 'حذف',
  share: 'مشاركة',
  back: 'رجوع',

  // TEST MODE
  testModeBanner: 'TEST MODE — DEMO DATA · بيانات تجريبية محاكاة وليست من مركبة حقيقية',
  testModeBtn: 'وضع التجربة (TEST MODE)',
  testModeHint: 'بدون محول؟ جرّب التجربة الكاملة ببيانات تجريبية — بدون Bluetooth وبدون USB',

  // Dashboard
  diagnosticsTitle: 'تشخيص السيارة',
  dashSubtitle: 'Vehicle Diagnostics',
  connConnected: 'محول OBD متصل',
  connDisconnected: 'لا يوجد اتصال بمحول OBD',
  connDisconnectedHint: 'صل محول OBD-II بالمركبة ثم ابدأ فحصًا جديدًا',
  pillConnected: 'متصل',
  pillDisconnected: 'غير متصل',
  newScan: 'فحص جديد',
  newScanHint: 'قراءة الأعطال والبيانات الحية عبر OBD-II',
  startScan: 'بدء فحص جديد',
  lastResult: 'آخر نتيجة',
  noDtcsStored: 'لا توجد أعطال مخزنة',
  dtcCount: (n, codes) => `${n} رمز عطل: ${codes}`,
  history: 'سجل الفحوصات',
  historyCount: (n) => `${n} فحص محفوظ`,
  historyHint: 'عرض النتائج السابقة وإنشاء التقارير',
  historyEmptyTitle: 'لا توجد نتائج بعد',
  historyEmptyHint: 'ابدأ أول فحص لمركبتك وستظهر النتيجة هنا',
  compatNote:
    'يعمل الفحص مع محولات ELM327 المتوافقة عبر Bluetooth (BLE) أو USB حسب دعم متصفحك. أجهزة Bluetooth الكلاسيكية وWi-Fi OBD غير مدعومة في نسخة الويب حاليًا.',

  // اختيار المركبة
  selectVehicle: 'اختر المركبة',
  selectVehicleHint: 'اختر المركبة المراد فحصها',
  titleConnect: 'الاتصال',
  titleScanning: 'الفحص',
  titleResult: 'نتيجة الفحص',
  noVehicles: 'لا توجد مركبات',
  noVehiclesHint: 'أضف مركبة من شاشة المركبات أولًا ثم عد هنا',

  // الاتصال
  connectTitle: 'طريقة الاتصال بمحول OBD',
  bleBtn: 'Bluetooth (BLE)',
  bleUnsupported: 'غير مدعوم هنا',
  usbBtn: 'USB (Serial)',
  usbDesktopOnly: 'الحاسوب فقط',
  wifiBtn: 'Wi-Fi OBD — غير متاح في نسخة الويب',
  browserNoSupport:
    'هذا المتصفح لا يدعم اتصال OBD المباشر (Web Bluetooth / Web Serial). استخدم Chrome على Android أو Chrome/Edge على الحاسوب — أو جرّب الوضع التجريبي أدناه.',
  connecting: 'جاري الاتصال بالمحول… اختر الجهاز من نافذة المتصفح',
  changeVehicle: 'تغيير المركبة',
  vinAuto: 'VIN: سيُقرأ تلقائيًا من المركبة إن أمكن',
  vehicleLine1: (make, model, year) => `الشركة: ${make} · الموديل: ${model} · السنة: ${year}`,
  vehicleLine2: (engine, fuel) => `المحرك: ${engine} · الوقود: ${fuel}`,

  // الفحص
  scanningTitle: 'جاري الفحص…',
  scanStopped: 'توقف الفحص',
  stepInit: 'تهيئة المحول والتحقق من وحدة ECU',
  stepVin: 'قراءة رقم الهيكل (VIN)',
  stepSupported: 'اكتشاف القدرات المدعومة (PIDs)',
  stepDtc: 'فحص رموز الأعطال (DTC)',
  stepFreeze: 'قراءة Freeze Frame',
  stepLive: 'قراءة البيانات الحية',
  stepUnavailable: 'غير متاح',

  // النتيجة
  resultTitle: 'نتيجة الفحص',
  dtcsTitle: (n) => `رموز الأعطال (${n})`,
  noDtcsFound: 'لا توجد رموز أعطال مخزنة',
  clearDtcs: 'مسح رموز الأعطال',
  clearing: 'جاري المسح وإعادة الفحص…',
  clearWarning: 'مسح رمز العطل لا يعني إصلاح سبب المشكلة',
  liveDataTitle: 'البيانات الحية',
  noLiveData: 'لم تتوفر بيانات حية من هذه المركبة.',
  viewMore: (n) => `عرض المزيد (${n})`,
  viewLess: 'عرض أقل',
  freezeFrameTitle: 'Freeze Frame',
  reportTitle: 'التقرير',
  downloadPdf: 'تحميل PDF',
  rescan: 'إعادة الفحص',
  backToDashboard: 'العودة للوحة التشخيص',
  shareCopied: 'تم نسخ ملخص التقرير — المشاركة المباشرة غير متاحة في هذا المتصفح',
  shareFailed: 'تعذّرت المشاركة',
  popupBlocked: 'المتصفح منع نافذة الطباعة — اسمح بالنوافذ المنبثقة ثم أعد المحاولة',
  clearDialogTitle: 'تأكيد مسح رموز الأعطال',
  clearDialogBody: (n) =>
    `سيتم مسح ${n} رمز عطل من وحدة ECU ثم إعادة الفحص للمقارنة.\nتنبيه مهم: مسح رمز العطل لا يعني إصلاح سبب المشكلة — قد تعود الرموز إذا استمر العطل الفعلي.`,
  confirmClear: 'تأكيد المسح',
  clearFailed: 'رفضت وحدة ECU طلب المسح — العملية غير مدعومة أو تعذّرت',
  clearSuccess: (n) =>
    `تم مسح ${n} رمز بنجاح. تنبيه: مسح رمز العطل لا يعني إصلاح سبب المشكلة — قد يعود الرمز إذا استمر السبب.`,
  clearReturned: (n, codes) =>
    `عادت ${n} رموز بعد إعادة الفحص فورًا (${codes}) — السبب الجذري ما زال قائمًا ويحتاج إصلاحًا.`,
  clearPartial: (gone, rest, codes) => `تم مسح ${gone} رمز، وبقيت ${rest} رموز (${codes})`,

  // بطاقة DTC
  systemLabel: 'النظام',
  statusLabel: 'الحالة',
  statusStored: 'مخزّن',
  statusCleared: 'تم المسح',
  needsFurtherDiag: 'يتطلب تشخيصًا إضافيًا',
  possibleCauses: 'الأسباب المحتملة',
  recommendedChecks: 'الفحوصات المقترحة',
  notConclusive: 'هذه أسباب محتملة وليست تشخيصًا قطعيًا — قد يلزم فحص إضافي لتحديد السبب الجذري.',

  // السجل
  historyPageTitle: 'سجل الفحوصات',
  historyPageEmpty: 'لا توجد فحوصات محفوظة',
  historyPageEmptyHint: 'نتائج الفحوصات التي تجريها ستظهر هنا',
  liveSnapshotTitle: 'لقطة البيانات الحية',
  clearResultLabel: 'مسح الأعطال',
  rescanResultLabel: 'إعادة الفحص',
  copied: 'تم نسخ الملخص',
};

const en = {
  vehicleFallback: 'Vehicle',
  retry: 'Retry',
  cancel: 'Cancel',
  delete: 'Delete',
  share: 'Share',
  back: 'Back',

  testModeBanner: 'TEST MODE — DEMO DATA · Simulated data, not from a real vehicle',
  testModeBtn: 'Test Mode (TEST MODE)',
  testModeHint: 'No adapter? Try the full experience with demo data — no Bluetooth or USB needed',

  diagnosticsTitle: 'Vehicle Diagnostics',
  dashSubtitle: 'Vehicle Diagnostics',
  connConnected: 'OBD adapter connected',
  connDisconnected: 'No OBD adapter connected',
  connDisconnectedHint: 'Plug an OBD-II adapter into the vehicle, then start a new scan',
  pillConnected: 'Connected',
  pillDisconnected: 'Not connected',
  newScan: 'New Diagnostic',
  newScanHint: 'Read fault codes and live data via OBD-II',
  startScan: 'Start new scan',
  lastResult: 'Last Diagnostic',
  noDtcsStored: 'No stored fault codes',
  dtcCount: (n, codes) => `${n} fault code(s): ${codes}`,
  history: 'Diagnostic History',
  historyCount: (n) => `${n} saved scan(s)`,
  historyHint: 'View previous results and generate reports',
  historyEmptyTitle: 'No results yet',
  historyEmptyHint: 'Run your first vehicle scan and the result will appear here',
  compatNote:
    'Scanning works with ELM327-compatible adapters via Bluetooth (BLE) or USB depending on your browser. Classic Bluetooth and Wi-Fi OBD adapters are not supported in the web version.',

  selectVehicle: 'Select Vehicle',
  noVehicles: 'No vehicles',
  noVehiclesHint: 'Add a vehicle from the Vehicles screen first, then come back',

  connectTitle: 'OBD adapter connection',
  bleBtn: 'Bluetooth (BLE)',
  bleUnsupported: 'not supported here',
  usbBtn: 'USB (Serial)',
  usbDesktopOnly: 'desktop only',
  wifiBtn: 'Wi-Fi OBD — not available in the web version',
  browserNoSupport:
    'This browser does not support direct OBD connection (Web Bluetooth / Web Serial). Use Chrome on Android or Chrome/Edge on desktop — or try Test Mode below.',
  connecting: 'Connecting to adapter… pick the device in the browser prompt',
  changeVehicle: 'Change vehicle',
  vinAuto: 'VIN: will be read from the vehicle automatically when possible',
  vehicleLine1: (make, model, year) => `Make: ${make} · Model: ${model} · Year: ${year}`,
  vehicleLine2: (engine, fuel) => `Engine: ${engine} · Fuel: ${fuel}`,

  scanningTitle: 'Scanning…',
  scanStopped: 'Scan interrupted',
  stepInit: 'Initializing adapter & checking ECU',
  stepVin: 'Reading VIN',
  stepSupported: 'Detecting supported PIDs',
  stepDtc: 'Reading diagnostic codes (DTC)',
  stepFreeze: 'Reading Freeze Frame',
  stepLive: 'Reading live data',
  stepUnavailable: 'unavailable',

  resultTitle: 'Scan Result',
  dtcsTitle: (n) => `Fault Codes (${n})`,
  noDtcsFound: 'No stored fault codes',
  clearDtcs: 'Clear fault codes',
  clearing: 'Clearing and re-scanning…',
  clearWarning: 'Clearing a fault code does not fix the underlying problem',
  liveDataTitle: 'Live Data',
  noLiveData: 'No live data available from this vehicle.',
  viewMore: (n) => `View more (${n})`,
  viewLess: 'View less',
  freezeFrameTitle: 'Freeze Frame',
  reportTitle: 'Report',
  downloadPdf: 'Download PDF',
  rescan: 'Re-scan',
  backToDashboard: 'Back to Diagnostics',
  shareCopied: 'Report summary copied — direct sharing is unavailable in this browser',
  shareFailed: 'Sharing failed',
  popupBlocked: 'The browser blocked the print window — allow pop-ups and try again',
  clearDialogTitle: 'Confirm clearing fault codes',
  clearDialogBody: (n) =>
    `${n} fault code(s) will be cleared from the ECU, followed by a comparison re-scan.\nImportant: clearing a code does not fix the root cause — codes may return if the fault persists.`,
  confirmClear: 'Confirm clear',
  clearFailed: 'The ECU rejected the clear request — operation unsupported or failed',
  clearSuccess: (n) =>
    `${n} code(s) cleared successfully. Note: clearing a code does not fix the root cause — it may return if the fault persists.`,
  clearReturned: (n, codes) =>
    `${n} code(s) returned immediately after re-scan (${codes}) — the root cause still needs repair.`,
  clearPartial: (gone, rest, codes) => `${gone} code(s) cleared, ${rest} remain (${codes})`,

  systemLabel: 'System',
  statusLabel: 'Status',
  statusStored: 'Stored',
  statusCleared: 'Cleared',
  needsFurtherDiag: 'further diagnosis required',
  possibleCauses: 'Possible Causes',
  recommendedChecks: 'Recommended Checks',
  notConclusive:
    'These are possible causes, not a definitive diagnosis — further inspection may be needed to find the root cause.',

  historyPageTitle: 'Diagnostic History',
  historyPageEmpty: 'No saved scans',
  historyPageEmptyHint: 'Results of scans you run will appear here',
  liveSnapshotTitle: 'Live data snapshot',
  clearResultLabel: 'Clear result',
  rescanResultLabel: 'Re-scan result',
  copied: 'Summary copied',
};

const fr = {
  vehicleFallback: 'Véhicule',
  retry: 'Réessayer',
  cancel: 'Annuler',
  delete: 'Supprimer',
  share: 'Partager',
  back: 'Retour',

  testModeBanner: 'TEST MODE — DEMO DATA · Données simulées, ne provenant pas d’un véhicule réel',
  testModeBtn: 'Mode démo (TEST MODE)',
  testModeHint:
    'Pas d’adaptateur ? Essayez l’expérience complète avec des données de démonstration — sans Bluetooth ni USB',

  diagnosticsTitle: 'Diagnostics',
  dashSubtitle: 'Vehicle Diagnostics',
  connConnected: 'Adaptateur OBD connecté',
  connDisconnected: 'Aucun adaptateur OBD connecté',
  connDisconnectedHint:
    'Branchez un adaptateur OBD-II au véhicule, puis lancez un nouveau diagnostic',
  pillConnected: 'Connecté',
  pillDisconnected: 'Non connecté',
  newScan: 'Nouveau diagnostic',
  newScanHint: 'Lire les codes défaut et les données en direct via OBD-II',
  startScan: 'Démarrer un diagnostic',
  lastResult: 'Dernier diagnostic',
  noDtcsStored: 'Aucun code défaut enregistré',
  dtcCount: (n, codes) => `${n} code(s) défaut : ${codes}`,
  history: 'Historique des diagnostics',
  historyCount: (n) => `${n} diagnostic(s) enregistré(s)`,
  historyHint: 'Voir les résultats précédents et générer des rapports',
  historyEmptyTitle: 'Aucun résultat pour le moment',
  historyEmptyHint: 'Lancez votre premier diagnostic et le résultat apparaîtra ici',
  compatNote:
    'Le diagnostic fonctionne avec les adaptateurs compatibles ELM327 via Bluetooth (BLE) ou USB selon votre navigateur. Les adaptateurs Bluetooth classiques et Wi-Fi OBD ne sont pas pris en charge dans la version web.',

  selectVehicle: 'Choisir le véhicule',
  noVehicles: 'Aucun véhicule',
  noVehiclesHint: 'Ajoutez d’abord un véhicule depuis l’écran Véhicules, puis revenez ici',

  connectTitle: 'Connexion à l’adaptateur OBD',
  bleBtn: 'Bluetooth (BLE)',
  bleUnsupported: 'non pris en charge ici',
  usbBtn: 'USB (Serial)',
  usbDesktopOnly: 'ordinateur uniquement',
  wifiBtn: 'Wi-Fi OBD — non disponible dans la version web',
  browserNoSupport:
    'Ce navigateur ne prend pas en charge la connexion OBD directe (Web Bluetooth / Web Serial). Utilisez Chrome sur Android ou Chrome/Edge sur ordinateur — ou essayez le mode démo ci-dessous.',
  connecting: 'Connexion à l’adaptateur… choisissez l’appareil dans la fenêtre du navigateur',
  changeVehicle: 'Changer de véhicule',
  vinAuto: 'VIN : sera lu automatiquement depuis le véhicule si possible',
  vehicleLine1: (make, model, year) => `Marque : ${make} · Modèle : ${model} · Année : ${year}`,
  vehicleLine2: (engine, fuel) => `Moteur : ${engine} · Carburant : ${fuel}`,

  scanningTitle: 'Diagnostic en cours…',
  scanStopped: 'Diagnostic interrompu',
  stepInit: 'Initialisation de l’adaptateur et vérification de l’ECU',
  stepVin: 'Lecture du VIN',
  stepSupported: 'Détection des PID pris en charge',
  stepDtc: 'Lecture des codes défaut (DTC)',
  stepFreeze: 'Lecture du Freeze Frame',
  stepLive: 'Lecture des données en direct',
  stepUnavailable: 'non disponible',

  resultTitle: 'Résultat du diagnostic',
  dtcsTitle: (n) => `Codes défaut (${n})`,
  noDtcsFound: 'Aucun code défaut enregistré',
  clearDtcs: 'Effacer les codes défaut',
  clearing: 'Effacement et nouvelle analyse…',
  clearWarning: 'Effacer un code défaut ne répare pas la cause du problème',
  liveDataTitle: 'Données en direct',
  noLiveData: 'Aucune donnée en direct disponible pour ce véhicule.',
  viewMore: (n) => `Voir plus (${n})`,
  viewLess: 'Voir moins',
  freezeFrameTitle: 'Freeze Frame',
  reportTitle: 'Rapport',
  downloadPdf: 'Télécharger PDF',
  rescan: 'Relancer l’analyse',
  backToDashboard: 'Retour au tableau Diagnostics',
  shareCopied:
    'Résumé du rapport copié — le partage direct n’est pas disponible dans ce navigateur',
  shareFailed: 'Échec du partage',
  popupBlocked:
    'Le navigateur a bloqué la fenêtre d’impression — autorisez les pop-ups et réessayez',
  clearDialogTitle: 'Confirmer l’effacement des codes défaut',
  clearDialogBody: (n) =>
    `${n} code(s) défaut seront effacés de l’ECU, suivis d’une nouvelle analyse de comparaison.\nImportant : effacer un code ne répare pas la cause — les codes peuvent réapparaître si le défaut persiste.`,
  confirmClear: 'Confirmer l’effacement',
  clearFailed: 'L’ECU a refusé la demande d’effacement — opération non prise en charge ou échouée',
  clearSuccess: (n) =>
    `${n} code(s) effacé(s) avec succès. Remarque : effacer un code ne répare pas la cause — il peut réapparaître si le défaut persiste.`,
  clearReturned: (n, codes) =>
    `${n} code(s) réapparu(s) immédiatement après la nouvelle analyse (${codes}) — la cause racine nécessite encore une réparation.`,
  clearPartial: (gone, rest, codes) => `${gone} code(s) effacé(s), ${rest} restant(s) (${codes})`,

  systemLabel: 'Système',
  statusLabel: 'Statut',
  statusStored: 'Enregistré',
  statusCleared: 'Effacé',
  needsFurtherDiag: 'diagnostic supplémentaire requis',
  possibleCauses: 'Causes possibles',
  recommendedChecks: 'Vérifications recommandées',
  notConclusive:
    'Ce sont des causes possibles, pas un diagnostic définitif — une inspection supplémentaire peut être nécessaire.',

  historyPageTitle: 'Historique des diagnostics',
  historyPageEmpty: 'Aucun diagnostic enregistré',
  historyPageEmptyHint: 'Les résultats de vos diagnostics apparaîtront ici',
  liveSnapshotTitle: 'Aperçu des données en direct',
  clearResultLabel: 'Résultat de l’effacement',
  rescanResultLabel: 'Résultat de la nouvelle analyse',
  copied: 'Résumé copié',
};

const DICTS = { ar, en, fr };

export const diagDict = (lang) => DICTS[lang] || DICTS.en;

/** Hook: يُرجع { t, lang, dir } تتبع لغة التطبيق الحالية. */
export const useDiagT = () => {
  const { language } = useLocalization();
  const lang = DICTS[language] ? language : 'en';
  const dict = DICTS[lang];
  return {
    lang,
    dir: lang === 'ar' ? 'rtl' : 'ltr',
    t: (key, ...args) => {
      const v = dict[key];
      return typeof v === 'function' ? v(...args) : (v ?? DICTS.en[key] ?? key);
    },
  };
};

export default DICTS;
