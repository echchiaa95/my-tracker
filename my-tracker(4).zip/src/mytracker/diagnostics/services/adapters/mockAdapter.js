/**
 * MockAdapter — محاكي اختبار فقط (TEST MODE).
 * يحاكي جهاز ELM327 كاملًا على مستوى النص الخام (نفس بروتوكول النقل)،
 * حتى تمر كل الطبقات (Elm327Transport → diagnosticService → analysisEngine)
 * بنفس مسار الوضع الحقيقي. لا يُستخدم إلا باختيار صريح من المستخدم،
 * والواجهة تعرض شريط TEST MODE طوال الجلسة.
 */

const MOCK_VIN = '1HGCM82633A004352';

// PIDs مدعومة في المحاكي (01-40 تقريبًا كسيارة واقعية)
const MOCK_SUPPORTED_HEX = {
  '00': 'BE1FA813', // يدعم 03,04,05,07,0B,0C,0D,0F,10,11,13,14,15,1F,20
  20: '8001B001', // يدعم 21,2F,33,40
  40: '02400000', // يدعم 42,46
};

// عطلا اختبار: P0301 (misfire cyl 1) + P0420 (catalyst)
const MOCK_DTC = '43 03 01 04 20';

const pad2 = (n) => n.toString(16).toUpperCase().padStart(2, '0');

class MockAdapter {
  constructor() {
    this.type = 'mock';
    this.dataCb = null;
    this.connected = false;
    this.cleared = false;
    // قيم حية تتذبذب قليلًا لتبدو طبيعية في الاختبار
    this.t0 = Date.now();
  }

  static isSupported() {
    return true;
  }

  isConnected() {
    return this.connected;
  }

  onData(cb) {
    this.dataCb = cb;
  }

  onDisconnect() {}

  async connect() {
    await new Promise((r) => setTimeout(r, 400));
    this.connected = true;
    return { deviceName: 'TEST MODE — Mock ELM327' };
  }

  liveValue(pid) {
    const t = (Date.now() - this.t0) / 1000;
    const wob = (base, amp, period) => base + amp * Math.sin(t / period);
    switch (pid) {
      case '04':
        return [Math.round(wob(80, 12, 3))]; // حمل ~31%
      case '05':
        return [90 + 40]; // 90°C
      case '0B':
        return [34];
      case '0C': {
        const v = Math.round(wob(880, 60, 2)) * 4;
        return [Math.floor(v / 256), v % 256];
      }
      case '0D':
        return [0]; // السيارة متوقفة أثناء الفحص
      case '0F':
        return [28 + 40];
      case '10': {
        const v = Math.round(wob(680, 60, 2));
        return [Math.floor(v / 256), v % 256];
      }
      case '11':
        return [Math.round(0.14 * 255)];
      case '13':
        return [0x33];
      case '14':
        return [Math.round(wob(140, 30, 1.5)), 0x80];
      case '15':
        return [Math.round(wob(128, 10, 2)), 0x80];
      case '1F': {
        const v = Math.round(t);
        return [Math.floor(v / 256), v % 256];
      }
      case '21':
        return [0x05, 0xdc]; // 1500km مع MIL
      case '2F':
        return [Math.round(0.62 * 255)];
      case '33':
        return [99];
      case '42': {
        const v = 14200;
        return [Math.floor(v / 256), v % 256];
      }
      case '46':
        return [31 + 40];
      default:
        return null;
    }
  }

  respond(text) {
    if (!this.connected) return;
    const cmd = text.trim().toUpperCase();
    setTimeout(
      () => {
        if (!this.connected) return;
        let out;
        if (cmd === 'ATZ') out = '\r\rELM327 v1.5\r>';
        else if (cmd.startsWith('AT')) out = '\rOK\r>';
        else if (cmd === '0902') {
          const hex = Array.from(MOCK_VIN)
            .map((c) => c.charCodeAt(0).toString(16).toUpperCase())
            .join('');
          // ثلاثة أسطر: 49 02 01 + أول 3 بايتات … إلخ
          out = `\r014\r0: 49 02 01 ${hex.slice(0, 6).replace(/(..)/g, '$1 ')}\r1: ${hex.slice(6, 20).replace(/(..)/g, '$1 ')}\r2: ${hex.slice(20, 34).replace(/(..)/g, '$1 ')}\r>`;
        } else if (cmd === '03') {
          out = this.cleared
            ? '\r43 00 00 00 00 00 00\r>'
            : `\r${MOCK_DTC.replace(/(..)/g, '$1 ').trim()}\r>`;
        } else if (cmd === '04') {
          this.cleared = true;
          out = '\r44\r>';
        } else if (cmd.startsWith('02')) {
          // Mode 02 — Freeze Frame: متاح فقط عند وجود أعطال (قبل المسح)
          const pid = cmd.slice(2, 4);
          const val = !this.cleared && pid !== '02' ? this.liveValue(pid) : null;
          out = val ? `\r42 ${pid} 00 ${val.map(pad2).join(' ')}\r>` : '\rNO DATA\r>';
        } else if (cmd.startsWith('01')) {
          const pid = cmd.slice(2, 4);
          if (MOCK_SUPPORTED_HEX[pid]) {
            const bytes = MOCK_SUPPORTED_HEX[pid].replace(/(..)/g, '$1 ').trim();
            out = `\r41 ${pid} ${bytes}\r>`;
          } else {
            const val = this.liveValue(pid);
            out = val ? `\r41 ${pid} ${val.map(pad2).join(' ')}\r>` : '\rNO DATA\r>';
          }
        } else {
          out = '\r?\r>';
        }
        this.dataCb?.(out);
      },
      120 + Math.random() * 180,
    );
  }

  async write(text) {
    this.respond(text);
  }

  async disconnect() {
    this.connected = false;
  }
}

export default MockAdapter;
