/**
 * WebBluetoothAdapter — قناة BLE لأجهزة OBD-II المتوافقة (ELM327 BLE وغيرها).
 *
 * لا نفترض UUID واحدًا ثابتًا: أجهزة BLE تختلف (FFE0/FFF0 الشائعة، Nordic
 * UART 6E40xxxx، وغيرها). لذلك الاكتشاف يتم في مرحلتين:
 *  1) requestDevice مع optionalServices لكل الـUUIDs المعروفة + قبول كل
 *     الأجهزة ليتمكن المستخدم من اختيار جهازه حتى لو كان غير معروف.
 *  2) بعد الاتصال: استكشاف الخدمات والخصائص فعليًا واختيار أول زوج
 *     (notify/indicate للقراءة + write/writeWithoutResponse للكتابة).
 * إذا تعذّر العثور على زوج صالح → خطأ واضح UNSUPPORTED_DEVICE وليس فشلًا صامتًا.
 */

export const BLE_ERRORS = {
  UNSUPPORTED_BROWSER: 'BLE_UNSUPPORTED_BROWSER',
  CANCELLED: 'BLE_CANCELLED',
  CONNECT_FAILED: 'BLE_CONNECT_FAILED',
  UNSUPPORTED_DEVICE: 'BLE_UNSUPPORTED_DEVICE',
  DISCONNECTED: 'BLE_DISCONNECTED',
};

// UUIDs شائعة لمحولات OBD BLE — قائمة مرشحة فقط، الاكتشاف الفعلي ديناميكي.
const KNOWN_SERVICE_UUIDS = [
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000fff0-0000-1000-8000-00805f9b34fb',
  '000018f0-0000-1000-8000-00805f9b34fb',
  '6e400001-b5a3-f393-e0a9-e50e24dcca9e', // Nordic UART
  '49535343-fe7d-4ae5-8fa9-9fafd205e455', // ISSC transparent
];

const encoder = new TextEncoder();
const decoder = new TextDecoder();

class WebBluetoothAdapter {
  constructor() {
    this.type = 'ble';
    this.device = null;
    this.server = null;
    this.rxChar = null; // notify
    this.txChar = null; // write
    this.dataCb = null;
    this.disconnectCb = null;
    this.handleNotification = (event) => {
      if (this.dataCb && event.target.value) {
        this.dataCb(decoder.decode(event.target.value));
      }
    };
    this.handleDisconnect = () => {
      this.rxChar = null;
      this.txChar = null;
      this.server = null;
      this.disconnectCb?.();
    };
  }

  static isSupported() {
    return typeof navigator !== 'undefined' && !!navigator.bluetooth;
  }

  isConnected() {
    return !!(this.device?.gatt?.connected && this.rxChar && this.txChar);
  }

  onData(cb) {
    this.dataCb = cb;
  }
  onDisconnect(cb) {
    this.disconnectCb = cb;
  }

  /** يفتح منتقي الأجهزة ويكتشف قناة UART صالحة. يرمي أحد BLE_ERRORS. */
  async connect() {
    if (!WebBluetoothAdapter.isSupported()) throw new Error(BLE_ERRORS.UNSUPPORTED_BROWSER);
    try {
      this.device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: KNOWN_SERVICE_UUIDS,
      });
    } catch (err) {
      // إلغاء المستخدم من المنتقي ليس خطأ اتصال
      throw new Error(
        err?.name === 'NotFoundError' ? BLE_ERRORS.CANCELLED : BLE_ERRORS.CONNECT_FAILED,
        { cause: err },
      );
    }

    this.device.addEventListener('gattserverdisconnected', this.handleDisconnect);

    try {
      this.server = await this.device.gatt.connect();
    } catch (err) {
      throw new Error(BLE_ERRORS.CONNECT_FAILED, { cause: err });
    }

    // اكتشاف ديناميكي: أول خدمة تحتوي زوج notify + write
    const services = await this.server.getPrimaryServices();
    for (const service of services) {
      let chars;
      try {
        chars = await service.getCharacteristics();
      } catch {
        continue;
      }
      const notify = chars.find((c) => c.properties.notify || c.properties.indicate);
      const write = chars.find((c) => c.properties.write || c.properties.writeWithoutResponse);
      if (notify && write) {
        this.rxChar = notify;
        this.txChar = write;
        break;
      }
    }

    if (!this.rxChar || !this.txChar) {
      try {
        this.server.disconnect();
      } catch {
        /* تجاهل */
      }
      throw new Error(BLE_ERRORS.UNSUPPORTED_DEVICE);
    }

    if (this.rxChar.properties.notify) {
      await this.rxChar.startNotifications();
    } else {
      await this.rxChar.startNotifications(); // indicate يستخدم نفس الـAPI
    }
    this.rxChar.addEventListener('characteristicvaluechanged', this.handleNotification);
    return { deviceName: this.device.name || 'BLE OBD' };
  }

  async write(text) {
    if (!this.txChar) throw new Error(BLE_ERRORS.DISCONNECTED);
    const data = encoder.encode(text);
    // بعض الخصائص لا تدعم writeWithoutResponse
    if (this.txChar.properties.writeWithoutResponse) {
      await this.txChar.writeValueWithoutResponse(data);
    } else {
      await this.txChar.writeValueWithResponse(data);
    }
  }

  async disconnect() {
    try {
      if (this.rxChar) {
        this.rxChar.removeEventListener('characteristicvaluechanged', this.handleNotification);
        await this.rxChar.stopNotifications().catch(() => {});
      }
      this.device?.gatt?.disconnect();
    } catch {
      /* تجاهل */
    }
    this.rxChar = null;
    this.txChar = null;
    this.server = null;
  }
}

export default WebBluetoothAdapter;
