/**
 * AndroidWifiAdapter — قناة Wi-Fi TCP الأصلية لأجهزة ELM327 على Android.
 *
 * يطابق نفس واجهة بقية الـAdapters (connect/onData/onDisconnect/write/disconnect)
 * فيعمل Elm327Transport وDiagnosticService دون أي تغيير في منطق OBD:
 *   UI → DiagnosticService → Elm327Transport → AndroidWifiAdapter → ObdWifiPlugin → Socket
 *
 * TEST MODE لا يمر هنا أبدًا — هذا adapter للوضع الحقيقي فقط، والمسح/القراءة
 * تظهر دائمًا كـ mode: 'real'. لا بيانات وهمية ولا fallback.
 */

import { Capacitor } from '@capacitor/core';
import { ObdWifi } from 'my-tracker-obd-wifi';

export const WIFI_ERRORS = {
  NOT_SUPPORTED: 'WIFI_NOT_SUPPORTED',
  INVALID_IP: 'WIFI_INVALID_IP',
  INVALID_PORT: 'WIFI_INVALID_PORT',
  TIMEOUT: 'TIMEOUT',
  CONNECTION_REFUSED: 'WIFI_CONNECTION_REFUSED',
  UNREACHABLE: 'WIFI_UNREACHABLE',
  CONNECT_FAILED: 'WIFI_CONNECT_FAILED',
  DISCONNECTED: 'DISCONNECTED',
  NOT_CONNECTED: 'NOT_CONNECTED',
};

const IP_RE = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
const MAX_LOG = 400;

class AndroidWifiAdapter {
  constructor() {
    this.type = 'wifi';
    this.dataCb = null;
    this.disconnectCb = null;
    this.logCb = null;
    this.connected = false;
    this.ip = null;
    this.port = null;
    this.debugLog = [];
    this.handles = null;
  }

  static isSupported() {
    return Capacitor.getPlatform() === 'android';
  }

  isConnected() {
    return this.connected;
  }

  onData(cb) {
    this.dataCb = cb;
  }

  onDisconnect(cb) {
    this.disconnectCb = cb;
  }

  onLog(cb) {
    this.logCb = cb; // لوحة debug فقط
  }

  getDebugLog() {
    return this.debugLog;
  }

  pushLog(direction, text) {
    this.debugLog.push({ direction, text: String(text).slice(0, 500), at: Date.now() });
    if (this.debugLog.length > MAX_LOG) this.debugLog.splice(0, this.debugLog.length - MAX_LOG);
    this.logCb?.(this.debugLog);
  }

  /** ربط مستمعي الأحداث (يُستخدم للاتصال وللكشف/معلومات Wi-Fi). */
  async attach() {
    await this.detach();
    await ObdWifi.removeAllListeners().catch(() => {});
    this.handles = [
      await ObdWifi.addListener('data', (e) => this.dataCb?.(e.chunk)),
      await ObdWifi.addListener('log', (e) => this.pushLog(e.direction, e.text)),
      await ObdWifi.addListener('disconnected', (e) => {
        this.connected = false;
        this.pushLog('sys', `disconnected: ${e.reason}`);
        this.disconnectCb?.();
      }),
    ];
  }

  /** معلومات شبكة Wi-Fi الحالية (PART 1) — للكشف/العرض. */
  async getWifiInfo() {
    if (!AndroidWifiAdapter.isSupported()) throw new Error(WIFI_ERRORS.NOT_SUPPORTED);
    await this.attach();
    return ObdWifi.getWifiInfo();
  }

  /** اكتشاف تلقائي لمحول ELM327 على الشبكة المحلية (PART 2+3). */
  async detect() {
    if (!AndroidWifiAdapter.isSupported()) throw new Error(WIFI_ERRORS.NOT_SUPPORTED);
    await this.attach();
    return ObdWifi.detect();
  }

  async connect(options = {}) {
    if (!AndroidWifiAdapter.isSupported()) throw new Error(WIFI_ERRORS.NOT_SUPPORTED);
    const ip = String(options.ip || '').trim();
    const port = Number(options.port);
    const timeoutMs = Number(options.timeoutMs) || 8000;

    const m = IP_RE.exec(ip);
    if (!m || m.slice(1).some((o) => Number(o) > 255)) throw new Error(WIFI_ERRORS.INVALID_IP);
    if (!Number.isInteger(port) || port < 1 || port > 65535) {
      throw new Error(WIFI_ERRORS.INVALID_PORT);
    }

    await this.attach();

    try {
      const res = await ObdWifi.connect({ ip, port, timeoutMs });
      this.connected = true;
      this.ip = ip;
      this.port = port;
      return { deviceName: `ELM327 Wi-Fi ${res.remoteInfo}` };
    } catch (err) {
      await this.detach();
      throw new Error(err?.message || WIFI_ERRORS.CONNECT_FAILED);
    }
  }

  async write(text) {
    if (!this.connected) throw new Error(WIFI_ERRORS.NOT_CONNECTED);
    await ObdWifi.send({ data: text });
  }

  async disconnect() {
    this.connected = false;
    await ObdWifi.disconnect().catch(() => {});
    await this.detach();
  }

  async detach() {
    this.handles?.forEach((h) => h.remove().catch(() => {}));
    this.handles = null;
  }

  /** معلومات المحول التلقائية للواجهة بعد الاتصال. */
  getInfo() {
    return {
      adapter: 'ELM327 Wi-Fi',
      connection: 'Wi-Fi TCP',
      ip: this.ip,
      port: this.port,
      protocol: 'auto', // ATSP0 — اكتشاف تلقائي، لا افتراض ثابت
    };
  }
}

export default AndroidWifiAdapter;
