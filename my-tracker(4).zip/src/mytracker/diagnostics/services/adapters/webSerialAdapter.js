/**
 * WebSerialAdapter — قناة USB-Serial لأجهزة OBD-II السلكية (ELM327 USB /
 * OBDLink USB …) عبر Web Serial API (Chrome/Edge على الحاسوب).
 */

export const SERIAL_ERRORS = {
  UNSUPPORTED_BROWSER: 'SERIAL_UNSUPPORTED_BROWSER',
  CANCELLED: 'SERIAL_CANCELLED',
  CONNECT_FAILED: 'SERIAL_CONNECT_FAILED',
  DISCONNECTED: 'SERIAL_DISCONNECTED',
};

const BAUD_RATES = [38400, 115200, 9600, 230400];

const encoder = new TextEncoder();

class WebSerialAdapter {
  constructor() {
    this.type = 'serial';
    this.port = null;
    this.reader = null;
    this.writer = null;
    this.dataCb = null;
    this.disconnectCb = null;
    this.reading = false;
  }

  static isSupported() {
    return typeof navigator !== 'undefined' && !!navigator.serial;
  }

  isConnected() {
    return !!(this.port && this.writer);
  }

  onData(cb) {
    this.dataCb = cb;
  }
  onDisconnect(cb) {
    this.disconnectCb = cb;
  }

  async connect() {
    if (!WebSerialAdapter.isSupported()) throw new Error(SERIAL_ERRORS.UNSUPPORTED_BROWSER);
    try {
      this.port = await navigator.serial.requestPort();
    } catch (err) {
      throw new Error(
        err?.name === 'NotFoundError' ? SERIAL_ERRORS.CANCELLED : SERIAL_ERRORS.CONNECT_FAILED,
        { cause: err },
      );
    }

    // نحاول baud rates الشائعة — أول واحد يُفتح بنجاح يكفي، والتهيئة (ATZ)
    // في طبقة ELM هي التي تؤكد فعليًا أن القناة تعمل.
    let opened = false;
    let lastError = null;
    for (const baudRate of BAUD_RATES) {
      try {
        await this.port.open({ baudRate });
        opened = true;
        break;
      } catch (err) {
        lastError = err;
      }
    }
    if (!opened) {
      throw Object.assign(new Error(SERIAL_ERRORS.CONNECT_FAILED), { cause: lastError });
    }

    this.writer = this.port.writable.getWriter();
    this.reading = true;
    this.readLoop();
    return { deviceName: 'USB OBD' };
  }

  async readLoop() {
    while (this.reading && this.port?.readable) {
      this.reader = this.port.readable.getReader();
      try {
        for (;;) {
          const { value, done } = await this.reader.read();
          if (done) break;
          if (value) this.dataCb?.(new TextDecoder().decode(value));
        }
      } catch {
        // انقطاع مفاجئ للكابل
      } finally {
        try {
          this.reader.releaseLock();
        } catch {
          /* تجاهل */
        }
        this.reader = null;
      }
      if (this.reading) {
        // القراءة توقفت دون طلب إغلاق → انقطاع فعلي
        this.reading = false;
        this.writer = null;
        this.disconnectCb?.();
        break;
      }
    }
  }

  async write(text) {
    if (!this.writer) throw new Error(SERIAL_ERRORS.DISCONNECTED);
    await this.writer.write(encoder.encode(text));
  }

  async disconnect() {
    this.reading = false;
    try {
      this.writer?.releaseLock();
    } catch {
      /* تجاهل */
    }
    this.writer = null;
    try {
      await this.reader?.cancel();
    } catch {
      /* تجاهل */
    }
    try {
      await this.port?.close();
    } catch {
      /* تجاهل */
    }
    this.port = null;
  }
}

export default WebSerialAdapter;
