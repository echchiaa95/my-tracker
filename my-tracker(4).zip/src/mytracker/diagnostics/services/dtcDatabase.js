/**
 * قاعدة رموز الأعطال (DTC) — الأكواد الأكثر شيوعًا بثلاث لغات (ar/fr/en).
 * أي رمز غير موجود هنا يُعرض بوصف عام صادق — لا نخترع تفاصيل غير موثقة.
 * lookupDtc(code, lang) تُرجع نسخة مسطّحة بلغة واحدة جاهزة للعرض.
 */

const DTC_DB = {
  P0100: {
    severity: 'warning',
    system: 'engine',
    desc: {
      ar: 'عطل في دائرة حساس تدفق الهواء (MAF)',
      fr: 'Défaut du circuit du débitmètre d’air (MAF)',
      en: 'Mass Air Flow (MAF) sensor circuit malfunction',
    },
    causes: {
      ar: [
        'اتساخ أو تلف حساس MAF',
        'تسريب هواء في مجمع السحب',
        'مشكلة في التوصيلات الكهربائية للحساس',
      ],
      fr: [
        'Capteur MAF encrassé ou défectueux',
        'Fuite d’air dans le collecteur d’admission',
        'Problème de câblage du capteur',
      ],
      en: ['Dirty or faulty MAF sensor', 'Intake air leak', 'Sensor wiring issue'],
    },
    checks: {
      ar: ['فحص نظافة حساس MAF', 'فحص خراطيم الهواء بحثًا عن تسريب', 'فحص قابس الحساس وأسلاكه'],
      fr: [
        'Vérifier la propreté du capteur MAF',
        'Vérifier les durites d’air (fuites)',
        'Vérifier le connecteur et le câblage',
      ],
      en: [
        'Check MAF sensor cleanliness',
        'Inspect air hoses for leaks',
        'Inspect sensor connector and wiring',
      ],
    },
  },
  P0171: {
    severity: 'warning',
    system: 'fuel',
    desc: {
      ar: 'خليط الوقود فقير جدًا (بنك 1)',
      fr: 'Mélange trop pauvre (banque 1)',
      en: 'Fuel mixture too lean (Bank 1)',
    },
    causes: {
      ar: ['تسريب هواء غير مقصود', 'ضعف ضغط الوقود', 'اتساخ حساس MAF أو حاقنات الوقود'],
      fr: ['Prise d’air', 'Pression de carburant faible', 'Capteur MAF ou injecteurs encrassés'],
      en: ['Vacuum/intake air leak', 'Low fuel pressure', 'Dirty MAF sensor or injectors'],
    },
    checks: {
      ar: ['فحص خراطيم الفاكيوم', 'قياس ضغط الوقود', 'فحص قراءات حساس الأكسجين'],
      fr: [
        'Vérifier les durites de dépression',
        'Mesurer la pression de carburant',
        'Vérifier les sondes lambda',
      ],
      en: ['Inspect vacuum hoses', 'Measure fuel pressure', 'Check O2 sensor readings'],
    },
  },
  P0172: {
    severity: 'warning',
    system: 'fuel',
    desc: {
      ar: 'خليط الوقود غني جدًا (بنك 1)',
      fr: 'Mélange trop riche (banque 1)',
      en: 'Fuel mixture too rich (Bank 1)',
    },
    causes: {
      ar: ['حاقن وقود مانع للتسريب', 'ضغط وقود مرتفع', 'فلتر هواء مسدود'],
      fr: ['Injecteur qui fuit', 'Pression de carburant élevée', 'Filtre à air obstrué'],
      en: ['Leaking fuel injector', 'High fuel pressure', 'Clogged air filter'],
    },
    checks: {
      ar: ['فحص فلتر الهواء', 'فحص الحاقنات', 'فحص حساس الأكسجين'],
      fr: ['Vérifier le filtre à air', 'Vérifier les injecteurs', 'Vérifier la sonde lambda'],
      en: ['Check air filter', 'Inspect injectors', 'Check O2 sensor'],
    },
  },
  P0300: {
    severity: 'fault',
    system: 'engine',
    desc: {
      ar: 'ضعف احتراق (Misfire) عشوائي في عدة أسطوانات',
      fr: 'Ratés d’allumage aléatoires sur plusieurs cylindres',
      en: 'Random/multiple cylinder misfire detected',
    },
    causes: {
      ar: ['شمعات احتراق متآكلة', 'ملفات إشعال تالفة', 'ضغط وقود غير كافٍ', 'تسريب فاكيوم'],
      fr: [
        'Bougies usées',
        'Bobines d’allumage défectueuses',
        'Pression de carburant insuffisante',
        'Prise d’air',
      ],
      en: [
        'Worn spark plugs',
        'Faulty ignition coils',
        'Insufficient fuel pressure',
        'Vacuum leak',
      ],
    },
    checks: {
      ar: ['فحص شمعات الاحتراق', 'فحص ملفات الإشعال', 'فحص ضغط الوقود'],
      fr: [
        'Vérifier les bougies',
        'Vérifier les bobines d’allumage',
        'Vérifier la pression de carburant',
      ],
      en: ['Inspect spark plugs', 'Check ignition coils', 'Check fuel pressure'],
    },
  },
  P0301: {
    severity: 'fault',
    system: 'engine',
    desc: {
      ar: 'ضعف احتراق (Misfire) في الأسطوانة 1',
      fr: 'Raté d’allumage cylindre 1',
      en: 'Cylinder 1 misfire detected',
    },
    causes: {
      ar: [
        'شمعة احتراق الأسطوانة 1',
        'ملف إشعال الأسطوانة 1',
        'حاقن الأسطوانة 1',
        'ضغط منخفض في الأسطوانة',
      ],
      fr: [
        'Bougie du cylindre 1',
        'Bobine d’allumage du cylindre 1',
        'Injecteur du cylindre 1',
        'Compression faible',
      ],
      en: [
        'Cylinder 1 spark plug',
        'Cylinder 1 ignition coil',
        'Cylinder 1 injector',
        'Low cylinder compression',
      ],
    },
    checks: {
      ar: [
        'فحص/استبدال شمعة الأسطوانة 1',
        'تبديل ملف الإشعال مع أسطوانة أخرى للمقارنة',
        'فحص الحاقن',
      ],
      fr: [
        'Vérifier/remplacer la bougie du cylindre 1',
        'Échanger la bobine avec un autre cylindre pour comparer',
        'Vérifier l’injecteur',
      ],
      en: [
        'Inspect/replace cylinder 1 spark plug',
        'Swap ignition coil with another cylinder to compare',
        'Check injector',
      ],
    },
  },
  P0302: {
    severity: 'fault',
    system: 'engine',
    desc: {
      ar: 'ضعف احتراق (Misfire) في الأسطوانة 2',
      fr: 'Raté d’allumage cylindre 2',
      en: 'Cylinder 2 misfire detected',
    },
    causes: {
      ar: ['شمعة احتراق الأسطوانة 2', 'ملف إشعال الأسطوانة 2', 'حاقن الأسطوانة 2'],
      fr: ['Bougie du cylindre 2', 'Bobine d’allumage du cylindre 2', 'Injecteur du cylindre 2'],
      en: ['Cylinder 2 spark plug', 'Cylinder 2 ignition coil', 'Cylinder 2 injector'],
    },
    checks: {
      ar: ['فحص شمعة الأسطوانة 2', 'فحص ملف الإشعال', 'فحص الحاقن'],
      fr: ['Vérifier la bougie du cylindre 2', 'Vérifier la bobine', 'Vérifier l’injecteur'],
      en: ['Inspect cylinder 2 spark plug', 'Check ignition coil', 'Check injector'],
    },
  },
  P0303: {
    severity: 'fault',
    system: 'engine',
    desc: {
      ar: 'ضعف احتراق (Misfire) في الأسطوانة 3',
      fr: 'Raté d’allumage cylindre 3',
      en: 'Cylinder 3 misfire detected',
    },
    causes: {
      ar: ['شمعة احتراق الأسطوانة 3', 'ملف إشعال الأسطوانة 3', 'حاقن الأسطوانة 3'],
      fr: ['Bougie du cylindre 3', 'Bobine d’allumage du cylindre 3', 'Injecteur du cylindre 3'],
      en: ['Cylinder 3 spark plug', 'Cylinder 3 ignition coil', 'Cylinder 3 injector'],
    },
    checks: {
      ar: ['فحص شمعة الأسطوانة 3', 'فحص ملف الإشعال', 'فحص الحاقن'],
      fr: ['Vérifier la bougie du cylindre 3', 'Vérifier la bobine', 'Vérifier l’injecteur'],
      en: ['Inspect cylinder 3 spark plug', 'Check ignition coil', 'Check injector'],
    },
  },
  P0304: {
    severity: 'fault',
    system: 'engine',
    desc: {
      ar: 'ضعف احتراق (Misfire) في الأسطوانة 4',
      fr: 'Raté d’allumage cylindre 4',
      en: 'Cylinder 4 misfire detected',
    },
    causes: {
      ar: ['شمعة احتراق الأسطوانة 4', 'ملف إشعال الأسطوانة 4', 'حاقن الأسطوانة 4'],
      fr: ['Bougie du cylindre 4', 'Bobine d’allumage du cylindre 4', 'Injecteur du cylindre 4'],
      en: ['Cylinder 4 spark plug', 'Cylinder 4 ignition coil', 'Cylinder 4 injector'],
    },
    checks: {
      ar: ['فحص شمعة الأسطوانة 4', 'فحص ملف الإشعال', 'فحص الحاقن'],
      fr: ['Vérifier la bougie du cylindre 4', 'Vérifier la bobine', 'Vérifier l’injecteur'],
      en: ['Inspect cylinder 4 spark plug', 'Check ignition coil', 'Check injector'],
    },
  },
  P0325: {
    severity: 'warning',
    system: 'engine',
    desc: {
      ar: 'عطل في دائرة حساس الطرق (Knock Sensor)',
      fr: 'Défaut du circuit du capteur de cliquetis',
      en: 'Knock sensor circuit malfunction',
    },
    causes: {
      ar: ['حساس طرق تالف', 'مشكلة في أسلاك الحساس'],
      fr: ['Capteur de cliquetis défectueux', 'Problème de câblage'],
      en: ['Faulty knock sensor', 'Wiring issue'],
    },
    checks: {
      ar: ['فحص توصيلات حساس الطرق', 'اختبار مقاومة الحساس'],
      fr: ['Vérifier le connecteur du capteur', 'Mesurer la résistance du capteur'],
      en: ['Check sensor connector', 'Measure sensor resistance'],
    },
  },
  P0401: {
    severity: 'warning',
    system: 'emissions',
    desc: {
      ar: 'تدفق غير كافٍ في نظام إعادة تدوير العادم (EGR)',
      fr: 'Débit EGR insuffisant',
      en: 'Insufficient EGR flow',
    },
    causes: {
      ar: ['صمام EGR مسدود بالكربون', 'ممرات EGR مسدودة', 'حساس موضع EGR'],
      fr: ['Vanne EGR encrassée', 'Passages EGR obstrués', 'Capteur de position EGR'],
      en: ['Carbon-clogged EGR valve', 'Blocked EGR passages', 'EGR position sensor'],
    },
    checks: {
      ar: ['تنظيف صمام EGR', 'فحص الممرات', 'فحص حركة الصمام'],
      fr: [
        'Nettoyer la vanne EGR',
        'Vérifier les passages',
        'Vérifier le fonctionnement de la vanne',
      ],
      en: ['Clean EGR valve', 'Inspect passages', 'Test valve movement'],
    },
  },
  P0420: {
    severity: 'warning',
    system: 'emissions',
    desc: {
      ar: 'كفاءة المحول الحفاز أقل من الحد المطلوب (بنك 1)',
      fr: 'Efficacité du catalyseur sous le seuil (banque 1)',
      en: 'Catalyst system efficiency below threshold (Bank 1)',
    },
    causes: {
      ar: [
        'تدهور المحول الحفاز',
        'حساس أكسجين خلفي غير دقيق',
        'تسريب في العادم قبل المحول',
        'مشكلة احتراق تؤثر على المحول',
      ],
      fr: [
        'Catalyseur dégradé',
        'Sonde lambda arrière imprécise',
        'Fuite d’échappement avant le catalyseur',
        'Problème de combustion affectant le catalyseur',
      ],
      en: [
        'Degraded catalytic converter',
        'Inaccurate rear O2 sensor',
        'Exhaust leak before catalyst',
        'Combustion issue affecting the catalyst',
      ],
    },
    checks: {
      ar: [
        'فحص قراءات حساسي الأكسجين الأمامي والخلفي ومقارنتهما',
        'فحص العادم بحثًا عن تسريب',
        'استبعاد وجود Misfire قبل الحكم على المحول',
      ],
      fr: [
        'Comparer les sondes lambda avant/arrière',
        'Vérifier les fuites d’échappement',
        'Écarter tout raté d’allumage avant de juger le catalyseur',
      ],
      en: [
        'Compare front/rear O2 sensor readings',
        'Inspect exhaust for leaks',
        'Rule out misfires before condemning the catalyst',
      ],
    },
  },
  P0442: {
    severity: 'info',
    system: 'emissions',
    desc: {
      ar: 'تسريب صغير في نظام بخار الوقود (EVAP)',
      fr: 'Petite fuite du système EVAP',
      en: 'Small EVAP system leak',
    },
    causes: {
      ar: ['غطاء خزان الوقود غير محكم', 'خرطوم EVAP متشقق', 'صمام تطهير'],
      fr: ['Bouchon de réservoir mal serré', 'Durite EVAP fissurée', 'Vanne de purge'],
      en: ['Loose fuel cap', 'Cracked EVAP hose', 'Purge valve'],
    },
    checks: {
      ar: ['إحكام غطاء الوقود أولًا', 'فحص خراطيم EVAP', 'اختبار دخان للنظام'],
      fr: ['Resserrer le bouchon d’abord', 'Vérifier les durites EVAP', 'Test de fumée'],
      en: ['Tighten fuel cap first', 'Inspect EVAP hoses', 'Smoke test the system'],
    },
  },
  P0455: {
    severity: 'warning',
    system: 'emissions',
    desc: {
      ar: 'تسريب كبير في نظام بخار الوقود (EVAP)',
      fr: 'Fuite importante du système EVAP',
      en: 'Large EVAP system leak',
    },
    causes: {
      ar: ['غطاء خزان الوقود مفقود/تالف', 'خرطوم منفصل', 'صمام EVAP عالق مفتوحًا'],
      fr: [
        'Bouchon de réservoir manquant/défectueux',
        'Durite débranchée',
        'Vanne EVAP bloquée ouverte',
      ],
      en: ['Missing/damaged fuel cap', 'Disconnected hose', 'EVAP valve stuck open'],
    },
    checks: {
      ar: ['فحص غطاء الوقود', 'فحص الخراطيم والوصلات', 'اختبار دخان'],
      fr: ['Vérifier le bouchon', 'Vérifier durites et raccords', 'Test de fumée'],
      en: ['Check fuel cap', 'Inspect hoses and fittings', 'Smoke test'],
    },
  },
  P0500: {
    severity: 'warning',
    system: 'transmission',
    desc: {
      ar: 'عطل في حساس سرعة المركبة (VSS)',
      fr: 'Défaut du capteur de vitesse (VSS)',
      en: 'Vehicle speed sensor (VSS) malfunction',
    },
    causes: {
      ar: ['حساس السرعة تالف', 'مشكلة في الأسلاك', 'خلل في وحدة ناقل الحركة'],
      fr: [
        'Capteur de vitesse défectueux',
        'Problème de câblage',
        'Problème de module transmission',
      ],
      en: ['Faulty speed sensor', 'Wiring issue', 'Transmission module fault'],
    },
    checks: {
      ar: ['فحص حساس السرعة وتوصيلاته', 'فحص قراءة السرعة الحية'],
      fr: ['Vérifier le capteur et son connecteur', 'Vérifier la vitesse en données en direct'],
      en: ['Check sensor and connector', 'Verify live speed reading'],
    },
  },
  P0562: {
    severity: 'warning',
    system: 'electrical',
    desc: {
      ar: 'جهد نظام الشحن منخفض',
      fr: 'Tension du système de charge faible',
      en: 'Charging system voltage low',
    },
    causes: {
      ar: ['بطارية ضعيفة', 'دينمو (Alternator) لا يشحن كفاية', 'توصيلات مرتخية أو مؤكسدة'],
      fr: ['Batterie faible', 'Alternateur insuffisant', 'Connexions desserrées ou oxydées'],
      en: ['Weak battery', 'Undercharging alternator', 'Loose or corroded connections'],
    },
    checks: {
      ar: ['قياس جهد البطارية أثناء التشغيل', 'فحص أقطاب البطارية', 'اختبار الدينمو'],
      fr: ['Mesurer la tension moteur tournant', 'Vérifier les bornes', 'Tester l’alternateur'],
      en: ['Measure battery voltage while running', 'Inspect terminals', 'Test alternator'],
    },
  },
  P0700: {
    severity: 'fault',
    system: 'transmission',
    desc: {
      ar: 'طلب إضاءة لمبة العطل من وحدة ناقل الحركة',
      fr: 'Demande d’allumage du témoin par le module transmission',
      en: 'Transmission control module requested MIL',
    },
    causes: {
      ar: ['عطل مخزّن في وحدة TCM يحتاج فحصًا بجهاز يدعم ناقل الحركة'],
      fr: ['Un défaut est enregistré dans le TCM — nécessite un outil compatible transmission'],
      en: ['A fault is stored in the TCM — requires a transmission-capable scanner'],
    },
    checks: {
      ar: ['قراءة أكواد وحدة ناقل الحركة'],
      fr: ['Lire les codes du module transmission'],
      en: ['Read transmission module codes'],
    },
  },
  P0128: {
    severity: 'warning',
    system: 'cooling',
    desc: {
      ar: 'حرارة سائل التبريد أقل من المطلوب (ثرموستات)',
      fr: 'Température du liquide de refroidissement sous le seuil (thermostat)',
      en: 'Coolant temperature below thermostat regulating threshold',
    },
    causes: {
      ar: ['ثرموستات عالق مفتوحًا', 'حساس حرارة سائل التبريد'],
      fr: ['Thermostat bloqué ouvert', 'Capteur de température du liquide'],
      en: ['Thermostat stuck open', 'Coolant temperature sensor'],
    },
    checks: {
      ar: ['متابعة وصول الحرارة لـ90°م أثناء القيادة', 'فحص الثرموستات'],
      fr: ['Vérifier que la température atteint ~90°C en roulant', 'Vérifier le thermostat'],
      en: ['Check that coolant reaches ~90°C while driving', 'Inspect thermostat'],
    },
  },
  P0505: {
    severity: 'warning',
    system: 'engine',
    desc: {
      ar: 'عطل في نظام التحكم بالتباطؤ (Idle Control)',
      fr: 'Défaut du système de régulation de ralenti',
      en: 'Idle control system malfunction',
    },
    causes: {
      ar: ['صمام تباطؤ متسخ', 'تسريب فاكيوم', 'خانق متسخ'],
      fr: ['Vanne de ralenti encrassée', 'Prise d’air', 'Papillon encrassé'],
      en: ['Dirty idle control valve', 'Vacuum leak', 'Dirty throttle body'],
    },
    checks: {
      ar: ['تنظيف جسم الخانق', 'فحص صمام التباطؤ'],
      fr: ['Nettoyer le corps de papillon', 'Vérifier la vanne de ralenti'],
      en: ['Clean throttle body', 'Check idle control valve'],
    },
  },
  P0135: {
    severity: 'warning',
    system: 'emissions',
    desc: {
      ar: 'عطل في دائرة تسخين حساس الأكسجين (بنك1 حساس1)',
      fr: 'Défaut du circuit de chauffage de la sonde lambda (banque 1, sonde 1)',
      en: 'O2 sensor heater circuit (Bank 1, Sensor 1)',
    },
    causes: {
      ar: ['عنصر تسخين الحساس تالف', 'فيوز أو أسلاك'],
      fr: ['Résistance de chauffage HS', 'Fusible ou câblage'],
      en: ['Faulty heater element', 'Fuse or wiring'],
    },
    checks: {
      ar: ['فحص فيوز الحساس', 'قياس مقاومة التسخين'],
      fr: ['Vérifier le fusible', 'Mesurer la résistance de chauffage'],
      en: ['Check sensor fuse', 'Measure heater resistance'],
    },
  },
  P0113: {
    severity: 'info',
    system: 'engine',
    desc: {
      ar: 'قراءة عالية من حساس حرارة هواء السحب',
      fr: 'Signal haut du capteur de température d’air d’admission',
      en: 'Intake air temperature sensor circuit high',
    },
    causes: {
      ar: ['حساس IAT تالف', 'أسلاك مقطوعة'],
      fr: ['Capteur IAT défectueux', 'Câblage coupé'],
      en: ['Faulty IAT sensor', 'Broken wiring'],
    },
    checks: {
      ar: ['فحص قابس الحساس', 'مقارنة قراءة IAT مع الحرارة الخارجية'],
      fr: ['Vérifier le connecteur', 'Comparer la lecture IAT avec la température ambiante'],
      en: ['Check sensor connector', 'Compare IAT reading with ambient temperature'],
    },
  },
};

const SYSTEM_LABELS = {
  engine: { ar: 'المحرك', en: 'Engine', fr: 'Moteur' },
  fuel: { ar: 'الوقود', en: 'Fuel', fr: 'Carburant' },
  emissions: { ar: 'الانبعاثات', en: 'Emissions', fr: 'Émissions' },
  transmission: { ar: 'ناقل الحركة', en: 'Transmission', fr: 'Transmission' },
  electrical: { ar: 'الكهرباء', en: 'Electrical', fr: 'Électrique' },
  cooling: { ar: 'التبريد', en: 'Cooling', fr: 'Refroidissement' },
  unknown: { ar: 'عام', en: 'General', fr: 'Général' },
};

const SEVERITY_ORDER = { fault: 3, warning: 2, info: 1 };

const GENERIC_BY_LETTER = {
  P: {
    ar: 'رمز عطل متعلق بمجموعة الحركة (محرك/ناقل حركة)',
    fr: 'Code défaut lié au groupe motopropulseur',
    en: 'Powertrain-related fault code',
  },
  C: {
    ar: 'رمز عطل متعلق بالهيكل (فرامل/تعليق)',
    fr: 'Code défaut lié au châssis (freins/suspension)',
    en: 'Chassis-related fault code (brakes/suspension)',
  },
  B: {
    ar: 'رمز عطل متعلق بهيكل المركبة',
    fr: 'Code défaut lié à la carrosserie',
    en: 'Body-related fault code',
  },
  U: {
    ar: 'رمز عطل في شبكة الاتصال بين الوحدات',
    fr: 'Code défaut du réseau de communication entre modules',
    en: 'Network communication fault code',
  },
};

const FURTHER = {
  ar: 'يلزم فحص إضافي لتحديد السبب',
  fr: 'Un diagnostic supplémentaire est requis pour déterminer la cause',
  en: 'Further diagnosis required to determine the cause',
};

const GENERIC_CHECK = {
  ar: 'تسجيل الرمز ومراجعة مختص أو دليل المركبة',
  fr: 'Noter le code et consulter un spécialiste ou le manuel du véhicule',
  en: 'Record the code and consult a specialist or the vehicle manual',
};

const NOT_DOCUMENTED_SUFFIX = {
  ar: 'الوصف التفصيلي غير موثق محليًا، يُنصح بالبحث عن الرمز أو مراجعة مختص',
  fr: 'description détaillée non documentée localement — recherchez le code ou consultez un spécialiste',
  en: 'detailed description not documented locally — look up the code or consult a specialist',
};

const pick = (obj, lang) => obj?.[lang] ?? obj?.en ?? obj?.ar ?? '';

/**
 * الاستعلام عن رمز عطل بلغة محددة. يُرجع كائنًا مسطّحًا جاهزًا للعرض:
 * { code, documented, severity, system, desc, causes[], checks[] }
 */
export function lookupDtc(code, lang = 'ar') {
  const entry = DTC_DB[code];
  if (entry) {
    return {
      code,
      documented: true,
      severity: entry.severity,
      system: entry.system,
      desc: pick(entry.desc, lang),
      causes: entry.causes[lang] || entry.causes.en,
      checks: entry.checks[lang] || entry.checks.en,
    };
  }
  const generic = GENERIC_BY_LETTER[code[0]] || {
    ar: 'رمز عطل',
    fr: 'Code défaut',
    en: 'Fault code',
  };
  return {
    code,
    documented: false,
    severity: 'warning',
    system: 'unknown',
    desc: `${pick(generic, lang)} — ${NOT_DOCUMENTED_SUFFIX[lang] || NOT_DOCUMENTED_SUFFIX.en}`,
    causes: [FURTHER[lang] || FURTHER.en],
    checks: [GENERIC_CHECK[lang] || GENERIC_CHECK.en],
  };
}

export { SYSTEM_LABELS, SEVERITY_ORDER };
export default DTC_DB;
