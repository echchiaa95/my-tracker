// قاموس أكواد الأعطال الشائعة — شرح مبسط وسبب محتمل لكل كود.
// يغطي أكثر الأكواد شيوعًا في محركات البنزين؛ غير المدرج يُعاد null والواجهة تعرض تلميحًا عامًا.
const DB = {
  P0100: { t: { ar: 'عطل دائرة مقياس تدفق الهواء (MAF)', fr: 'Circuit du débitmètre d\'air (MAF)' }, c: { ar: 'حساس MAF متسخ أو تالف، فيشة كهربائية، تسريب هواء في الخراطيم', fr: 'Capteur MAF sale/défectueux, connecteur, fuite d\'air' } },
  P0101: { t: { ar: 'أداء غير منطقي لحساس تدفق الهواء', fr: 'Performance du MAF hors plage' }, c: { ar: 'تسريب هواء غير مقاس بعد الحساس، حساس متسخ', fr: 'Fuite d\'air non mesurée, capteur encrassé' } },
  P0110: { t: { ar: 'عطل دائرة حساس حرارة الهواء الداخل (IAT)', fr: 'Circuit IAT (température air admission)' }, c: { ar: 'حساس حرارة تالف أو فيشة مفكوكة', fr: 'Capteur ou connecteur défectueux' } },
  P0115: { t: { ar: 'عطل دائرة حساس حرارة سائل التبريد (ECT)', fr: 'Circuit ECT (température liquide de refroidissement)' }, c: { ar: 'حساس الحرارة تالف — يؤثر على تسخين المحرك والاستهلاك', fr: 'Capteur ECT défectueux — affecte chauffage et conso' } },
  P0116: { t: { ar: 'أداء غير منطقي لحساس حرارة التبريد', fr: 'Performance ECT hors plage' }, c: { ar: 'حساس يسجل حرارة غير واقعية، تسريب سائل تبريد', fr: 'Valeurs irréalistes, fuite de liquide de refroidissement' } },
  P0120: { t: { ar: 'عطل دائرة حساس الخانق الإلكتروني (TPS)', fr: 'Circuit du capteur de papillon (TPS)' }, c: { ar: 'حساس الخانق تالف أو الفيشة مفكوكة', fr: 'Capteur TPS ou connecteur défectueux' } },
  P0171: { t: { ar: 'خليط وقود فقير جدًا (صف 1)', fr: 'Mélange trop pauvre (banc 1)' }, c: { ar: 'تسريب هواء (خرطيم/جوانت)، MAF متسخ، ضغط وقود منخفض، حساس أكسجين', fr: 'Fuite d\'air, MAF sale, pression carburant basse' } },
  P0172: { t: { ar: 'خليط وقود غني جدًا (صف 1)', fr: 'Mélange trop riche (banc 1)' }, c: { ar: 'حاقن تسريب، حساس أكسجين، ضغط وقود عالٍ', fr: 'Injecteur qui fuit, capteur O2, pression élevée' } },
  P0174: { t: { ar: 'خليط فقير جدًا (صف 2)', fr: 'Mélange trop pauvre (banc 2)' }, c: { ar: 'نفس أسباب P0171 على الصف الثاني من الأسطوانات', fr: 'Comme P0171, banc 2' } },
  P0201: { t: { ar: 'عطل حاقن الأسطوانة 1', fr: 'Injecteur cylindre 1' }, c: { ar: 'حاقن مسدود أو تالف كهربائيًا، ملف الحاقن', fr: 'Injecteur bouché ou électriquement HS' } },
  P0202: { t: { ar: 'عطل حاقن الأسطوانة 2', fr: 'Injecteur cylindre 2' }, c: { ar: 'حاقن مسدود أو تالف', fr: 'Injecteur bouché ou HS' } },
  P0203: { t: { ar: 'عطل حاقن الأسطوانة 3', fr: 'Injecteur cylindre 3' }, c: { ar: 'حاقن مسدود أو تالف', fr: 'Injecteur bouché ou HS' } },
  P0204: { t: { ar: 'عطل حاقن الأسطوانة 4', fr: 'Injecteur cylindre 4' }, c: { ar: 'حاقن مسدود أو تالف', fr: 'Injecteur bouché ou HS' } },
  P0300: { t: { ar: 'احتراق متقطع عشوائي (Misfire)', fr: 'Ratés d\'allumage aléatoires' }, c: { ar: 'شمعات إشعال، ملفات، حاقنات، ضغط أسطوانات، تسريب هواء', fr: 'Bougies, bobines, injecteurs, compression' } },
  P0301: { t: { ar: 'احتراق متقطع — الأسطوانة 1', fr: 'Ratés d\'allumage — cylindre 1' }, c: { ar: 'شمعة/ملف/حاقن الأسطوانة 1، أو ضغط ضعيف فيها', fr: 'Bougie/bobine/injecteur cylindre 1' } },
  P0302: { t: { ar: 'احتراق متقطع — الأسطوانة 2', fr: 'Ratés d\'allumage — cylindre 2' }, c: { ar: 'شمعة/ملف/حاقن الأسطوانة 2', fr: 'Bougie/bobine/injecteur cylindre 2' } },
  P0303: { t: { ar: 'احتراق متقطع — الأسطوانة 3', fr: 'Ratés d\'allumage — cylindre 3' }, c: { ar: 'شمعة/ملف/حاقن الأسطوانة 3', fr: 'Bougie/bobine/injecteur cylindre 3' } },
  P0304: { t: { ar: 'احتراق متقطع — الأسطوانة 4', fr: 'Ratés d\'allumage — cylindre 4' }, c: { ar: 'شمعة/ملف/حاقن الأسطوانة 4', fr: 'Bougie/bobine/injecteur cylindre 4' } },
  P0325: { t: { ar: 'عطل دائرة حساس قرقعة المحرك (Knock)', fr: 'Circuit du capteur de cliquetis' }, c: { ar: 'حساس القرقعة تالف أو مسامير تثبيت مفكوكة', fr: 'Capteur cliquetis ou serrage défectueux' } },
  P0335: { t: { ar: 'عطل دائرة حساس موضع العمود المرفقي (CKP)', fr: 'Circuit CKP (position vilebrequin)' }, c: { ar: 'السيارة لن تشتغل غالبًا — حساس أو فيشة أو سير مؤقت', fr: 'Souvent non-démarrage : capteur, connecteur, courroie' } },
  P0340: { t: { ar: 'عطل دائرة حساس عمود الكامات (CMP)', fr: 'Circuit CMP (arbre à cames)' }, c: { ar: 'حساس الكامات تالف — اهتزاز وتقطيع في الأداء', fr: 'Capteur AAC défectueux — à-coups' } },
  P0400: { t: { ar: 'عطل في نظام إعادة تدوير غاز العادم (EGR)', fr: 'Panne système EGR' }, c: { ar: 'صمام EGR متسخ عالق، خراطيم مسدودة', fr: 'Vanne EGR encrassée, durites bouchées' } },
  P0401: { t: { ar: 'تدفق EGR غير كافٍ', fr: 'Débit EGR insuffisant' }, c: { ar: 'صمام EGR عالق بالإغلاق — نظّفه أو استبدله', fr: 'Vanne EGR colmatée en fermeture' } },
  P0420: { t: { ar: 'كفاءة محول حفاز ضعيفة (صف 1)', fr: 'Efficacité catalyseur banc 1' }, c: { ar: 'حفاز منتهي أو حساس أكسجين خلفي تالف، تسريب عادم', fr: 'Catalyseur usé ou sonde O2 arrière, fuite échappement' } },
  P0430: { t: { ar: 'كفاءة محول حفاز ضعيفة (صف 2)', fr: 'Efficacité catalyseur banc 2' }, c: { ar: 'نفس أسباب P0420 على الصف الثاني', fr: 'Comme P0420, banc 2' } },
  P0440: { t: { ar: 'عطل في نظام امتصاص أبخرة الوقود (EVAP)', fr: 'Panne circuit EVAP' }, c: { ar: 'غطاء خزان مفكوك، خرطوم مسدود، صمام EVAP عالق', fr: 'Bouchon réservoir, durite, vanne EVAP' } },
  P0442: { t: { ar: 'تسريب صغير في نظام EVAP', fr: 'Fuite mineure détectée (EVAP)' }, c: { ar: 'غالبًا غطاء خزان الوقود غير محكم — أغلقه جيدًا أولًا', fr: 'Souvent le bouchon du réservoir — revisser d\'abord' } },
  P0455: { t: { ar: 'تسريب كبير في نظام EVAP', fr: 'Fuite importante détectée (EVAP)' }, c: { ar: 'خرطوم مفتوح، خزان وقود، صمام purge', fr: 'Durite ouverte, réservoir, vanne de purge' } },
  P0500: { t: { ar: 'عطل دائرة حساس السرعة (VSS)', fr: 'Circuit capteur de vitesse' }, c: { ar: 'حساس السرعة أو عداد/كابل، يؤثر على ناقل الحركة', fr: 'Capteur VSS — affecte la boîte' } },
  P0505: { t: { ar: 'عطل في نظام التهدئة (IAC)', fr: 'Panne régulateur de ralenti (IAC)' }, c: { ar: 'صمام التهدئة متسخ — رalenti متذبذب أو انطفاء', fr: 'Vanne de ralenti encrassée — régime instable' } },
  P0562: { t: { ar: 'جهد بطارية منخفض', fr: 'Tension batterie basse' }, c: { ar: 'بطارية ضعيفة، دينامو، أطراف مفكوكة/مؤكسدة', fr: 'Batterie faible, alternateur, cosses oxydées' } },
  P0700: { t: { ar: 'عطل مسجل في وحدة ناقل الحركة (TCM)', fr: 'Défaut enregistré boîte de vitesses (TCM)' }, c: { ar: 'اقرأ أكواد ناقل الحركة التفصيلية بجهاز يدعم TCM', fr: 'Lire les codes détaillés TCM avec un appareil adapté' } },
  P1101: { t: { ar: 'تسريب هواء في نظام السحب (مدخل MAF)', fr: 'Fuite d\'air admission (après MAF)' }, c: { ar: 'خرطوم مفتوح بين MAF والخانق، جوانت PCV', fr: 'Durite ouverte entre MAF et papillon, joint PCV' } },
  P1158: { t: { ar: 'عطل في مسار ملف الحاقن', fr: 'Panne circuit bobine d\'injecteur' }, c: { ar: 'ملف حاقن أو كابل تالف', fr: 'Bobine injecteur ou câblage' } },
  P1327: { t: { ar: 'قرقعة (Knock) مكتشفة من ECU', fr: 'Cliquetis détecté par l\'ECU' }, c: { ar: 'وقود رديء أو توقيت مبكر، تحقق من نوع الوقود', fr: 'Carburant médiocre ou avance — vérifier l\'essence' } },
  P2096: { t: { ar: 'خليط فقير بعد الحفاز (بنك 1)', fr: 'Mélange pauvre post-catalyseur (banc 1)' }, c: { ar: 'حساس O2 خلفي، تسريب عادم، ضغط وقود', fr: 'Sonde O2 arrière, fuite échappement' } },
  P2195: { t: { ar: 'حساس O2 أمامي علق على الفقير (بنك 1)', fr: 'Sonde O2 avant bloquée pauvre' }, c: { ar: 'حساس أكسجين تالف أو تسريب هواء حقيقي', fr: 'Sonde O2 HS ou vraie fuite d\'air' } },
  U0100: { t: { ar: 'فقدان الاتصال مع وحدة تحكم المحرك', fr: 'Perte de communication avec l\'ECU moteur' }, c: { ar: 'فيه كهرباء/كنيكترات CAN، بطارية ضعيفة أثناء التشغيل', fr: 'Câblage CAN, cosse, batterie faible' } },
  B0001: { t: { ar: 'عطل في دائرة وسادة هوائية سائق', fr: 'Circuit airbag conducteur' }, c: { ar: 'فيه ساعة الدركسيون/مقاومة — يحتاج فنيًا', fr: 'Contacteur tournant — faire vérifier' } },
};

/** يُرجع { title, cause } مترجمًا حسب اللغة، أو null إن لم يُعرف الكود. */
export function explainDtc(code, lang = 'ar') {
  if (!code) return null;
  const e = DB[code.toUpperCase()];
  if (!e) return null;
  return {
    title: e.t[lang] || e.t.en,
    cause: e.c[lang] || e.c.en,
  };
}

export default DB;
