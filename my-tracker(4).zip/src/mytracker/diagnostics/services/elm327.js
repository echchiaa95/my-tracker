/**
 * Elm327Transport — طبقة بروتوكول ELM327 فوق أي Adapter (BLE / Serial / Mock).
 * الـAdapter يوفّر فقط: write(text) و onData(cb) و disconnect().
 * هذه الطبقة تتولى: تهيئة ELM، إرسال الأوامر، تجميع الردود حتى '>' prompt،
 * وتصفية الردود (إزالة echo، "SEARCHING..."، "NO DATA" …).
 */

export const ELM_ERRORS = {
  NO_DATA: 'NO_DATA',
  UNABLE_TO_CONNECT: 'UNABLE_TO_CONNECT',
  TIMEOUT: 'TIMEOUT',
  STOPPED: 'STOPPED',
  NOT_CONNECTED: 'NOT_CONNECTED',
};

class Elm327Transport {
  /**
   * @param {object} adapter — { write(text), onData(cb), disconnect(), isConnected() }
   */
  constructor(adapter) {
    this.adapter = adapter;
    this.buffer = '';
    this.waiter = null;
    this.initialized = false;

    adapter.onData((text) => {
      this.buffer += text;
      if (this.waiter && this.buffer.includes('>')) {
        const raw = this.buffer;
        this.buffer = '';
        const { resolve, timeoutId } = this.waiter;
        this.waiter = null;
        clearTimeout(timeoutId);
        resolve(raw);
      }
    });
  }

  /** إرسال أمر وانتظار الرد حتى prompt '>'. */
  command(cmd, { timeout = 4000 } = {}) {
    if (!this.adapter.isConnected()) {
      return Promise.reject(new Error(ELM_ERRORS.NOT_CONNECTED));
    }
    this.buffer = '';
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        this.waiter = null;
        reject(new Error(ELM_ERRORS.TIMEOUT));
      }, timeout);
      this.waiter = { resolve, timeoutId };
      this.adapter.write(cmd + '\r').catch((err) => {
        if (this.waiter) {
          this.waiter = null;
          clearTimeout(timeoutId);
        }
        reject(err);
      });
    });
  }

  /**
   * تهيئة ELM327: إعادة ضبط + إيقاف echo/linefeeds/spaces + تفعيل headers
   * + بروتوكول تلقائي. تُرجع { ok, protocol } أو ترمي خطأ.
   */
  async initialize(onStep) {
    await this.command('ATZ', { timeout: 6000 }); // reset — الرد "ELM327 v1.x"
    await this.command('ATE0'); // echo off
    await this.command('ATL0'); // linefeeds off
    await this.command('ATS0'); // spaces off
    await this.command('ATH1'); // headers on (نحتاجها لتصفية الردود)
    await this.command('ATSP0'); // protocol auto
    // فحص الاتصال الفعلي مع الـECU: 0100 يجب أن يعيد بيانات حقيقية.
    onStep?.('ecu');
    const resp = await this.command('0100', { timeout: 8000 });
    const lines = this.parseHexLines(resp, '41');
    if (!lines.length) {
      throw new Error(
        resp.includes('UNABLE TO CONNECT') ? ELM_ERRORS.UNABLE_TO_CONNECT : ELM_ERRORS.NO_DATA,
      );
    }
    this.initialized = true;
    return { ok: true };
  }

  /**
   * استخراج أسطر hex النظيفة لردود mode معين من نص خام.
   * يُزيل echo، prompt، "SEARCHING..."، ويرفض "NO DATA"/"?".
   * modePrefix مثل '41' (ردود Mode 01) أو '43' (Mode 03).
   */
  parseHexLines(raw, modePrefix) {
    const cleaned = raw
      .replace(/>/g, '\n')
      .split(/[\r\n]+/)
      .map((l) => l.trim())
      .filter(Boolean);
    const bad = [
      'SEARCHING',
      'NO DATA',
      'UNABLE TO CONNECT',
      'STOPPED',
      'ERROR',
      '?',
      'ELM327',
      'AT',
    ];
    const lines = [];
    for (const line of cleaned) {
      const upper = line.toUpperCase();
      if (bad.some((b) => upper.startsWith(b))) continue;
      const hex = upper.replace(/[^0-9A-F]/g, '');
      if (!hex.length) continue;
      // مع headers: "7E80641BE1F" → نبحث عن modePrefix ثم نأخذ البيانات بعده
      const idx = hex.indexOf(modePrefix);
      if (idx >= 0 && idx <= 6) {
        lines.push(hex.slice(idx));
      }
    }
    return lines;
  }

  /**
   * استعلام Mode 01 لـ PID واحد. يُرجع بايتات البيانات (بعد "41 XX")
   * أو null إذا NO DATA/غير مدعوم.
   */
  async queryPid(pid, { timeout = 3000 } = {}) {
    const resp = await this.command(`01${pid}`, { timeout });
    const lines = this.parseHexLines(resp, '41');
    for (const line of lines) {
      // line يبدأ بـ '41' ثم pid (خانتين) ثم البيانات
      if (line.slice(2, 4) === pid.toUpperCase()) {
        const dataHex = line.slice(4);
        const bytes = [];
        for (let i = 0; i + 1 < dataHex.length; i += 2) {
          bytes.push(parseInt(dataHex.slice(i, i + 2), 16));
        }
        return bytes;
      }
    }
    return null; // NO DATA أو PID غير مدعوم
  }

  /** قراءة VIN (Mode 09 PID 02). يُرجع النص أو null. */
  async readVin() {
    const resp = await this.command('0902', { timeout: 6000 });
    const rawLines = resp
      .replace(/>/g, '\n')
      .split(/[\r\n]+/)
      .map((l) => l.trim())
      .filter(Boolean);
    const bad = [
      'SEARCHING',
      'NO DATA',
      'UNABLE TO CONNECT',
      'STOPPED',
      'ERROR',
      '?',
      'ELM327',
      'AT',
    ];
    // تجميع تيار hex واحد: نُزيل فهرس الإطار "N:" من بداية كل سطر ثم نأخذ
    // الـhex الصافي، ونبدأ من أول سطر يحتوي '49' (رد Mode 09).
    let stream = '';
    let started = false;
    for (const line of rawLines) {
      const upper = line.toUpperCase();
      if (bad.some((b) => upper.startsWith(b))) continue;
      const noIndex = upper.replace(/^[0-9A-F]:/, '');
      const hex = noIndex.replace(/[^0-9A-F]/g, '');
      if (!hex.length) continue;
      if (!started) {
        const idx = hex.indexOf('49');
        if (idx < 0 || idx > 6) continue;
        stream = hex.slice(idx);
        started = true;
      } else {
        stream += hex;
      }
    }
    if (!started || stream.length < 6 || stream.slice(2, 4) !== '02') return null;
    // بعد '49 02' يأتي بايت تسلسل (01) ثم بيانات ASCII عبر الإطارات
    let vinHex = stream.slice(6);
    let vin = '';
    for (let i = 0; i + 1 < vinHex.length; i += 2) {
      const code = parseInt(vinHex.slice(i, i + 2), 16);
      if (code >= 32 && code <= 126) vin += String.fromCharCode(code);
    }
    vin = vin.trim();
    return vin.length >= 11 ? vin : null;
  }

  /**
   * قراءة رموز الأعطال Mode 03. يُرجع مصفوفة أكواد مثل ['P0420'].
   */
  async readDtcs() {
    const resp = await this.command('03', { timeout: 6000 });
    const lines = this.parseHexLines(resp, '43');
    const bytes = [];
    for (const line of lines) {
      const dataHex = line.slice(2); // بعد '43'
      for (let i = 0; i + 1 < dataHex.length; i += 2) {
        bytes.push(parseInt(dataHex.slice(i, i + 2), 16));
      }
    }
    const dtcs = [];
    for (let i = 0; i + 1 < bytes.length; i += 2) {
      const code = this.decodeDtcBytes(bytes[i], bytes[i + 1]);
      if (code) dtcs.push(code);
    }
    return [...new Set(dtcs)];
  }

  /** فك ترميز زوج بايتات DTC إلى نص مثل P0420. null إذا فارغ (0x0000). */
  decodeDtcBytes(a, b) {
    if (a === 0 && b === 0) return null;
    const systems = ['P', 'C', 'B', 'U'];
    const sys = systems[(a >> 6) & 0x03];
    const d1 = ((a >> 4) & 0x03).toString();
    const d2 = (a & 0x0f).toString(16).toUpperCase();
    const d34 = b.toString(16).toUpperCase().padStart(2, '0');
    return `${sys}${d1}${d2}${d34}`;
  }

  /**
   * قراءة Freeze Frame (Mode 02) لمجموعة PIDs. يُرجع { pid: bytes|null }.
   */
  async readFreezeFrame(pids) {
    const result = {};
    for (const pid of pids) {
      const resp = await this.command(`02${pid}00`, { timeout: 3000 });
      const lines = this.parseHexLines(resp, '42');
      let bytes = null;
      for (const line of lines) {
        if (line.slice(2, 4) === pid.toUpperCase()) {
          const dataHex = line.slice(6); // بعد 42 PID frame#
          bytes = [];
          for (let i = 0; i + 1 < dataHex.length; i += 2) {
            bytes.push(parseInt(dataHex.slice(i, i + 2), 16));
          }
          break;
        }
      }
      result[pid] = bytes;
    }
    return result;
  }

  /** مسح رموز الأعطال (Mode 04). يُرجع true عند النجاح الظاهري. */
  async clearDtcs() {
    const resp = await this.command('04', { timeout: 6000 });
    if (resp.includes('NO DATA') || resp.includes('?')) return false;
    return this.parseHexLines(resp, '44').length > 0 || resp.includes('OK');
  }
}

export default Elm327Transport;
