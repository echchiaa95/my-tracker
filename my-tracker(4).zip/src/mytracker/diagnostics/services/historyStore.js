/**
 * HistoryStore — حفظ جلسات التشخيص محليًا عبر storageService (نفس مخزن
 * My Tracker الحالي). تُحفظ النتائج النهائية فقط (DTCs, Health, VIN …)
 * ولا تُحفظ Live Data المستمرة — فقط لقطة ملخصة من القيم الرئيسية.
 */

import storageService from '../../services/storageService';

const MAX_SESSIONS = 30;

function getContainer() {
  const state = storageService.getState();
  return state.diagnostics?.sessions || [];
}

function persist(sessions) {
  storageService.update('diagnostics', { sessions });
}

const historyStore = {
  /** كل الجلسات، الأحدث أولًا. */
  list() {
    return [...getContainer()].sort((a, b) => b.timestamp - a.timestamp);
  },

  getById(id) {
    return getContainer().find((s) => s.id === id) || null;
  },

  /** آخر جلسة لمركبة معينة (أو أحدث جلسة إجمالًا بدون vehicleId). */
  lastFor(vehicleId) {
    const all = this.list();
    return vehicleId ? all.find((s) => s.vehicleId === vehicleId) || null : all[0] || null;
  },

  /**
   * @param {object} session — {
   *   vehicleId, vehicleName, vehicleInfo:{make,model,year,engine,fuelType,vin},
   *   mode: 'real'|'test', vin, dtcsDetailed, health:{score,status},
   *   liveSnapshot, freezeFrame, connection:{type,deviceName}
   * }
   */
  save(session) {
    const entry = {
      id: `diag-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      timestamp: Date.now(),
      clearResult: null,
      rescanResult: null,
      ...session,
    };
    const sessions = [entry, ...getContainer()].slice(0, MAX_SESSIONS);
    persist(sessions);
    return entry;
  },

  /** تحديث جلسة موجودة (مثلًا بعد Clear DTC / Re-scan). */
  update(id, patch) {
    const sessions = getContainer().map((s) => (s.id === id ? { ...s, ...patch } : s));
    persist(sessions);
    return this.getById(id);
  },

  remove(id) {
    persist(getContainer().filter((s) => s.id !== id));
  },
};

export default historyStore;
