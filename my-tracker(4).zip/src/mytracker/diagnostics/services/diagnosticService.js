/**
 * DiagnosticService — الطبقة المركزية للتشخيص (Vehicle Diagnostics V1).
 *
 * الفصل الصارم:  UI ↔ DiagnosticService ↔ Elm327Transport ↔ Adapter
 * لا تتعامل الواجهة مع بروتوكول OBD إطلاقًا، ولا تعرف شيئًا عن BLE/Serial.
 *
 * Real Mode: ممنوع أي بيانات وهمية أو fallback إلى Mock — أي فشل يظهر
 * للمستخدم كخطأ واضح. Mock لا يُستخدم إلا عبر adapter من نوع 'mock'
 * وباختيار صريح من شاشة الاتصال، وتُوسم كل نتائجه بـ mode: 'test'.
 */

import { Capacitor } from '@capacitor/core';
import Elm327Transport, { ELM_ERRORS } from './elm327';
import { PIDS, PID_BY_CODE, decodeSupportedPids } from './obdPids';
import WebBluetoothAdapter, { BLE_ERRORS } from './adapters/webBluetoothAdapter';
import WebSerialAdapter, { SERIAL_ERRORS } from './adapters/webSerialAdapter';
import MockAdapter from './adapters/mockAdapter';
import AndroidWifiAdapter, { WIFI_ERRORS } from './adapters/androidWifiAdapter';

export const DIAG_ERRORS = {
  ...ELM_ERRORS,
  ...BLE_ERRORS,
  ...SERIAL_ERRORS,
  ...WIFI_ERRORS,
  VIN_UNAVAILABLE: 'VIN_UNAVAILABLE',
};

// Wi-Fi OBD متاح فقط داخل تطبيق Android الأصلي (TCP خام غير ممكن من Web).
// في المتصفح يبقى معطّلًا مع نفس الرسالة السابقة — سلوك Web لم يتغير.
export const ADAPTER_TYPES = [
  { type: 'ble', label: { ar: 'Bluetooth (BLE)', en: 'Bluetooth (BLE)' } },
  { type: 'serial', label: { ar: 'USB (Serial)', en: 'USB (Serial)' } },
  {
    type: 'wifi',
    label: { ar: 'Wi-Fi OBD', en: 'Wi-Fi OBD' },
    disabled: !Capacitor.isNativePlatform(),
  },
];

function createAdapter(type) {
  if (type === 'ble') return new WebBluetoothAdapter();
  if (type === 'serial') return new WebSerialAdapter();
  if (type === 'mock') return new MockAdapter();
  if (type === 'wifi') {
    if (!Capacitor.isNativePlatform()) throw new Error(DIAG_ERRORS.WIFI_NOT_SUPPORTED);
    return new AndroidWifiAdapter();
  }
  throw new Error(DIAG_ERRORS.CONNECT_FAILED || 'CONNECT_FAILED');
}

class DiagnosticService {
  constructor() {
    this.adapter = null;
    this.transport = null;
    this.mode = null; // 'real' | 'test'
    this.state = 'idle'; // idle | connecting | connected | busy | error
    this.deviceName = null;
    this.listeners = new Set();
  }

  /* ---------- أحداث ---------- */
  subscribe(cb) {
    this.listeners.add(cb);
    cb(this.snapshot());
    return () => this.listeners.delete(cb);
  }

  emit() {
    const snap = this.snapshot();
    this.listeners.forEach((cb) => cb(snap));
  }

  snapshot() {
    return {
      state: this.state,
      mode: this.mode,
      deviceName: this.deviceName,
      connected: this.state === 'connected' || this.state === 'busy',
    };
  }

  setState(state) {
    this.state = state;
    this.emit();
  }

  /* ---------- التوافق ---------- */
  /** فحص توافق المتصفح/الجهاز قبل عرض خيارات الاتصال. */
  checkCompatibility() {
    return {
      ble: WebBluetoothAdapter.isSupported(),
      serial: WebSerialAdapter.isSupported(),
      // Wi-Fi TCP متاح فقط في تطبيق Android الأصلي (Capacitor)؛ في المتصفح العادي false
      wifi: Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android',
      secureContext: typeof window !== 'undefined' && window.isSecureContext,
    };
  }

  /* ---------- الاتصال ---------- */
  async connect(adapterType, options) {
    if (this.state === 'connecting' || this.state === 'busy') return;
    // await إلزامي هنا: بدونها كانت الدالة async تستأنف لاحقًا فتصفّر
    // this.adapter بعد إنشائه (سباق) — وهذا كان سبب فشل TEST MODE الفعلي.
    await this.disconnectSilently();
    this.adapter = createAdapter(adapterType);
    this.mode = adapterType === 'mock' ? 'test' : 'real';
    this.setState('connecting');

    this.adapter.onDisconnect(() => {
      this.transport = null;
      this.deviceName = null;
      this.setState('idle');
    });

    try {
      const info = await this.adapter.connect(options);
      this.deviceName = info.deviceName;
      this.transport = new Elm327Transport(this.adapter);
      this.setState('connected');
      return { ok: true, deviceName: info.deviceName };
    } catch (err) {
      const code = err?.message || DIAG_ERRORS.CONNECT_FAILED || 'CONNECT_FAILED';
      this.adapter = null;
      this.transport = null;
      this.deviceName = null;
      this.setState('error');
      return { ok: false, error: code };
    }
  }

  async disconnect() {
    await this.disconnectSilently();
    this.setState('idle');
  }

  async disconnectSilently() {
    try {
      await this.adapter?.disconnect();
    } catch {
      /* تجاهل */
    }
    this.adapter = null;
    this.transport = null;
    this.deviceName = null;
  }

  requireTransport() {
    if (!this.transport || !this.adapter?.isConnected()) {
      throw new Error(DIAG_ERRORS.NOT_CONNECTED);
    }
    return this.transport;
  }

  /**
   * لقطة بيانات حية سريعة أثناء الاتصال (بعد الفحص) — لاستخدامها في لوحة "مباشر".
   * يستعلم الـ PIDs الأولية فقط ويتسامح مع فشل أي منها.
   */
  async readLiveSnapshot(lang = 'ar') {
    const t = this.requireTransport();
    const result = {};
    const primary = PIDS.filter((p) => p.primary);
    for (const def of primary) {
      try {
        const bytes = await t.queryPid(def.pid);
        if (bytes && bytes.length >= def.bytes) {
          const value = def.decode(bytes);
          if (value !== null && value !== undefined) {
            result[def.key] = {
              value,
              unit: def.unit?.[lang] || def.unit?.en || '',
              name: def.name?.[lang] || def.name?.en || def.key,
            };
          }
        }
      } catch {
        /* تخطّي PID فاشل — لا توقف اللوحة */
      }
    }
    return result;
  }

  /** معلومات المحول التلقائية (§16) — تعرضها الواجهة بعد الاتصال. */
  getConnectionInfo() {
    return this.adapter?.getInfo?.() || null;
  }

  /** سجل debug (أوامر/ردود ELM327) — للوحة debug في واجهة Wi-Fi. */
  getDebugLog() {
    return this.adapter?.getDebugLog?.() || [];
  }

  /**
   * اكتشاف تلقائي لمحول ELM327 عبر Wi-Fi (Android native فقط).
   * ينشئ adapter مؤقتًا دون المساس بحالة الاتصال الحالية.
   */
  async detectWifiAdapter() {
    if (!Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') {
      throw new Error(DIAG_ERRORS.WIFI_NOT_SUPPORTED);
    }
    const adapter = new AndroidWifiAdapter();
    const r = await adapter.detect();
    this.lastWifiAdapter = adapter; // لاستمرار ظهور سجل debug
    return r;
  }

  /** معلومات شبكة Wi-Fi الحالية (Android native فقط). */
  async getWifiInfo() {
    if (!Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') {
      throw new Error(DIAG_ERRORS.WIFI_NOT_SUPPORTED);
    }
    const adapter = new AndroidWifiAdapter();
    return adapter.getWifiInfo();
  }

  async withBusy(fn) {
    this.setState('busy');
    try {
      return await fn(this.requireTransport());
    } finally {
      this.setState(this.adapter?.isConnected() ? 'connected' : 'idle');
    }
  }

  /* ---------- عمليات OBD ---------- */

  /** تهيئة ELM + التحقق من استجابة ECU. */
  initialize(onStep) {
    return this.withBusy((t) => t.initialize(onStep));
  }

  /** VIN — يُرجع { vin: string|null }. null = غير متاح من هذه المركبة. */
  async getVIN() {
    return this.withBusy(async (t) => ({ vin: await t.readVin() }));
  }

  /**
   * الـPIDs المدعومة من المركبة (عبر 0100/0120/0140).
   * يُرجع قائمة أكواد hex؛ لا يفترض دعم أي PID غير مُعلن.
   */
  async getSupportedPIDs() {
    return this.withBusy(async (t) => {
      const supported = new Set();
      let base = '00';
      for (let depth = 0; depth < 3; depth += 1) {
        const bytes = await t.queryPid(base, { timeout: 5000 });
        if (!bytes || bytes.length < 4) break;
        decodeSupportedPids(base, bytes.slice(0, 4)).forEach((p) => supported.add(p));
        // البت الأخير يشير لوجود مجموعة تالية
        const hasMore = (bytes[3] & 0x01) === 1;
        if (!hasMore) break;
        base = (parseInt(base, 16) + 0x20).toString(16).toUpperCase().padStart(2, '0');
      }
      return [...supported];
    });
  }

  /** قراءة رموز الأعطال المخزنة (Mode 03). */
  readDTC() {
    return this.withBusy((t) => t.readDtcs());
  }

  /** مسح رموز الأعطال (Mode 04) — الواجهة تتولى التأكيد قبل الاستدعاء. */
  clearDTC() {
    return this.withBusy((t) => t.clearDtcs());
  }

  /** Freeze Frame (Mode 02) للـPIDs الأساسية — null للقيم غير المتوفرة. */
  getFreezeFrame() {
    return this.withBusy(async (t) => {
      const pids = ['02', '04', '05', '0C', '0D'];
      const raw = await t.readFreezeFrame(pids);
      const frame = {};
      Object.entries(raw).forEach(([pid, bytes]) => {
        const def = PID_BY_CODE[pid];
        if (def && bytes && bytes.length >= def.bytes) {
          frame[def.key] = { value: def.decode(bytes), unit: def.unit, name: def.name };
        }
      });
      return Object.keys(frame).length ? frame : null;
    });
  }

  /**
   * قراءة لقطة Live Data: فقط الـPIDs المُعلن عنها في supportedPids والتي
   * لدينا فك ترميز لها. PID غير مدعوم لا يُقرأ أصلًا (لا بيانات وهمية).
   */
  async readLiveData(supportedPids) {
    return this.withBusy(async (t) => {
      const readable = PIDS.filter((p) => supportedPids.includes(p.pid) && p.pid !== '13');
      const result = {};
      for (const def of readable) {
        try {
          const bytes = await t.queryPid(def.pid);
          if (bytes && bytes.length >= def.bytes) {
            const value = def.decode(bytes);
            if (value !== null && Number.isFinite(value)) {
              result[def.key] = { value, unit: def.unit, name: def.name, pid: def.pid };
            }
          }
        } catch {
          // PID فشل وقتيًا — يُتجاهل ولا يعرض شيئًا بدلًا عنه
        }
      }
      return result;
    });
  }

  /**
   * فحص متكامل بخطوات واضحة للمستخدم (onStep يستقبل مفاتيح المراحل):
   * init → vin → supported → dtc → freezeFrame → liveData
   */
  async scan(onStep) {
    onStep?.('init', 'active');
    await this.initialize();
    onStep?.('init', 'done');

    onStep?.('vin', 'active');
    let vin = null;
    try {
      vin = await this.withBusy((t) => t.readVin());
    } catch {
      // VIN غير متاح في بعض المركبات — يبقى null ويظهر كـ"غير متاح"
    }
    onStep?.('vin', vin ? 'done' : 'skipped');

    onStep?.('supported', 'active');
    const supportedPids = await this.getSupportedPIDs();
    onStep?.('supported', 'done');

    onStep?.('dtc', 'active');
    const dtcs = await this.readDTC();
    onStep?.('dtc', 'done');

    onStep?.('freeze', 'active');
    let freezeFrame = null;
    if (dtcs.length) {
      try {
        freezeFrame = await this.getFreezeFrame();
      } catch {
        freezeFrame = null;
      }
    }
    onStep?.('freeze', freezeFrame ? 'done' : 'skipped');

    onStep?.('live', 'active');
    const liveData = await this.readLiveData(supportedPids);
    onStep?.('live', 'done');

    return { vin, supportedPids, dtcs, freezeFrame, liveData };
  }
}

const diagnosticService = new DiagnosticService();
export default diagnosticService;
