import { DIAG_ERRORS } from './diagnosticService';

/**
 * خريطة أكواد الأخطاء إلى رسائل مفهومة (ar/en/fr): المشكلة + ما يمكن فعله.
 * لا تُعرض رسائل تقنية خام للمستخدم أبدًا.
 */
const M = {
  [DIAG_ERRORS.BLE_UNSUPPORTED_BROWSER]: {
    ar: [
      'Bluetooth غير مدعوم في هذا المتصفح',
      'استخدم Chrome على Android أو Chrome/Edge على الحاسوب. Safari على iPhone لا يدعم Web Bluetooth حاليًا.',
    ],
    en: [
      'Bluetooth is not supported in this browser',
      'Use Chrome on Android or Chrome/Edge on desktop. Safari on iPhone does not support Web Bluetooth.',
    ],
    fr: [
      'Bluetooth non pris en charge dans ce navigateur',
      'Utilisez Chrome sur Android ou Chrome/Edge sur ordinateur. Safari sur iPhone ne prend pas en charge Web Bluetooth.',
    ],
  },
  [DIAG_ERRORS.SERIAL_UNSUPPORTED_BROWSER]: {
    ar: [
      'اتصال USB غير مدعوم في هذا المتصفح',
      'اتصال USB متاح فقط في Chrome/Edge على الحاسوب. جرّب Bluetooth على الهاتف بدلًا منه.',
    ],
    en: [
      'USB connection is not supported in this browser',
      'USB is only available in Chrome/Edge on desktop. Try Bluetooth on your phone instead.',
    ],
    fr: [
      'Connexion USB non prise en charge dans ce navigateur',
      'L’USB est disponible uniquement dans Chrome/Edge sur ordinateur. Essayez le Bluetooth sur téléphone.',
    ],
  },
  [DIAG_ERRORS.WIFI_NOT_SUPPORTED]: {
    ar: [
      'أجهزة OBD عبر Wi-Fi غير مدعومة في نسخة الويب',
      'متصفحات الويب لا تسمح باتصال TCP المباشر الذي تحتاجه أجهزة Wi-Fi OBD. استخدم محول BLE أو USB.',
    ],
    en: [
      'Wi-Fi OBD adapters are not supported in the web version',
      'Web browsers do not allow the raw TCP connection these adapters need. Use a BLE or USB adapter.',
    ],
    fr: [
      'Les adaptateurs Wi-Fi OBD ne sont pas pris en charge dans la version web',
      'Les navigateurs n’autorisent pas la connexion TCP directe requise. Utilisez un adaptateur BLE ou USB.',
    ],
  },
  [DIAG_ERRORS.BLE_CANCELLED]: {
    ar: [
      'لم يتم اختيار جهاز',
      'أعد المحاولة واختر محول OBD من القائمة. تأكد أن المحول مُشغَّل ومرئي.',
    ],
    en: [
      'No device selected',
      'Try again and pick the OBD adapter from the list. Make sure it is powered on and visible.',
    ],
    fr: [
      'Aucun appareil sélectionné',
      'Réessayez et choisissez l’adaptateur OBD dans la liste. Vérifiez qu’il est allumé et visible.',
    ],
  },
  [DIAG_ERRORS.SERIAL_CANCELLED]: {
    ar: ['لم يتم اختيار منفذ USB', 'أعد المحاولة واختر منفذ المحول من القائمة.'],
    en: ['No USB port selected', 'Try again and pick the adapter port from the list.'],
    fr: [
      'Aucun port USB sélectionné',
      'Réessayez et choisissez le port de l’adaptateur dans la liste.',
    ],
  },
  [DIAG_ERRORS.CONNECT_FAILED]: {
    ar: [
      'فشل الاتصال بالمحول',
      'تأكد أن المحول موصول بمنفذ OBD-II وأن بطارية المركبة تعمل، ثم أعد المحاولة.',
    ],
    en: [
      'Failed to connect to the adapter',
      'Make sure the adapter is plugged into the OBD-II port and the vehicle has power, then try again.',
    ],
    fr: [
      'Échec de connexion à l’adaptateur',
      'Vérifiez que l’adaptateur est branché sur la prise OBD-II et que le véhicule est alimenté, puis réessayez.',
    ],
  },
  [DIAG_ERRORS.UNSUPPORTED_DEVICE]: {
    ar: [
      'لم يتم العثور على محول تشخيص متوافق',
      'تم الاتصال بالجهاز لكن لم يُعثر على قناة OBD صالحة فيه. تأكد أنه محول ELM327 متوافق مع BLE.',
    ],
    en: [
      'No compatible diagnostic adapter found',
      'The device connected but no valid OBD channel was found. Make sure it is an ELM327-compatible BLE adapter.',
    ],
    fr: [
      'Aucun adaptateur de diagnostic compatible trouvé',
      'L’appareil s’est connecté mais aucun canal OBD valide n’a été trouvé. Vérifiez qu’il s’agit d’un adaptateur ELM327 compatible BLE.',
    ],
  },
  [DIAG_ERRORS.UNABLE_TO_CONNECT]: {
    ar: [
      'المحول لا يستطيع الوصول لوحدة ECU',
      'شغّل المحرك (أو ضع المفتاح في وضع ON)، وتأكد أن المركبة تدعم OBD-II، ثم أعد الفحص.',
    ],
    en: [
      'The adapter cannot reach the ECU',
      'Start the engine (or turn ignition ON), make sure the vehicle supports OBD-II, then scan again.',
    ],
    fr: [
      'L’adaptateur ne parvient pas à joindre l’ECU',
      'Démarrez le moteur (ou mettez le contact), vérifiez que le véhicule prend en charge OBD-II, puis relancez.',
    ],
  },
  [DIAG_ERRORS.NO_DATA]: {
    ar: [
      'لا توجد استجابة من وحدة ECU',
      'المركبة قد لا تدعم OBD-II القياسي أو البروتوكول غير مدعوم. جرّب مع المحرك يعمل.',
    ],
    en: [
      'No response from the ECU',
      'The vehicle may not support standard OBD-II or the protocol is unsupported. Try with the engine running.',
    ],
    fr: [
      'Aucune réponse de l’ECU',
      'Le véhicule ne prend peut-être pas en charge l’OBD-II standard ou le protocole est incompatible. Essayez moteur tournant.',
    ],
  },
  [DIAG_ERRORS.TIMEOUT]: {
    ar: [
      'انتهت مهلة الاتصال',
      'استجابة المحول بطيئة جدًا. قرّب الهاتف من المحول وتأكد من ثبات الاتصال، ثم أعد المحاولة.',
    ],
    en: [
      'Connection timed out',
      'The adapter is responding too slowly. Move the phone closer and ensure a stable connection, then retry.',
    ],
    fr: [
      'Délai de connexion dépassé',
      'L’adaptateur répond trop lentement. Rapprochez le téléphone et vérifiez la connexion, puis réessayez.',
    ],
  },
  [DIAG_ERRORS.NOT_CONNECTED]: {
    ar: ['المحول غير متصل', 'انقطع الاتصال بمحول OBD. أعد الاتصال ثم تابع الفحص.'],
    en: ['Adapter not connected', 'The OBD adapter disconnected. Reconnect and continue the scan.'],
    fr: [
      'Adaptateur non connecté',
      'L’adaptateur OBD s’est déconnecté. Reconnectez-le puis reprenez le diagnostic.',
    ],
  },
  [DIAG_ERRORS.DISCONNECTED]: {
    ar: ['انقطع الاتصال', 'فُقد الاتصال بالمحول أثناء العملية. أعد الاتصال وأعد الفحص.'],
    en: [
      'Connection lost',
      'The adapter connection was lost during the operation. Reconnect and scan again.',
    ],
    fr: [
      'Connexion perdue',
      'La connexion à l’adaptateur a été perdue pendant l’opération. Reconnectez et relancez.',
    ],
  },
};

const FALLBACK = {
  ar: ['حدث خطأ غير متوقع', 'أعد المحاولة. إذا استمرت المشكلة، افصل المحول ووصله من جديد.'],
  en: [
    'An unexpected error occurred',
    'Try again. If the problem persists, unplug the adapter and reconnect it.',
  ],
  fr: [
    'Une erreur inattendue s’est produite',
    'Réessayez. Si le problème persiste, débranchez puis rebranchez l’adaptateur.',
  ],
};

export function describeError(code, lang = 'ar') {
  const entry = M[code] || FALLBACK;
  const pair = entry[lang] || entry.en;
  return { title: pair[0], hint: pair[1] };
}
