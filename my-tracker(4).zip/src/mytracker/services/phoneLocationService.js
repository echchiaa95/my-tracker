/**
 * phoneLocationService — موقع صاحب السيارة من GPS الهاتف.
 * يعمل في المتصفح (navigator.geolocation) وداخل تطبيق Capacitor أندرويد
 * بنفس الواجهة، مع watch مستمر واشتراكات.
 */

let watcher = null;
let lastPosition = null; // { lat, lon, accuracy, ts }
const listeners = new Set();

function emit(position) {
  lastPosition = position;
  listeners.forEach((fn) => fn(position));
}

const phoneLocationService = {
  /** آخر موقع معروف للهاتف (أو null). */
  getLast() {
    return lastPosition;
  },

  subscribe(fn) {
    listeners.add(fn);
    if (lastPosition) fn(lastPosition);
    return () => listeners.delete(fn);
  },

  /** يطلب الموقع مرة واحدة. يُرجع { ok, position?, error? }. */
  async getOnce() {
    if (!('geolocation' in navigator)) return { ok: false, error: 'GPS غير مدعوم في هذا الجهاز' };
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const position = {
            lat: pos.coords.latitude,
            lon: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
            ts: Date.now(),
          };
          emit(position);
          resolve({ ok: true, position });
        },
        (err) => resolve({ ok: false, error: err.code === 1 ? 'رفضت إذن الموقع — فعّله من إعدادات المتصفح' : 'تعذر تحديد الموقع' }),
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 15000 },
      );
    });
  },

  /** مراقبة مستمرة (لصفحة "أين سيارتي" أثناء المشي نحو المركبة). */
  startWatch() {
    if (watcher != null || !('geolocation' in navigator)) return;
    watcher = navigator.geolocation.watchPosition(
      (pos) => emit({
        lat: pos.coords.latitude,
        lon: pos.coords.longitude,
        accuracy: pos.coords.accuracy,
        ts: Date.now(),
      }),
      () => {},
      { enableHighAccuracy: true, maximumAge: 5000 },
    );
  },

  stopWatch() {
    if (watcher != null) {
      navigator.geolocation.clearWatch(watcher);
      watcher = null;
    }
  },
};

export default phoneLocationService;
