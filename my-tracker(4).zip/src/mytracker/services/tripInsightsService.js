/**
 * tripInsightsService — ملخص الرحلات الذكي (عربي أولًا).
 * يجمع بيانات /api/reports/trips و /api/reports/summary من Traccar ويحوّلها
 * إلى ملخص نصي وبطاقات إحصائية مفهومة للمستخدم العادي:
 * "قطعت 45 كم في 3 رحلات، أطولها 22 كم، أعلى سرعة 110 كم/س".
 * لا يخزّن شيئًا — حساب فوري عند فتح الصفحة.
 */

import traccarService from './traccarService';

const METERS_PER_KM = 1000;
const KNOTS_TO_KMH = 1.852;

/** تحويل مسافة Traccar (متر) إلى كم مقروءة. */
export const kmFromMeters = (m) => (m || 0) / METERS_PER_KM;

/** سرعات Traccar تأتي بالعقدة (knots). */
export const kmhFromKnots = (kn) => (kn || 0) * KNOTS_TO_KMH;

function fmtKm(km) {
  if (km >= 100) return Math.round(km).toString();
  return (Math.round(km * 10) / 10).toString();
}

function fmtDuration(ms) {
  if (!ms || ms <= 0) return '0 د';
  const totalMin = Math.round(ms / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h && m) return `${h} س ${m} د`;
  if (h) return `${h} س`;
  return `${m} د`;
}

function fmtTime(iso) {
  try {
    return new Date(iso).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

/**
 * يبني ملخصًا ذكيًا من رحلات يوم/فترة واحدة لجهاز واحد.
 * @returns {{
 *   totals: { trips, distanceKm, driveMs, maxSpeedKmh, avgSpeedKmh, spentFuel },
 *   longest: object|null, fastest: object|null,
 *   lines: string[], trips: object[]
 * }}
 */
export function buildInsights(trips, summaryRow) {
  const list = Array.isArray(trips) ? trips : [];
  const totals = {
    trips: list.length,
    distanceKm: 0,
    driveMs: 0,
    maxSpeedKmh: 0,
    avgSpeedKmh: 0,
    spentFuel: summaryRow?.spentFuel || 0,
  };
  let longest = null;
  let fastest = null;
  let weightedSpeed = 0;

  list.forEach((trip) => {
    const dist = kmFromMeters(trip.distance);
    const dur = trip.duration || 0;
    totals.distanceKm += dist;
    totals.driveMs += dur;
    const maxKmh = kmhFromKnots(trip.maxSpeed);
    if (maxKmh > totals.maxSpeedKmh) totals.maxSpeedKmh = maxKmh;
    weightedSpeed += kmhFromKnots(trip.averageSpeed) * dist;
    if (!longest || dist > kmFromMeters(longest.distance)) longest = trip;
    if (!fastest || maxKmh > kmhFromKnots(fastest.maxSpeed)) fastest = trip;
  });

  if (totals.distanceKm > 0) {
    totals.avgSpeedKmh = weightedSpeed / totals.distanceKm;
  } else if (summaryRow) {
    // Traccar summary أدق أحيانًا (يشمل مسافات خارج الرحلات المكتشفة)
    totals.distanceKm = kmFromMeters(summaryRow.distance);
    totals.maxSpeedKmh = kmhFromKnots(summaryRow.maxSpeed);
    totals.avgSpeedKmh = kmhFromKnots(summaryRow.averageSpeed);
  }

  const lines = [];
  if (!list.length && !summaryRow) {
    lines.push('لا توجد رحلات مسجلة في هذه الفترة.');
  } else {
    lines.push(
      `قطعت ${fmtKm(totals.distanceKm)} كم في ${totals.trips} ${totals.trips === 1 ? 'رحلة' : 'رحلات'}` +
        (totals.driveMs ? ` بزمن قيادة إجمالي ${fmtDuration(totals.driveMs)}.` : '.'),
    );
    if (longest) {
      lines.push(
        `أطول رحلة: ${fmtKm(kmFromMeters(longest.distance))} كم` +
          ` (من ${fmtTime(longest.startTime)} إلى ${fmtTime(longest.endTime)}).`,
      );
    }
    if (totals.maxSpeedKmh > 0) {
      lines.push(
        `أعلى سرعة ${Math.round(totals.maxSpeedKmh)} كم/س` +
          `، ومتوسط السرعة ${Math.round(totals.avgSpeedKmh)} كم/س.`,
      );
    }
    if (totals.spentFuel > 0) {
      lines.push(`الوقود المستهلك: ${(Math.round(totals.spentFuel * 10) / 10).toString()} لتر.`);
    }
    // ملاحظة سياقية بسيطة
    if (totals.maxSpeedKmh >= 140) {
      lines.push('تنبيه: سُجّلت سرعة مرتفعة جدًا — قُد بحذر.');
    }
  }

  return { totals, longest, fastest, lines, trips: list };
}

/**
 * يجلب الرحلات والملخص لفترة زمنية ويبني الـInsights.
 * @returns {Promise<{ ok, error?, insights? }>}
 */
export async function fetchInsights(deviceId, fromDate, toDate) {
  const fromIso = new Date(fromDate).toISOString();
  const toIso = new Date(toDate).toISOString();
  const [tripsRes, summaryRes] = await Promise.all([
    traccarService.getTrips(deviceId, fromIso, toIso),
    traccarService.getSummary(deviceId, fromIso, toIso),
  ]);
  if (!tripsRes.ok) return { ok: false, error: tripsRes.error };
  const summaryRow = summaryRes.ok && summaryRes.summary?.length ? summaryRes.summary[0] : null;
  return { ok: true, insights: buildInsights(tripsRes.trips, summaryRow) };
}
