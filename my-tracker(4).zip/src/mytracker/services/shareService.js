/**
 * shareService — مشاركة الموقع الحي (الميزة 3).
 * يبني روابط خرائط جاهزة (Google Maps / WhatsApp) من آخر موقع معروف،
 * ويستخدم Web Share API عند توفرها، مع Capacitor Share على أندرويد،
 * والنسخ إلى الحافظة كحل أخير.
 */

/** رابط Google Maps من إحداثيات. */
export const mapsLink = (lat, lon) =>
  `https://www.google.com/maps?q=${lat},${lon}`;

/** رابط واتساب يفتح محادثة جاهزة بنص الموقع. */
export const whatsappLink = (text) =>
  `https://wa.me/?text=${encodeURIComponent(text)}`;

/**
 * يشارك نصًا/رابطًا بأفضل وسيلة متاحة.
 * @returns {Promise<'native'|'capacitor'|'clipboard'|'whatsapp'>}
 */
export async function shareText({ title, text, url }) {
  if (navigator.share) {
    await navigator.share({ title, text, url });
    return 'native';
  }
  try {
    // Capacitor Share (تطبيق أندرويد) — الحزمة موجودة في package.json
    const { Share } = await import('@capacitor/share');
    const can = await Share.canShare();
    if (can.value) {
      await Share.share({ title, text, url, dialogTitle: title });
      return 'capacitor';
    }
  } catch {
    // لسنا داخل Capacitor — نكمل للحلول التالية
  }
  try {
    await navigator.clipboard.writeText(url || text);
    return 'clipboard';
  } catch {
    window.open(whatsappLink(`${text} ${url || ''}`), '_blank', 'noopener');
    return 'whatsapp';
  }
}

/** يبني رسالة مشاركة موقع مركبة. */
export function buildShareMessage({ deviceName, position }) {
  const lat = position?.latitude;
  const lon = position?.longitude;
  const link = lat != null && lon != null ? mapsLink(lat, lon) : '';
  const time = position?.fixTime
    ? new Date(position.fixTime).toLocaleString('ar')
    : new Date().toLocaleString('ar');
  return {
    title: `موقع ${deviceName}`,
    text: `موقع ${deviceName} الآن (${time}):`,
    url: link,
    link,
  };
}
