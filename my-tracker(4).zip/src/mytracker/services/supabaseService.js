/**
 * supabaseService — اختياري بالكامل. لا يُستخدم أبدًا لبيانات GPS الحية
 * (Traccar هو المصدر الوحيد لذلك عبر traccarService). دوره الوحيد:
 * نسخ احتياطي/مزامنة settings + vehicles + preferences المحلية.
 *
 * التطبيق يعمل بشكل طبيعي بدون أي إعداد لـSupabase — هذا الملف لا يُستدعى
 * تلقائيًا من أي مكان، ويُفعَّل فقط إذا زوّد المستخدم VITE_SUPABASE_URL و
 * VITE_SUPABASE_ANON_KEY (متغيرات بيئة Public/Anon فقط — لا يوجد أي
 * service role key هنا، مطابقة لمتطلب الأمان #28).
 */

import storageService from './storageService';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

let clientPromise = null;

function getClient() {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) return null;
  if (!clientPromise) {
    clientPromise = import('@supabase/supabase-js').then(({ createClient }) =>
      createClient(SUPABASE_URL, SUPABASE_ANON_KEY),
    );
  }
  return clientPromise;
}

const supabaseService = {
  isEnabled() {
    return Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);
  },

  /** رفع نسخة من الإعدادات/السيارات/التفضيلات فقط، تحت معرّف مستخدم Traccar. */
  async backup(userId) {
    const client = await getClient();
    if (!client) return { ok: false, error: 'Supabase not configured' };
    const { settings, vehicles } = storageService.getState();
    const { error } = await client.from('mytracker_backups').upsert({
      user_id: String(userId),
      settings,
      vehicles,
      updated_at: new Date().toISOString(),
    });
    return error ? { ok: false, error: error.message } : { ok: true };
  },

  async restore(userId) {
    const client = await getClient();
    if (!client) return { ok: false, error: 'Supabase not configured' };
    const { data, error } = await client
      .from('mytracker_backups')
      .select('settings, vehicles')
      .eq('user_id', String(userId))
      .maybeSingle();
    if (error) return { ok: false, error: error.message };
    if (!data) return { ok: false, error: 'No backup found' };
    storageService.update('settings', data.settings || {});
    storageService.update('vehicles', data.vehicles || {});
    return { ok: true };
  },
};

export default supabaseService;
