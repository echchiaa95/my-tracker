/**
 * offlineMapService — خرائط دون اتصال عبر PMTiles (الميزة 4).
 * حزمتا maplibre-gl وpmtiles موجودتان أصلًا في المشروع؛ هذه الخدمة:
 *   1) تسجّل بروتوكول pmtiles:// في maplibre (مرة واحدة).
 *   2) تبني Style JSON كاملًا (vector) من ملف PMTiles يحدده المستخدم في
 *      الإعدادات (رابط https:// أو ملف محلي مرفوع عبر HTTP داخلي).
 * يعمل الملف المحفوظ محليًا على جهاز المستخدم (أو المستضاف على سيرفره)
 * بدون أي اتصال بخوادم خرائط خارجية.
 */

import maplibregl from 'maplibre-gl';
import { Protocol } from 'pmtiles';
import storageService from './storageService';

let protocolRegistered = false;
const protocol = new Protocol();

/** تسجيل بروتوكول pmtiles:// — آمن للاستدعاء المتكرر. */
export function registerPmtilesProtocol() {
  if (protocolRegistered) return;
  try {
    maplibregl.addProtocol('pmtiles', (params, callback) => {
      protocol.tile(params, callback);
      return { cancel: () => {} };
    });
    protocolRegistered = true;
  } catch {
    // نسخة maplibre قد لا تدعم addProtocol بعد — نتجاهل ونبقي الخيار مخفيًا
  }
}

/** رابط PMTiles الحالي من إعدادات التطبيق. */
export function getPmtilesUrl() {
  return storageService.getState().settings?.pmtilesUrl || '';
}

/** هل الخرائط دون اتصال مُهيَّأة؟ */
export function isOfflineMapConfigured() {
  return Boolean(getPmtilesUrl()) && protocolRegistered;
}

/**
 * يبني Style JSON لخريطة vector كاملة المصدر من PMTiles.
 * التصميم بسيط (خلفية + ماء + طرق + مبانٍ) — يكفي للتتبع دون اتصال.
 */
export function buildPmtilesStyle(url) {
  const source = `pmtiles://${url}`;
  return {
    version: 8,
    glyphs: 'https://cdn.traccar.com/map/fonts/{fontstack}/{range}.pbf',
    sources: {
      offline: {
        type: 'vector',
        url: source,
      },
    },
    layers: [
      { id: 'background', type: 'background', paint: { 'background-color': '#e8eef2' } },
      {
        id: 'water',
        type: 'fill',
        source: 'offline',
        'source-layer': 'water',
        paint: { 'fill-color': '#b3d1e8' },
      },
      {
        id: 'landuse',
        type: 'fill',
        source: 'offline',
        'source-layer': 'landuse',
        paint: { 'fill-color': '#dce8d5', 'fill-opacity': 0.6 },
      },
      {
        id: 'buildings',
        type: 'fill',
        source: 'offline',
        'source-layer': 'buildings',
        paint: { 'fill-color': '#d6d3cd' },
      },
      {
        id: 'roads',
        type: 'line',
        source: 'offline',
        'source-layer': 'roads',
        paint: { 'line-color': '#ffffff', 'line-width': ['interpolate', ['linear'], ['zoom'], 5, 1, 16, 5] },
      },
    ],
  };
}

export default { registerPmtilesProtocol, getPmtilesUrl, isOfflineMapConfigured, buildPmtilesStyle };
