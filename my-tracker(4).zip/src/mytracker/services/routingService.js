/**
 * routingService — أقرب مسار من موقع الهاتف إلى السيارة.
 * يستخدم خادم OSRM العام للملاحة بالسيارة/مشيًا؛ عند غياب الاتصال أو فشل
 * الخدمة يرجع خطًا مستقيمًا (fallback) حتى لا تتعطل الميزة.
 * الملاحة الفعلية (صوت/منعطفات) تفتح في Google Maps عبر رابط dir.
 */

const OSRM_BASE = 'https://router.project-osrm.org/route/v1';

/**
 * @param {{lat:number, lon:number}} from — موقع الهاتف
 * @param {{lat:number, lon:number}} to — موقع السيارة
 * @param {'driving'|'walking'} profile
 * @returns {Promise<{ ok, coords?: [lon,lat][], distanceKm?: number,
 *   durationMin?: number, fallback?: boolean, error?: string }>}
 */
export async function findRoute(from, to, profile = 'driving') {
  try {
    const url = `${OSRM_BASE}/${profile}/${from.lon},${from.lat};${to.lon},${to.lat}?overview=full&geometries=geojson`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const route = data?.routes?.[0];
    if (!route) throw new Error('no route');
    return {
      ok: true,
      coords: route.geometry.coordinates,
      distanceKm: route.distance / 1000,
      durationMin: route.duration / 60,
      fallback: false,
    };
  } catch {
    // بدون اتصال: خط مستقيم + مسافة هافرساين
    const R = 6371;
    const dLat = ((to.lat - from.lat) * Math.PI) / 180;
    const dLon = ((to.lon - from.lon) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos((from.lat * Math.PI) / 180) *
        Math.cos((to.lat * Math.PI) / 180) *
        Math.sin(dLon / 2) ** 2;
    const distanceKm = 2 * R * Math.asin(Math.sqrt(a));
    return {
      ok: true,
      coords: [
        [from.lon, from.lat],
        [to.lon, to.lat],
      ],
      distanceKm,
      durationMin: (distanceKm / 40) * 60, // تقدير تقريبي بسرعة 40 كم/س
      fallback: true,
    };
  }
}

/** رابط ملاحة Google Maps من موقع الهاتف إلى السيارة (يفتح التطبيق مباشرة). */
export const googleNavLink = (to, profile = 'driving') =>
  `https://www.google.com/maps/dir/?api=1&destination=${to.lat},${to.lon}&travelmode=${profile}`;
