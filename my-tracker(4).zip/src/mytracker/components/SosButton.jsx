import { useState } from 'react';
import { useSelector } from 'react-redux';
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Fab,
  MenuItem,
  Snackbar,
  TextField,
  Typography,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import SosIcon from '@mui/icons-material/Sos';
import { buildShareMessage, shareText } from '../services/shareService';

const useStyles = makeStyles()((theme) => ({
  fab: {
    position: 'fixed',
    bottom: 'calc(72px + env(safe-area-inset-bottom))',
    insetInlineEnd: theme.spacing(2),
    zIndex: 1200,
  },
}));

/**
 * SosButton — زر طوارئ عائم: يشارك الموقع الحالي لأي مركبة فورًا
 * (Web Share / Capacitor / نسخ الرابط / واتساب) مع تأكيد قبل الإرسال
 * لمنع الضغط الخاطئ.
 */
const SosButton = () => {
  const { classes } = useStyles();
  const devices = useSelector((state) => Object.values(state.devices.items));
  const positions = useSelector((state) => state.session.positions);
  const [open, setOpen] = useState(false);
  const [deviceId, setDeviceId] = useState('');
  const [toast, setToast] = useState('');

  const handleSend = async () => {
    const id = Number(deviceId || devices[0]?.id);
    const device = devices.find((d) => d.id === id);
    const position = positions[id];
    if (!device || !position) {
      setToast('لا يوجد موقع حديث لهذه المركبة بعد');
      setOpen(false);
      return;
    }
    const msg = buildShareMessage({ deviceName: device.name, position });
    try {
      const method = await shareText(msg);
      setToast(
        method === 'clipboard'
          ? 'تم نسخ رابط الموقع — الصقه في أي تطبيق'
          : 'تمت مشاركة الموقع بنجاح',
      );
    } catch {
      setToast('أُلغيت المشاركة');
    }
    setOpen(false);
  };

  if (!devices.length) return null;

  return (
    <>
      <Fab
        color="error"
        className={classes.fab}
        onClick={() => {
          setDeviceId(String(devices[0]?.id || ''));
          setOpen(true);
        }}
        aria-label="SOS مشاركة الموقع"
      >
        <SosIcon />
      </Fab>

      <Dialog open={open} onClose={() => setOpen(false)} fullWidth maxWidth="xs">
        <DialogTitle>مشاركة الموقع الآن؟</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" mb={2}>
            سيتم مشاركة آخر موقع معروف للمركبة مع رابط خريطة مباشر.
          </Typography>
          <TextField
            select
            fullWidth
            label="المركبة"
            value={deviceId}
            onChange={(e) => setDeviceId(e.target.value)}
          >
            {devices.map((d) => (
              <MenuItem key={d.id} value={String(d.id)}>{d.name}</MenuItem>
            ))}
          </TextField>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>إلغاء</Button>
          <Button onClick={handleSend} variant="contained" color="error">
            مشاركة الموقع
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={Boolean(toast)}
        autoHideDuration={3000}
        onClose={() => setToast('')}
        message={toast}
      />
      <Box />
    </>
  );
};

export default SosButton;
