import { Box, ButtonBase, Typography } from '@mui/material';
import BackspaceIcon from '@mui/icons-material/BackspaceOutlined';
import { makeStyles } from 'tss-react/mui';

const useStyles = makeStyles()((theme) => ({
  dots: {
    display: 'flex',
    justifyContent: 'center',
    gap: theme.spacing(2),
    marginBottom: theme.spacing(4),
  },
  dot: {
    width: 16,
    height: 16,
    borderRadius: '50%',
    border: `2px solid ${theme.palette.primary.main}`,
  },
  dotFilled: {
    backgroundColor: theme.palette.primary.main,
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, 1fr)',
    gap: theme.spacing(2),
    maxWidth: 280,
    margin: '0 auto',
  },
  key: {
    height: 64,
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 24,
    fontWeight: 500,
  },
  empty: {
    visibility: 'hidden',
  },
}));

/** لوحة أرقام لإدخال PIN من 4 أرقام. مكوّن عرض فقط، بدون منطق تخزين. */
const PinKeypad = ({ value, onChange, length = 4, error }) => {
  const { classes, cx } = useStyles();

  const handleDigit = (digit) => {
    if (value.length >= length) return;
    onChange(value + digit);
  };

  const handleBackspace = () => {
    onChange(value.slice(0, -1));
  };

  return (
    <Box>
      <Box className={classes.dots}>
        {Array.from({ length }).map((_, i) => (
          <Box
            key={i}
            className={cx(classes.dot, i < value.length && classes.dotFilled)}
            sx={error ? { borderColor: 'error.main' } : undefined}
          />
        ))}
      </Box>
      <Box className={classes.grid}>
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
          <ButtonBase
            key={digit}
            className={classes.key}
            onClick={() => handleDigit(String(digit))}
          >
            <Typography variant="h6">{digit}</Typography>
          </ButtonBase>
        ))}
        <Box className={classes.empty} />
        <ButtonBase className={classes.key} onClick={() => handleDigit('0')}>
          <Typography variant="h6">0</Typography>
        </ButtonBase>
        <ButtonBase className={classes.key} onClick={handleBackspace}>
          <BackspaceIcon />
        </ButtonBase>
      </Box>
    </Box>
  );
};

export default PinKeypad;
