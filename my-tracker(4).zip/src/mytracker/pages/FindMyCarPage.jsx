import { useEffect, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import {
  Alert,
  AppBar,
  Box,
  Button,
  Card,
  CardContent,
  Container,
  IconButton,
  MenuItem,
  Stack,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Toolbar,
  Typography,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import MyLocationIcon from '@mui/icons-material/MyLocation';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import NavigationIcon from '@mui/icons-material/Navigation';
import phoneLocationService from '../services/phoneLocationService';
import { findRoute, googleNavLink } from '../services/routingService';

const OSM_STYLE = {
  version: 8,
  glyphs: 'https://cdn.traccar.com/map/fonts/{fontstack}/{range}.pbf',
  sources: {
    osm: {
      type: 'raster',
      tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
      tileSize: 256,
      maxzoom: 19,
      attribution: '© OpenStreetMap contributors',
    },
  },
  layers: [{ id: 'osm', type: 'raster', source: 'osm' }],
};

const ROUTE_SOURCE = 'find-car-route';

/**
 * FindMyCarPage — "أين سيارتي؟": يعرض موقعك من GPS الهاتف وموقع السيارة
 * على خريطة واحدة، يرسم أقرب مسار (OSRM، مع خط مستقيم كبديل دون اتصال)،
 * ويوفر زر ملاحة يفتح Google Maps مباشرة.
 */
const FindMyCarPage = () => {
  const navigate = useNavigate();
  const devices = useSelector((state) => Object.values(state.devices.items));
  const positions = useSelector((state) => state.session.positions);

  const mapContainer = useRef(null);
  const mapRef = useRef(null);
  const phoneMarkerRef = useRef(null);
  const carMarkerRef = useRef(null);

  const [deviceId, setDeviceId] = useState('');
  const [profile, setProfile] = useState('driving');
  const [phone, setPhone] = useState(phoneLocationService.getLast());
  const [routeInfo, setRouteInfo] = useState(null);
  const [error, setError] = useState(null);
  const [locating, setLocating] = useState(false);

  useEffect(() => {
    if (!deviceId && devices.length) setDeviceId(String(devices[0].id));
  }, [devices, deviceId]);

  // تهيئة الخريطة مرة واحدة
  useEffect(() => {
    const map = new maplibregl.Map({
      container: mapContainer.current,
      style: OSM_STYLE,
      center: [10.18, 36.8],
      zoom: 12,
      attributionControl: { compact: true },
    });
    map.addControl(new maplibregl.NavigationControl({ visualizePitch: true }), 'top-right');
    map.on('load', () => {
      map.addSource(ROUTE_SOURCE, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] },
      });
      map.addLayer({
        id: ROUTE_SOURCE,
        type: 'line',
        source: ROUTE_SOURCE,
        paint: {
          'line-color': '#2196f3',
          'line-width': 5,
          'line-opacity': 0.85,
        },
      });
    });
    mapRef.current = map;
    return () => map.remove();
  }, []);

  // اشتراك موقع الهاتف المستمر
  useEffect(() => {
    phoneLocationService.startWatch();
    const unsub = phoneLocationService.subscribe(setPhone);
    return () => {
      unsub();
      phoneLocationService.stopWatch();
    };
  }, []);

  const carPosition = positions[Number(deviceId)] || null;

  const drawMarker = (ref, lngLat, color, label) => {
    const map = mapRef.current;
    if (!map || !lngLat) return;
    if (ref.current) ref.current.remove();
    const el = document.createElement('div');
    el.style.cssText = `background:${color};color:#fff;border-radius:50% 50% 50% 0;transform:rotate(-45deg);width:30px;height:30px;display:flex;align-items:center;justify-content:center;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.4);`;
    const span = document.createElement('span');
    span.style.cssText = 'transform:rotate(45deg);font-size:13px;font-weight:800;';
    span.textContent = label;
    el.appendChild(span);
    ref.current = new maplibregl.Marker({ element: el }).setLngLat(lngLat).addTo(map);
  };

  // تحديث العلامات والمسار عند تغير المواقع
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    drawMarker(phoneMarkerRef, phone ? [phone.lon, phone.lat] : null, '#00c853', 'أنا');
    drawMarker(
      carMarkerRef,
      carPosition ? [carPosition.longitude, carPosition.latitude] : null,
      '#e53935',
      '🚗',
    );

    if (!phone || !carPosition) return;

    (async () => {
      const to = { lat: carPosition.latitude, lon: carPosition.longitude };
      const result = await findRoute({ lat: phone.lat, lon: phone.lon }, to, profile);
      if (!result.ok) {
        setError('تعذر حساب المسار');
        return;
      }
      setRouteInfo(result);
      const draw = () => {
        map.getSource(ROUTE_SOURCE)?.setData({
          type: 'Feature',
          geometry: { type: 'LineString', coordinates: result.coords },
          properties: {},
        });
      };
      if (map.isStyleLoaded()) draw();
      else map.once('load', draw);
      const bounds = result.coords.reduce(
        (b, c) => b.extend(c),
        new maplibregl.LngLatBounds(result.coords[0], result.coords[0]),
      );
      map.fitBounds(bounds, { padding: 80, maxZoom: 16 });
    })();
  }, [phone, carPosition, profile]);

  const locateMe = async () => {
    setLocating(true);
    setError(null);
    const result = await phoneLocationService.getOnce();
    setLocating(false);
    if (!result.ok) setError(result.error);
    else if (mapRef.current) {
      mapRef.current.flyTo({ center: [result.position.lon, result.position.lat], zoom: 15 });
    }
  };

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <AppBar position="static" color="default" elevation={1}>
        <Toolbar>
          <IconButton edge="start" onClick={() => navigate(-1)}>
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h6" sx={{ ml: 1 }}>
            أين سيارتي؟
          </Typography>
        </Toolbar>
      </AppBar>

      <Box ref={mapContainer} sx={{ flex: 1, minHeight: 0 }} />

      <Container maxWidth="sm" sx={{ py: 2 }}>
        {error && (
          <Alert severity="warning" sx={{ mb: 1.5 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}
        {routeInfo?.fallback && (
          <Alert severity="info" sx={{ mb: 1.5 }}>
            لا يوجد اتصال — يُعرض خط مستقيم تقريبي بدل مسار الطرق.
          </Alert>
        )}

        <Stack direction="row" spacing={1.5} mb={1.5}>
          <TextField
            select
            label="السيارة"
            value={deviceId}
            onChange={(e) => setDeviceId(e.target.value)}
            fullWidth
            size="small"
          >
            {devices.map((d) => (
              <MenuItem key={d.id} value={String(d.id)}>{d.name}</MenuItem>
            ))}
          </TextField>
          <ToggleButtonGroup
            exclusive
            size="small"
            value={profile}
            onChange={(_, v) => v && setProfile(v)}
          >
            <ToggleButton value="driving">سيارة</ToggleButton>
            <ToggleButton value="walking">مشي</ToggleButton>
          </ToggleButtonGroup>
        </Stack>

        {routeInfo && (
          <Card sx={{ mb: 1.5 }}>
            <CardContent sx={{ py: 1.5, '&:last-child': { pb: 1.5 } }}>
              <Typography fontWeight={800}>
                {`المسافة إلى سيارتك: ${routeInfo.distanceKm < 1
                  ? `${Math.round(routeInfo.distanceKm * 1000)} متر`
                  : `${routeInfo.distanceKm.toFixed(1)} كم`} · حوالي ${Math.max(1, Math.round(routeInfo.durationMin))} دقيقة`}
              </Typography>
              {!phone && (
                <Typography variant="body2" color="text.secondary">
                  اضغط «حدد موقعي» لعرض موقعك وحساب المسار.
                </Typography>
              )}
            </CardContent>
          </Card>
        )}

        <Stack direction="row" spacing={1.5}>
          <Button
            variant="outlined"
            startIcon={<MyLocationIcon />}
            onClick={locateMe}
            disabled={locating}
            fullWidth
          >
            {locating ? 'جارٍ التحديد…' : 'حدد موقعي'}
          </Button>
          <Button
            variant="contained"
            color="primary"
            startIcon={<NavigationIcon />}
            disabled={!carPosition}
            fullWidth
            onClick={() =>
              window.open(
                googleNavLink(
                  { lat: carPosition.latitude, lon: carPosition.longitude },
                  profile,
                ),
                '_blank',
                'noopener',
              )
            }
          >
            ابدأ الملاحة
          </Button>
        </Stack>
        {!carPosition && (
          <Typography variant="body2" color="text.secondary" mt={1} textAlign="center">
            <DirectionsCarIcon fontSize="small" sx={{ verticalAlign: 'middle' }} /> لا يوجد موقع
            حديث لهذه السيارة بعد — انتظر وصول إشارة من جهاز التتبع.
          </Typography>
        )}
      </Container>
    </Box>
  );
};

export default FindMyCarPage;
