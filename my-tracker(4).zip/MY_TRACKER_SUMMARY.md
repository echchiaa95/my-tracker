# My Tracker — ملخص كامل للمشروع والإصلاحات

آخر تحديث: بعد إصلاح خلل الـForm المتداخل (Full Page Reload عند تسجيل الدخول).

---

## 1. الفكرة والهدف

تطبيق شخصي خفيف لتتبع السيارات، مبني كفرع مستقل (`my-tracker`) من مشروع
**traccar-web** الرسمي (React + Vite + Redux + MUI + MapLibre)، دون المساس
بالنسخة الأصلية الكاملة. الهدف:

- PIN من 4 أرقام كقفل محلي للتطبيق.
- تخزين محلي (localStorage) للإعدادات وأسماء السيارات.
- طبقة `TraccarService` معزولة تتولى كل الاتصال بسيرفر Traccar.
- نشر على GitHub Pages: `https://echchiaa95.github.io/my-tracker/`
- الاتصال بسيرفر Traccar شخصي: `https://traccar.elbordiji.com`
- Traccar يبقى Backend غير مرئي للمستخدم بالكامل (لا حقل Server URL).

---

## 2. البنية الحالية

```
UI (غير مُعدَّل من الأصل، محمي):
  Dashboard, Vehicles, Live Map (MapLibre), Bottom Sheet, Bottom Navigation

UI (جديد، My Tracker فقط):
  MyTrackerRoot        — نقطة الدخول، المصدر الوحيد لحالة المصادقة
  MyTrackerLoginPage   — شاشة الدخول (بريد/كلمة مرور فقط)
  PinSetupPage / PinLockPage
  MyTrackerSettingsPage — /mytracker-settings

Services (جديدة، معزولة):
  traccarService.js  — REST + WebSocket + Polling fallback
  storageService.js  — localStorage (settings/vehicles/traccar/pin)
  pinService.js      — قفل PIN محلي (ليس تشفيرًا حقيقيًا)
  supabaseService.js — نسخ احتياطي اختياري فقط، لا يُستخدم لبيانات GPS

Bridge:
  TraccarReduxBridge — يغذّي Redux الأصلي (devices/positions) من
                       traccarService دون حذف Redux
```

---

## 3. سلسلة الأخطاء التي تم اكتشافها وإصلاحها (بالترتيب الزمني)

| # | الخطأ | الملف | الحل |
|---|-------|-------|------|
| 1 | `TraccarReduxBridge` لا يبدأ الاتصال الحي ولا يجلب البيانات أول مرة | `TraccarReduxBridge.jsx` | إضافة جلب أولي (`getDevices`/`getPositions`) ثم `startLive()` |
| 2 | `state.session.socket` لا يُحدَّث بعد تعطيل `SocketController` الأصلي | `TraccarReduxBridge.jsx` | ربط حدث `status` بـ`sessionActions.updateSocket` |
| 3 | مسارات `/api/...` نسبية في عدة ملفات (تذهب لدومين GitHub Pages بدل Traccar) | `fetchOrThrow.js`, `ServerProvider.jsx`, `App.jsx`, `PreferencesPage.jsx`, `Navigation.jsx` | إلحاق `traccarService.baseUrl` تلقائيًا + `credentials:'include'` |
| 4 | `BrowserRouter` بلا `basename` — يكسر التنقل تحت مسار GitHub Pages الفرعي | `index.jsx` | `basename={import.meta.env.BASE_URL}` |
| 5 | **نظام مصادقة موازٍ ومتنافس**: `App.jsx` الأصلي يستدعي `navigate('/login')` إن كان `user` فارغًا مؤقتًا | `App.jsx` | حذف الكتلة بالكامل — `MyTrackerRoot` أصبح المصدر الوحيد |
| 6 | `response.json()` خارج `try/catch` في `login()` — استثناء صامت يوقف التنفيذ بلا أي رسالة | `traccarService.js` | نقل التحليل داخل `try/catch` مع رسالة خطأ واضحة |
| 7 | `fetchSession()` تُعامل `404` (بعض نسخ Traccar تُرجعه بدل 401) كخطأ اتصال حقيقي | `traccarService.js` | معاملة `404` بنفس معاملة `401` تمامًا (لا توجد جلسة، حالة طبيعية) |
| 8 | **Full Page Reload عند الضغط على "تسجيل الدخول"** — السبب الجذري النهائي: `<Box component="form" onSubmit=...>` **متداخل داخل** `<form>` آخر ينتمي إلى `LoginLayout.jsx` نفسه (HTML غير صالح) → المتصفح يُرسِل الـform الخارجي الذي لا يملك `onSubmit` → إرسال تقليدي → إعادة تحميل كاملة | `MyTrackerLoginPage.jsx` | إزالة الـform الداخلي بالكامل، واستخدام `<Button onClick={...}>` عادي (type="button")، بنفس النمط المُثبَت فعليًا في `LoginPage.jsx` الأصلي لنفس المشروع |

---

## 4. أدوات التشخيص المضافة (مؤقتة، قابلة للإزالة لاحقًا)

- `src/mytracker/debugLog.js`: سجلّ مشترك بسيط.
- صندوق **Debug مرئي** أسفل زر تسجيل الدخول في `MyTrackerLoginPage.jsx`،
  يعرض 10 مراحل مرقّمة (بدء الدخول → POST → status → GET → status →
  user → onAuthenticated → authStatus → الانتقال)، بالإضافة لأي خطأ كامل
  النص دون اختصار.
- رسالة **"FORCED LOGOUT / UNAUTHENTICATED"** تلقائية (مع الملف/السبب/الحالة
  السابقة) في أي مرة تعود فيها الحالة الفعلية من `authenticated` إلى غير
  ذلك — لا تظهر خطأً في التدفق الطبيعي الأول.
- كاشف `AUTH: PAGE LOAD` في `MyTrackerRoot.jsx` يطبع نوع التنقل الفعلي
  (`performance.getEntriesByType('navigation')`) — يُستخدم لتأكيد ما إذا
  حدثت إعادة تحميل فعلية للصفحة أم لا.

**التوصية**: إبقاء الصندوق حتى يُؤكَّد أن تسلسل المصادقة الكامل (Login →
Dashboard → Refresh → Logout) يعمل بثبات على جهاز حقيقي، ثم إزالته أو إخفاءه
خلف علم تفعيل.

---

## 5. البنية التقنية للمصادقة الحالية

```
authStatus: 'checking' | 'unauthenticated' | 'authenticated'
pinLock (فرعي، بعد authenticated فقط): 'setup' | 'locked' | 'open'
```

- **مصدر واحد فقط** للحقيقة: `MyTrackerRoot.jsx` (مؤكَّد ببحث شامل في
  المشروع — لا يوجد أي ملف آخر يستدعي `setAuthStatus`).
- Traccar backend غير مرئي بالكامل: لا حقل Server URL في أي شاشة، الرابط
  يأتي حصرًا من `VITE_TRACCAR_URL` في `.env`.
- كل الطلبات (`login`, `fetchSession`, `logout`, `getDevices`,
  `getPositions`) تستخدم `credentials: 'include'` حصرًا.
- WebSocket (`wss://`) والـPolling الاحتياطي محفوظان كما كانا.

---

## 6. ما لم يُختبَر فعليًا بعد (قيد بيئي دائم)

بيئة التنفيذ هنا بلا وصول لسجل npm (403 على كل الحزم)، لذلك **لم يُشغَّل
`npm run build` فعليًا ولا مرة واحدة طوال هذا المشروع**. كل التحقق تم عبر:

- `tsc --noEmit` (فحص Syntax حقيقي) على كل ملف مُعدَّل.
- تحقق برمجي أن كل `import` نسبي يُحل لملف موجود فعليًا.

**البناء الفعلي يحدث فقط عبر GitHub Actions** (`deploy-pages.yml`) عند رفع
الـzip — وهذا هو الاختبار الحقيقي الوحيد المتاح حاليًا.

---

## 7. خطوات النشر (بلا تغيير)

1. ارفع `my-tracker.zip` (بنفس الاسم) إلى الريبو → Commit.
2. تبويب Actions → انتظار ✅ على build ثم deploy.
3. فتح `https://echchiaa95.github.io/my-tracker/`.
4. اختبار: فتح التطبيق → شاشة Login تظهر مباشرة بلا أي خطأ → إدخال
   البيانات → الضغط على "تسجيل الدخول" → **لا يجب أن تحدث أي إعادة تحميل
   للصفحة الآن** → متابعة قراءة صندوق Debug حتى `[10]`.

---

## 8. ملفات المشروع المتعلقة بهذا التقرير

- `.github/workflows/deploy-pages.yml` — بناء ونشر تلقائي من الـzip.
- `TRACCAR_SERVER_CORS_SETUP.md` — متطلبات CORS/كوكيز على سيرفر Traccar (مؤكَّدة سابقًا كمُهيَّأة بشكل صحيح من طرف المستخدم).
- `DEPLOY_GITHUB.md` — دليل النشر خطوة بخطوة من الهاتف.

---

## 9. تحديث: تنظيف Debug + إعادة تصميم Login السينمائي + إصلاح خطأ Build

بعد تأكيد المستخدم أن تسجيل الدخول أصبح يعمل ("شغالة")، تم تنفيذ ما يلي بالترتيب:

### 9.1 إزالة كامل أدوات التشخيص المؤقتة
- حذف `src/mytracker/debugLog.js` نهائيًا.
- إزالة صندوق Debug المرئي والمراحل `[1]`-`[10]` من `MyTrackerLoginPage.jsx`.
- إزالة رسائل `FORCED LOGOUT`, `AUTH: PAGE LOAD` وكل استدعاءات `debugLog`/`console.log` التشخيصية من `MyTrackerRoot.jsx` و`traccarService.js`.
- **لم تُحذف** الإصلاحات الوظيفية الحقيقية المكتشفة أثناء التحقيق: `try/catch` حول `response.json()`، ومعاملة `404` كمعاملة `401` (لا توجد جلسة، حالة طبيعية) — هذه بقيت كما هي.
- تنظيف import يتيم واحد (`storageService` في `MyTrackerRoot.jsx`).

### 9.2 إعادة تصميم `MyTrackerLoginPage.jsx` (سينمائي/Premium/Dark)
- تصميم مستقل بالكامل (لا يُعيد استخدام `LoginLayout.jsx` المشترك) — **بلا أي `<form>` إطلاقًا** في الملف، لإقصاء أي احتمال لعودة مشكلة الـform المتداخل (Full Page Reload) نهائيًا. الزر `type="button"` + `onClick` فقط.
- خلفية سينمائية CSS بحتة (Grid بنمط HUD/خرائط، مسار GPS متوهج بـSVG متحرك، نقاط نبض)، في طبقة `position:fixed` منفصلة عن تدفق الصفحة حتى تبقى قابلة للتمرير (لا يختفي الزر خلف لوحة مفاتيح الهاتف).
- بطاقة زجاجية (`backdrop-filter: blur`) بألوان navy/أزرق كهربائي/سماوي، مع لمسة برتقالية خفيفة واحدة فقط.
- علامة "MY TRACKER" + "Track. Control. Protect."، خط Space Grotesk.
- Animations خفيفة تحترم `prefers-reduced-motion`.

### 9.3 إصلاح خطأ Build حقيقي في GitHub Actions
**الخطأ**: `Rolldown failed to resolve import "@mui/icons-material/MailOutline"` (وكذلك `LockOutlined` و`NearMe`) — ثلاثة أيقونات جديدة أُضيفت أثناء التصميم السينمائي في 9.2.

**السبب**: `@mui/icons-material` موجودة فعليًا في `package.json`/`package-lock.json` وتُستخدم بنجاح في نفس المشروع بنفس نمط الاستيراد الفرعي (مثل `PersonIcon` من `.../Person` في `BottomMenu.jsx`) — لكن هذه الأسماء الثلاثة تحديدًا فشل حلّها في بيئة البناء الفعلية (Rolldown)، دون إمكانية التحقق من السبب الدقيق محليًا (لا وصول شبكي لفحص محتوى الحزمة المثبَّتة فعليًا).

**الحل المطبَّق** (الخيار الاحتياطي المطلوب صراحةً): استبدال الأيقونات الثلاث بأيقونات محلية عبر `SvgIcon` من `@mui/material` (المكتبة الأساسية المستخدمة في كل مكان بلا أي مشكلة) مع مسارات SVG بسيطة مرسومة يدويًا، في ملف جديد:
- `src/mytracker/components/MyTrackerIcons.jsx` (يصدّر `MailIcon`, `LockIcon`, `LocationPinIcon`).

**لم يُعدَّل**: `vite.config.js`، لا `external` workaround، لا تغيير في Auth logic/`traccarService.js`/`MyTrackerRoot` logic/Redux/WebSocket/PIN flow/`LoginLayout.jsx`. أيقونات أخرى موجودة مسبقًا وغير مرتبطة بهذا التصميم (`BackspaceOutlined` في `PinKeypad.jsx`، `ArrowBack` في `MyTrackerSettingsPage.jsx`) لم تُلمس لأنها لم تُبلَّغ كمعطوبة وسابقة لهذا التصميم.

