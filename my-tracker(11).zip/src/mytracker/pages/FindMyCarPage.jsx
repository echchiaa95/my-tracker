import { useEffect, useRef, useState, useCallback } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import {
  Alert,
  AppBar,
  Box,
  Button,
  Card,
  CardContent,
  Container,
  IconButton,
  MenuItem,
  Stack,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Toolbar,
  Typography,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import MyLocationIcon from '@mui/icons-material/MyLocation';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import NavigationIcon from '@mui/icons-material/Navigation';
import CloseIcon from '@mui/icons-material/Close';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import phoneLocationService from '../services/phoneLocationService';
import { findRoute, googleNavLink } from '../services/routingService';

/**
 * FindMyCarPage — "أين سيارتي؟" بنسخة Hybrid (قمر صناعي + أسماء شوارع)
 * مثل Apple Plans / Google Maps، مع ملاحة حية داخل التطبيق:
 * - كاميرا تتبع موقع الهاتف (بدون الخروج من التطبيق)
 * - إعادة حساب المسار تلقائيًا كلما تحركت السيارة أو تحرك المستخدم
 * - شريط تعليمات المنعطفات بالعربية + كشف الوصول
 * - زر فتح Google Maps يبقى كخيار احتياطي
 */

// نمط Hybrid: قمر صناعي + تسميات الشوارع في طبقة واحدة (نفس مصدر
// googleSatellite في useMapStyles لكن بصيغة lyrs=y = satellite+labels)
const HYBRID_STYLE = {
  version: 8,
  glyphs: 'https://cdn.traccar.com/map/fonts/{fontstack}/{range}.pbf',
  sources: {
    hybrid: {
      type: 'raster',
      tiles: [0, 1, 2, 3].map((i) => `https://mt${i}.google.com/vt/lyrs=y&hl=ar&x={x}&y={y}&z={z}`),
      tileSize: 256,
      maxzoom: 21,
      attribution: '© Google',
    },
  },
  layers: [{ id: 'hybrid', type: 'raster', source: 'hybrid' }],
};

const ROUTE_SOURCE = 'find-car-route';
const REROUTE_INTERVAL_MS = 20000; // إعادة حساب المسار كل 20 ثانية
const REROUTE_MOVE_M = 80; // أو فورًا إذا تحركت السيارة >80م
const ARRIVAL_M = 25; // أقل من 25م = وصلت

const haversineM = (a, b) => {
  const R = 6371000;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLon = ((b.lon - a.lon) * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
};

const fmtDist = (km) => (km < 1 ? `${Math.round(km * 1000)} متر` : `${km.toFixed(1)} كم`);

const FindMyCarPage = () => {
  const navigate = useNavigate();
  const devices = useSelector((state) => Object.values(state.devices.items));
  const positions = useSelector((state) => state.session.positions);

  const mapContainer = useRef(null);
  const mapRef = useRef(null);
  const phoneMarkerRef = useRef(null);
  const carMarkerRef = useRef(null);
  const rerouteTimer = useRef(null);
  const lastRouteCarPos = useRef(null);

  const [deviceId, setDeviceId] = useState('');
  const [profile, setProfile] = useState('driving');
  const [phone, setPhone] = useState(phoneLocationService.getLast());
  const [routeInfo, setRouteInfo] = useState(null);
  const [error, setError] = useState(null);
  const [locating, setLocating] = useState(false);
  const [navMode, setNavMode] = useState(false); // وضع الملاحة الحية
  const [arrived, setArrived] = useState(false);

  useEffect(() => {
    if (!deviceId && devices.length) setDeviceId(String(devices[0].id));
  }, [devices, deviceId]);

  // تهيئة الخريطة الهجينة مرة واحدة
  useEffect(() => {
    const map = new maplibregl.Map({
      container: mapContainer.current,
      style: HYBRID_STYLE,
      center: [10.18, 36.8],
      zoom: 15,
      attributionControl: { compact: true },
    });
    map.addControl(new maplibregl.NavigationControl({ visualizePitch: true }), 'top-right');
    map.on('load', () => {
      map.addSource(ROUTE_SOURCE, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] },
      });
      map.addLayer({
        id: `${ROUTE_SOURCE}-casing`,
        type: 'line',
        source: ROUTE_SOURCE,
        paint: { 'line-color': '#0d47a1', 'line-width': 9, 'line-opacity': 0.9 },
      });
      map.addLayer({
        id: ROUTE_SOURCE,
        type: 'line',
        source: ROUTE_SOURCE,
        paint: { 'line-color': '#42a5f5', 'line-width': 5 },
      });
    });
    mapRef.current = map;
    return () => {
      if (rerouteTimer.current) clearInterval(rerouteTimer.current);
      map.remove();
    };
  }, []);

  // اشتراك موقع الهاتف المستمر
  useEffect(() => {
    phoneLocationService.startWatch();
    const unsub = phoneLocationService.subscribe(setPhone);
    return () => {
      unsub();
      if (!navMode) phoneLocationService.stopWatch();
    };
  }, []);

  const carPosition = positions[Number(deviceId)] || null;

  const drawMarker = (ref, lngLat, color, label) => {
    const map = mapRef.current;
    if (!map || !lngLat) return;
    if (ref.current) ref.current.remove();
    const el = document.createElement('div');
    el.style.cssText = `background:${color};color:#fff;border-radius:50% 50% 50% 0;transform:rotate(-45deg);width:32px;height:32px;display:flex;align-items:center;justify-content:center;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.5);`;
    const span = document.createElement('span');
    span.style.cssText = 'transform:rotate(45deg);font-size:14px;font-weight:800;';
    span.textContent = label;
    el.appendChild(span);
    ref.current = new maplibregl.Marker({ element: el }).setLngLat(lngLat).addTo(map);
  };

  /** حساب/إعادة حساب المسار ورسمه. */
  const computeRoute = useCallback(async () => {
    if (!phone || !carPosition) return;
    const to = { lat: carPosition.latitude, lon: carPosition.longitude };
    const result = await findRoute({ lat: phone.lat, lon: phone.lon }, to, profile);
    if (!result.ok) {
      setError('تعذر حساب المسار');
      return;
    }
    setRouteInfo(result);
    lastRouteCarPos.current = to;
    setArrived(result.distanceKm * 1000 < ARRIVAL_M);
    const map = mapRef.current;
    if (!map) return;
    const draw = () => {
      map.getSource(ROUTE_SOURCE)?.setData({
        type: 'Feature',
        geometry: { type: 'LineString', coordinates: result.coords },
        properties: {},
      });
    };
    if (map.isStyleLoaded()) draw();
    else map.once('load', draw);
    if (!navMode) {
      const bounds = result.coords.reduce(
        (b, c) => b.extend(c),
        new maplibregl.LngLatBounds(result.coords[0], result.coords[0]),
      );
      map.fitBounds(bounds, { padding: 80, maxZoom: 17 });
    }
  }, [phone, carPosition, profile, navMode]);

  // تحديث العلامات والمسار عند تغير المواقع
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    drawMarker(phoneMarkerRef, phone ? [phone.lon, phone.lat] : null, '#00c853', 'أنا');
    drawMarker(
      carMarkerRef,
      carPosition ? [carPosition.longitude, carPosition.latitude] : null,
      '#e53935',
      '🚗',
    );
    computeRoute();
  }, [computeRoute, phone, carPosition]);

  // وضع الملاحة الحية: كاميرا تتبع + إعادة توجيه دورية (السيارة قد تتحرك)
  useEffect(() => {
    const map = mapRef.current;
    if (!navMode || !map) {
      if (rerouteTimer.current) {
        clearInterval(rerouteTimer.current);
        rerouteTimer.current = null;
      }
      return;
    }
    // كاميرا ملاحة: منظور مائل يتبع الهاتف
    if (phone) {
      map.easeTo({ center: [phone.lon, phone.lat], zoom: 18, pitch: 60, duration: 800 });
    }
    rerouteTimer.current = setInterval(() => {
      computeRoute();
      const p = phoneLocationService.getLast();
      if (p && mapRef.current) {
        mapRef.current.easeTo({ center: [p.lon, p.lat], duration: 600 });
      }
    }, REROUTE_INTERVAL_MS);
    return () => {
      if (rerouteTimer.current) {
        clearInterval(rerouteTimer.current);
        rerouteTimer.current = null;
      }
    };
  }, [navMode, computeRoute, phone]);

  // إعادة توجيه فورية إذا تحركت السيارة أثناء الملاحة
  useEffect(() => {
    if (!navMode || !carPosition || !lastRouteCarPos.current) return;
    const moved = haversineM(lastRouteCarPos.current, {
      lat: carPosition.latitude,
      lon: carPosition.longitude,
    });
    if (moved > REROUTE_MOVE_M) computeRoute();
  }, [navMode, carPosition, computeRoute]);

  const locateMe = async () => {
    setLocating(true);
    setError(null);
    const result = await phoneLocationService.getOnce();
    setLocating(false);
    if (!result.ok) setError(result.error);
    else if (mapRef.current) {
      mapRef.current.flyTo({ center: [result.position.lon, result.position.lat], zoom: 17 });
    }
  };

  const startNav = () => {
    setArrived(false);
    setNavMode(true);
  };

  const stopNav = () => {
    setNavMode(false);
    setArrived(false);
    const map = mapRef.current;
    if (map) map.easeTo({ pitch: 0, zoom: 15, duration: 600 });
    computeRoute(); // إعادة الإطار ليشمل النقطتين
  };

  // أقرب خطوة ملاحية (أول خطوة غير الوصول)
  const currentStep = routeInfo?.steps?.find((s) => s.instruction !== 'وصلت إلى سيارتك') || null;

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <AppBar position="static" color="default" elevation={1}>
        <Toolbar>
          <IconButton edge="start" onClick={() => navigate(-1)} aria-label="رجوع">
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h6" sx={{ ml: 1 }}>
            أين سيارتي؟
          </Typography>
        </Toolbar>
      </AppBar>

      {/* شريط تعليمات الملاحة (يظهر فقط في وضع الملاحة) */}
      {navMode && (
        <Box
          sx={(theme) => ({
            bgcolor: theme.palette.primary.main,
            color: theme.palette.primary.contrastText,
            px: 2,
            py: 1.5,
            display: 'flex',
            alignItems: 'center',
            gap: 1.5,
          })}
        >
          <NavigationIcon />
          <Box flex={1}>
            {arrived ? (
              <Typography fontWeight={800}>🎉 وصلت إلى سيارتك!</Typography>
            ) : (
              <>
                <Typography fontWeight={800}>
                  {currentStep?.instruction || 'اتبع الخط الأزرق'}
                </Typography>
                {currentStep?.distanceM > 0 && (
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    بعد {fmtDist(currentStep.distanceM / 1000)}
                  </Typography>
                )}
              </>
            )}
          </Box>
          <IconButton onClick={stopNav} sx={{ color: 'inherit' }} aria-label="إنهاء الملاحة">
            <CloseIcon />
          </IconButton>
        </Box>
      )}

      <Box ref={mapContainer} sx={{ flex: 1, minHeight: 0 }} />

      <Container maxWidth="sm" sx={{ py: 2 }}>
        {error && (
          <Alert severity="warning" sx={{ mb: 1.5 }} onClose={() => setError(null)}>
            {error}
          </Alert>
        )}
        {routeInfo?.fallback && (
          <Alert severity="info" sx={{ mb: 1.5 }}>
            لا يوجد اتصال — يُعرض خط مستقيم تقريبي بدل مسار الطرق.
          </Alert>
        )}

        {!navMode && (
          <Stack direction="row" spacing={1.5} mb={1.5}>
            <TextField
              select
              label="السيارة"
              value={deviceId}
              onChange={(e) => setDeviceId(e.target.value)}
              fullWidth
              size="small"
            >
              {devices.map((d) => (
                <MenuItem key={d.id} value={String(d.id)}>
                  {d.name}
                </MenuItem>
              ))}
            </TextField>
            <ToggleButtonGroup
              exclusive
              size="small"
              value={profile}
              onChange={(_, v) => v && setProfile(v)}
            >
              <ToggleButton value="driving">سيارة</ToggleButton>
              <ToggleButton value="walking">مشي</ToggleButton>
            </ToggleButtonGroup>
          </Stack>
        )}

        {routeInfo && (
          <Card sx={{ mb: 1.5 }}>
            <CardContent sx={{ py: 1.5, '&:last-child': { pb: 1.5 } }}>
              <Typography fontWeight={800}>
                {`المسافة إلى سيارتك: ${fmtDist(routeInfo.distanceKm)} · حوالي ${Math.max(1, Math.round(routeInfo.durationMin))} دقيقة`}
              </Typography>
              {navMode && carPosition && (
                <Typography variant="body2" color="text.secondary">
                  المسار يُحدَّث تلقائيًا كلما تحركت السيارة أو تحركت أنت.
                </Typography>
              )}
              {!phone && (
                <Typography variant="body2" color="text.secondary">
                  اضغط «حدد موقعي» لعرض موقعك وحساب المسار.
                </Typography>
              )}
            </CardContent>
          </Card>
        )}

        <Stack direction="row" spacing={1.5}>
          {!navMode ? (
            <>
              <Button
                variant="outlined"
                startIcon={<MyLocationIcon />}
                onClick={locateMe}
                disabled={locating}
                fullWidth
              >
                {locating ? 'جارٍ التحديد…' : 'حدد موقعي'}
              </Button>
              <Button
                variant="contained"
                color="primary"
                startIcon={<NavigationIcon />}
                disabled={!carPosition || !phone}
                fullWidth
                onClick={startNav}
              >
                ابدأ الملاحة
              </Button>
              <IconButton
                color="primary"
                disabled={!carPosition}
                aria-label="فتح في Google Maps"
                onClick={() =>
                  window.open(
                    googleNavLink(
                      { lat: carPosition.latitude, lon: carPosition.longitude },
                      profile,
                    ),
                    '_blank',
                    'noopener',
                  )
                }
              >
                <OpenInNewIcon />
              </IconButton>
            </>
          ) : (
            <Button variant="outlined" color="error" fullWidth onClick={stopNav}>
              إنهاء الملاحة
            </Button>
          )}
        </Stack>
        {!carPosition && (
          <Typography variant="body2" color="text.secondary" mt={1} textAlign="center">
            <DirectionsCarIcon fontSize="small" sx={{ verticalAlign: 'middle' }} /> لا يوجد موقع
            حديث لهذه السيارة بعد — انتظر وصول إشارة من جهاز التتبع.
          </Typography>
        )}
      </Container>
    </Box>
  );
};

export default FindMyCarPage;
