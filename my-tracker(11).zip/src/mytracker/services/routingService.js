/**
 * routingService — أقرب مسار من موقع الهاتف إلى السيارة + خطوات الملاحة.
 * يستخدم خادم OSRM العام (قيادة/مشي) مع خطوات منعطفات (steps) للملاحة
 * داخل التطبيق؛ عند غياب الاتصال يرجع خطًا مستقيمًا (fallback).
 */

const OSRM_BASE = 'https://router.project-osrm.org/route/v1';

/**
 * @returns {Promise<{ ok, coords?: [lon,lat][], distanceKm?: number,
 *   durationMin?: number, steps?: Array, fallback?: boolean }>}
 * steps: [{ instruction, distanceM, name }]
 */
export async function findRoute(from, to, profile = 'driving') {
  try {
    const url =
      `${OSRM_BASE}/${profile}/${from.lon},${from.lat};${to.lon},${to.lat}` +
      '?overview=full&geometries=geojson&steps=true';
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const route = data?.routes?.[0];
    if (!route) throw new Error('no route');

    const steps = [];
    (route.legs || []).forEach((leg) => {
      (leg.steps || []).forEach((step) => {
        steps.push({
          instruction: translateManeuver(step.maneuver, step.name),
          distanceM: step.distance,
          location: step.maneuver?.location, // [lon, lat]
        });
      });
    });

    return {
      ok: true,
      coords: route.geometry.coordinates,
      distanceKm: route.distance / 1000,
      durationMin: route.duration / 60,
      steps,
      fallback: false,
    };
  } catch {
    // بدون اتصال: خط مستقيم + مسافة هافرساين
    const R = 6371;
    const dLat = ((to.lat - from.lat) * Math.PI) / 180;
    const dLon = ((to.lon - from.lon) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos((from.lat * Math.PI) / 180) *
        Math.cos((to.lat * Math.PI) / 180) *
        Math.sin(dLon / 2) ** 2;
    const distanceKm = 2 * R * Math.asin(Math.sqrt(a));
    return {
      ok: true,
      coords: [
        [from.lon, from.lat],
        [to.lon, to.lat],
      ],
      distanceKm,
      durationMin: (distanceKm / 40) * 60,
      steps: [],
      fallback: true,
    };
  }
}

/** ترجمة منعطفات OSRM إلى العربية. */
function translateManeuver(maneuver, streetName) {
  if (!maneuver) return 'تابع الطريق';
  const street = streetName ? ` في ${streetName}` : '';
  const dir = {
    left: 'يسارًا',
    right: 'يمينًا',
    'slight left': 'قليلًا لليسار',
    'slight right': 'قليلًا لليمين',
    'sharp left': 'بحدة لليسار',
    'sharp right': 'بحدة لليمين',
    uturn: 'استدر وعد',
  };
  const mod = dir[maneuver.modifier] || '';
  switch (maneuver.type) {
    case 'depart':
      return `ابدأ${street}`;
    case 'arrive':
      return 'وصلت إلى سيارتك';
    case 'turn':
    case 'end of road':
      return `انعطف ${mod}${street}`.trim();
    case 'continue':
      return `تابع الطريق${street}`;
    case 'merge':
      return `اندمج ${mod}`.trim();
    case 'roundabout':
    case 'rotary':
      return `ادخل الدوار واخرج من المخارج ${maneuver.exit || ''}`.trim();
    case 'fork':
      return `خذ التفرع ${mod}`.trim();
    case 'new name':
      return `تابع${street}`;
    default:
      return `تابع ${mod}${street}`.trim();
  }
}

/** رابط ملاحة Google Maps خارجي (احتياطي). */
export const googleNavLink = (to, profile = 'driving') =>
  `https://www.google.com/maps/dir/?api=1&destination=${to.lat},${to.lon}&travelmode=${profile}`;
