/**
 * smartAlertsService — التنبيهات السياقية الذكية (V1).
 * بدل Geofence الثابت: قواعد سياقية تراقب تدفق المواقع الحي من traccarService:
 *
 *   1) حركة والمحرك مطفأ (احتمال سحب/قطر): ignition=false + speed>0.
 *   2) تجاوز السرعة: speed > العتبة المضبوطة في الإعدادات (مع تهدئة لتفادي التكرار).
 *   3) عودة الاتصال بعد انقطاع طويل (الجهاز اختفى ثم ظهر بعيدًا عن آخر موقع).
 *
 * التنبيهات تُخزَّن في storageService (smartAlerts.log) وتظهر في صفحة
 * "الملخص الذكي"، مع إشعار متصفح اختياري إن منح المستخدم الإذن.
 */

import traccarService from './traccarService';
import storageService from './storageService';

const MAX_LOG = 100;
// تهدئة: نفس نوع التنبيه لنفس الجهاز لا يتكرر قبل هذه المدة
const COOLDOWN_MS = 5 * 60 * 1000;

const deviceState = new Map(); // deviceId -> { lastAlertAt: {kind: ts}, lastSeen }
const deviceNames = new Map(); // deviceId -> name (من أحداث devices الحية)
let unsubscribe = null;

function kmh(speedKnots) {
  return (speedKnots || 0) * 1.852;
}

function notifyBrowser(title, body) {
  try {
    const { smartAlerts } = storageService.getState();
    if (!smartAlerts?.browserNotify) return;
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      // eslint-disable-next-line no-new
      new Notification(title, { body, icon: '/favicon.ico' });
    }
  } catch {
    // الإشعارات غير متاحة — نتجاهل بصمت
  }
}

function pushAlert(deviceId, deviceName, kind, title, body) {
  const state = storageService.getState();
  const prev = state.smartAlerts || { log: [] };
  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    ts: new Date().toISOString(),
    deviceId,
    deviceName: deviceName || `جهاز ${deviceId}`,
    kind,
    title,
    body,
    seen: false,
  };
  const log = [entry, ...(prev.log || [])].slice(0, MAX_LOG);
  storageService.update('smartAlerts', { log });
  notifyBrowser(title, body);
}

function onCooldown(devId, kind) {
  const st = deviceState.get(devId);
  const last = st?.lastAlertAt?.[kind] || 0;
  return Date.now() - last < COOLDOWN_MS;
}

function markAlerted(devId, kind) {
  const st = deviceState.get(devId) || { lastAlertAt: {} };
  st.lastAlertAt = { ...st.lastAlertAt, [kind]: Date.now() };
  deviceState.set(devId, st);
}

function handlePositions(positions) {
  const { smartAlerts } = storageService.getState();
  if (!smartAlerts?.enabled) return;

  positions.forEach((pos) => {
    const devId = pos.deviceId;
    const attrs = pos.attributes || {};
    const name = deviceNames.get(devId) || `مركبة ${devId}`;
    const speed = kmh(pos.speed);

    // قاعدة 1: حركة والمحرك مطفأ — احتمال سحب/قطر
    if (attrs.ignition === false && speed > 2 && !onCooldown(devId, 'tow')) {
      markAlerted(devId, 'tow');
      pushAlert(
        devId,
        name,
        'tow',
        `تنبيه سحب محتمل — ${name}`,
        `${name} تتحرك (${Math.round(speed)} كم/س) والمحرك مطفأ. تحقق من المركبة فورًا.`,
      );
    }

    // قاعدة 2: تجاوز السرعة
    const limit = smartAlerts?.overspeedKmh || 120;
    if (speed > limit && !onCooldown(devId, 'overspeed')) {
      markAlerted(devId, 'overspeed');
      pushAlert(
        devId,
        name,
        'overspeed',
        `تجاوز السرعة — ${name}`,
        `${name} تسير بسرعة ${Math.round(speed)} كم/س (الحد ${limit} كم/س).`,
      );
    }
  });
}

function handleDevices(devices) {
  // نخزّن الأسماء دائمًا (حتى لو التنبيهات معطلة) لتظهر صحيحة في التنبيهات
  devices.forEach((d) => {
    if (d.name) deviceNames.set(d.id, d.name);
  });
  const { smartAlerts } = storageService.getState();
  if (!smartAlerts?.enabled) return;
  devices.forEach((d) => {
    const st = deviceState.get(d.id) || { lastAlertAt: {} };
    // قاعدة 3: عودة الجهاز بعد انقطاع طويل (أكثر من 12 ساعة)
    const wasOfflineFor = st.lastSeen ? Date.now() - st.lastSeen : 0;
    if (d.status === 'online' && wasOfflineFor > 12 * 60 * 60 * 1000 && !onCooldown(d.id, 'reconnect')) {
      markAlerted(d.id, 'reconnect');
      pushAlert(
        d.id,
        d.name,
        'reconnect',
        `عودة الاتصال — ${d.name}`,
        `${d.name} عادت للاتصال بعد انقطاع تجاوز 12 ساعة.`,
      );
    }
    st.lastSeen = Date.now();
    deviceState.set(d.id, st);
  });
}

const smartAlertsService = {
  /** يبدأ مراقبة التدفق الحي. آمن للاستدعاء المتكرر. */
  start() {
    if (unsubscribe) return;
    unsubscribe = traccarService.subscribe(({ type, payload }) => {
      if (type === 'positions') handlePositions(payload || []);
      if (type === 'devices') handleDevices(payload || []);
    });
  },

  stop() {
    if (unsubscribe) {
      unsubscribe();
      unsubscribe = null;
    }
  },

  /** يطلب إذن إشعارات المتصفح ويحدّث الإعداد حسب النتيجة. */
  async requestBrowserPermission() {
    if (typeof Notification === 'undefined') return 'unsupported';
    const result = await Notification.requestPermission();
    storageService.update('smartAlerts', { browserNotify: result === 'granted' });
    return result;
  },

  /** يعلّم كل التنبيهات كمقروءة. */
  markAllSeen() {
    const { smartAlerts } = storageService.getState();
    storageService.update('smartAlerts', {
      log: (smartAlerts?.log || []).map((a) => ({ ...a, seen: true })),
    });
  },

  clearLog() {
    storageService.update('smartAlerts', { log: [] });
  },

  unseenCount() {
    return (storageService.getState().smartAlerts?.log || []).filter((a) => !a.seen).length;
  },
};

export default smartAlertsService;
