import { useEffect, useMemo, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemText,
  MenuItem,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import DeleteSweepIcon from '@mui/icons-material/DeleteSweep';
import RefreshIcon from '@mui/icons-material/Refresh';
import PageLayout from '../../common/components/PageLayout';
import { fetchInsights, kmFromMeters, kmhFromKnots } from '../services/tripInsightsService';
import smartAlertsService from '../services/smartAlertsService';
import storageService from '../services/storageService';

const useStyles = makeStyles()((theme) => ({
  page: { paddingBottom: theme.spacing(10) },
  statCard: {
    flex: '1 1 40%',
    minWidth: 140,
  },
  statValue: {
    fontSize: '1.6rem',
    fontWeight: 800,
    color: theme.palette.primary.main,
  },
  summaryLines: {
    fontSize: '1.05rem',
    lineHeight: 2,
  },
  alertItem: {
    borderRadius: theme.shape.borderRadius,
    marginBottom: theme.spacing(1),
    background: theme.palette.background.paper,
  },
}));

const toInputDate = (d) => d.toISOString().slice(0, 10);

const TripSummaryPage = () => {
  const { classes } = useStyles();
  const navigate = useNavigate();
  const devices = useSelector((state) => Object.values(state.devices.items));
  const [deviceId, setDeviceId] = useState('');
  const [date, setDate] = useState(toInputDate(new Date()));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [insights, setInsights] = useState(null);
  const [alerts, setAlerts] = useState(storageService.getState().smartAlerts?.log || []);

  useEffect(() => {
    if (!deviceId && devices.length) setDeviceId(String(devices[0].id));
  }, [devices, deviceId]);

  useEffect(
    () => storageService.subscribe((s) => setAlerts(s.smartAlerts?.log || [])),
    [],
  );

  const load = async () => {
    if (!deviceId) return;
    setLoading(true);
    setError(null);
    const from = new Date(`${date}T00:00:00`);
    const to = new Date(`${date}T23:59:59`);
    const result = await fetchInsights(Number(deviceId), from, to);
    setLoading(false);
    if (!result.ok) {
      setError(result.error);
      setInsights(null);
    } else {
      setInsights(result.insights);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deviceId, date]);

  const stats = useMemo(() => {
    if (!insights) return [];
    const t = insights.totals;
    return [
      { label: 'المسافة', value: `${Math.round(t.distanceKm * 10) / 10}`, unit: 'كم' },
      { label: 'عدد الرحلات', value: `${t.trips}`, unit: '' },
      { label: 'أعلى سرعة', value: `${Math.round(t.maxSpeedKmh)}`, unit: 'كم/س' },
      { label: 'متوسط السرعة', value: `${Math.round(t.avgSpeedKmh)}`, unit: 'كم/س' },
    ];
  }, [insights]);

  const kindColor = { tow: 'error', overspeed: 'warning', reconnect: 'info' };
  const kindLabel = { tow: 'سحب محتمل', overspeed: 'تجاوز سرعة', reconnect: 'عودة اتصال' };

  return (
    <PageLayout
      menu={<div />}
      breadcrumbs={['الملخص الذكي']}
    >
      <Box className={classes.page} p={2}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} mb={2}>
          <TextField
            select
            label="المركبة"
            value={deviceId}
            onChange={(e) => setDeviceId(e.target.value)}
            fullWidth
          >
            {devices.map((d) => (
              <MenuItem key={d.id} value={String(d.id)}>{d.name}</MenuItem>
            ))}
          </TextField>
          <TextField
            type="date"
            label="اليوم"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
            fullWidth
          />
          <IconButton onClick={load} disabled={loading} color="primary" aria-label="تحديث">
            <RefreshIcon />
          </IconButton>
        </Stack>

        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        {loading && <Typography color="text.secondary">جارٍ تحليل الرحلات…</Typography>}

        {insights && (
          <>
            <Card sx={{ mb: 2 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>ملخص اليوم</Typography>
                <Box className={classes.summaryLines}>
                  {insights.lines.map((line) => (
                    <Typography key={line}>{line}</Typography>
                  ))}
                </Box>
              </CardContent>
            </Card>

            <Stack direction="row" flexWrap="wrap" gap={1.5} mb={3}>
              {stats.map((s) => (
                <Card key={s.label} className={classes.statCard}>
                  <CardContent>
                    <Typography variant="body2" color="text.secondary">{s.label}</Typography>
                    <span className={classes.statValue}>{s.value}</span>{' '}
                    <Typography component="span" color="text.secondary">{s.unit}</Typography>
                  </CardContent>
                </Card>
              ))}
            </Stack>

            {insights.trips.length > 0 && (
              <>
                <Typography variant="h6" gutterBottom>تفاصيل الرحلات</Typography>
                <List disablePadding>
                  {insights.trips.map((trip) => (
                    <Card key={`${trip.startTime}-${trip.endTime}`} sx={{ mb: 1 }}>
                      <CardContent>
                        <Typography fontWeight={700}>
                          {new Date(trip.startTime).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}
                          {' → '}
                          {new Date(trip.endTime).toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}
                        </Typography>
                        <Typography color="text.secondary">
                          {`${Math.round(kmFromMeters(trip.distance) * 10) / 10} كم · أقصى سرعة ${Math.round(kmhFromKnots(trip.maxSpeed))} كم/س`}
                        </Typography>
                        {(trip.startAddress || trip.endAddress) && (
                          <Typography variant="body2" color="text.secondary">
                            {`من: ${trip.startAddress || '—'} · إلى: ${trip.endAddress || '—'}`}
                          </Typography>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </List>
              </>
            )}
          </>
        )}

        <Divider sx={{ my: 3 }} />
        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={1}>
          <Typography variant="h6">التنبيهات الذكية</Typography>
          {alerts.length > 0 && (
            <Button
              size="small"
              startIcon={<DeleteSweepIcon />}
              onClick={() => smartAlertsService.clearLog()}
            >
              مسح الكل
            </Button>
          )}
        </Stack>
        {alerts.length === 0 ? (
          <Typography color="text.secondary">
            لا توجد تنبيهات — سننبهك عند حركة مشبوهة أو تجاوز سرعة أو انقطاع طويل.
          </Typography>
        ) : (
          <List disablePadding>
            {alerts.map((a) => (
              <ListItem key={a.id} className={classes.alertItem} disableGutters sx={{ px: 2 }}>
                <ListItemText
                  primary={a.title}
                  secondary={`${a.body} — ${new Date(a.ts).toLocaleString('ar')}`}
                />
                <Chip size="small" color={kindColor[a.kind] || 'default'} label={kindLabel[a.kind] || a.kind} />
              </ListItem>
            ))}
          </List>
        )}
      </Box>
    </PageLayout>
  );
};

export default TripSummaryPage;
